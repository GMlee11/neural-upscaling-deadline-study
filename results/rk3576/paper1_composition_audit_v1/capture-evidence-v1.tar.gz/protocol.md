# RK3576 composition-audit successor V1

Engineering identity: `paper1-composition-rk3576-v1`, authorized 2026-09-14.
Inherits `paper1_composition_audit_v1.md`; the completed RK3566 campaign and all
earlier RK3576 captures remain unchanged. No paper-facing samples have been taken.

Use the retained width-24 INT8 models, not a new graph or compilation. Match the
original 30-FPS core profiles: `single_dualcore_01` at 320x180 and
`dual_independent_01` at 640x360, with three slots per context. These are not an
isolated chip-speed comparison with the single-context RK3566.

The opt-in `PAPER1_COMPOSITION_AUDIT` build propagates the runtime slot-release
return code through the native consumer; the audited recorder must reject a
failed release even on the final source. Legacy builds remain unchanged. An
initial LD_PRELOAD engineering shim could not intercept the hidden native symbol;
retain that failed test. The replacement explicit
`PAPER1_ENGINEERING_RELEASE_FAIL_TOKEN` hook substitutes a failed return at the
release boundary after safely releasing the slot. Capture rejects every
`PAPER1_ENGINEERING_*` environment variable and loader injection. This tests error
propagation, not an actual driver-induced failure. Preserve all attempts.

Engineering numerical V1 requested a raw-INT8 field formerly exposed only by
the RK3566 build. The opt-in validation path now exposes it on RK3576 too.
V2 then showed byte-exact residuals for all 16 cases, but vertically inverted
capture/reconstruction for the four spatial-pattern cases. The current board
uses Godot 4.6.3 + Mesa 25.0.7 Panfrost. Removing the legacy vertical flip in
the opt-in input shader and capture blit corrects this current-stack contract;
full qualification must pass again. This is not a finding that the historical
runtime/session had the same orientation; do not backdate or overwrite evidence.

Restore Godot 4.6.3 with the accepted binary SHA-256, godot-cpp commit
6cceaf6a5f8b0d78ac5d71c139fd7fabba43b918, and the installed RKNN library with its
recorded hash. Qualify synthetic pixels/ownership faults, native source-coded
capture at both resolutions, numerical direct/copied agreement, final-release
failure, and twelve short production cells. Freeze all computational assets,
source/scripts, package/kernel/governor identity, review and commands before the
single fixed 12-cell x 300-source campaign. No positive result is required.

Use the existing desktop DISPLAY :1 and its existing user Xauthority; do not
archive authentication material or stop the user's display server. Preserve
other projects on the board. Existing desktop activity is part of the disclosed
session environment, not a controlled cross-session speed comparison.
