# Independent RK3576 composition-audit source review

Date: 2026-09-14

Decision: SOURCE ACCEPTABLE; PHYSICAL GO PENDING QUALIFICATION EVIDENCE.

No concrete acceptance-blocking source defect was identified in the inspected RK3576 successor changes. This is not approval to freeze or start scientific capture. The final engineering evidence and exact deployed identities have not yet been independently reviewed.

## Review scope

Read both composition protocols, all `scripts/rk3576/*composition*_v1*` files, the opt-in build/native changes, and the audited recorder's release/terminal ordering. Checkout HEAD was `c5469324b8e2e8915dc4d1596af8e0f86341e783`; the RK3576 changes were uncommitted. The hashes below identify the inspected working bytes. No board connection, build, renderer, qualification, inference or capture was performed. Only this review file was written. The completed RK3566 campaign was not revisited.

## Source findings

- `PAPER1_COMPOSITION_AUDIT` selects the checked release implementation without changing the legacy non-audit RK3576 branch. Runtime release failure leaves the frame unsuccessful; `consume_direct_frame()` refreshes `ok`, `error` and `slot_released` after release. The recorder returns false on a failed consume whenever `composition_contract` is enabled, before writing the successful source row or its terminal event. This closes the previously identified final-source silent-success path at source level.
- The explicit engineering hook changes the returned status after the real release operation. It tests propagation through the actual consumer/recorder, not a physical driver failure or proof that a failing driver safely releases resources. The final-release fixture requires the hook marker, release-error text, renderer exit 3, zero successful source rows, and a failed audit prefix at both resolutions. Evidence must establish these checks ran against the final binary, rather than merely showing the script exists.
- The capture environment function rejects any `PAPER1_ENGINEERING_*` variable, including an empty-valued one, and nonempty `LD_PRELOAD`/`LD_AUDIT`. Direct in-memory tests reproduced all four rejection cases and accepted the clean environment. The obsolete interposer is not in the extension's source fileset or the capture command.
- Raw INT8 readback is confined to the explicit validation method. Frozen capture arguments disable validation/source/native readback. The numerical checker compares direct residual bytes with an independent ordinary-RKNN result on the exact quantized input, and checks source/input and composition tolerances. Although copied residual bytes are also saved, this checker does not itself compare that saved copied payload; describe its actual ordinary-reference check accurately unless the delivered evidence separately verifies copied-payload equality.
- Commands retain the prescribed model shapes, 30-FPS controls, three slots per context, logging pairs and 12-cell order. The profiles are `single_dualcore_01` at width 320 and `dual_independent_01` at width 640. These are different execution topologies from RK3566, not an isolated chip-speed comparison.
- The inherited selection/source ownership checks remain active with logging both on and off. The scientific boundary remains root-output selection during viewport updates, not GPU completion or scanout. Capture holds and detach-before-release remain disclosed scheduling changes.
- Freeze creation requires a qualified record, verifies its source hashes and package/kernel identity, and binds the review, protocols, schedule and assets. Capture rechecks frozen files and identity, refuses an existing session directory, uses fixed stop rules and rehashes assets on completion. No later positive outcome is required.

All nine matching Python scripts parsed without executing their entrypoints. Read-only command construction confirmed both core profiles and the no-readback flags. No native build or runtime success is inferred from these static checks.

## Conditions before a final physical decision

These are the already prescribed qualification/freeze gates, not requests for additional scientific experiments:

1. Supply the hash-verified retained engineering archive, including the unsuccessful interposer and earlier INT8-field attempt, plus successful synthetic, both-resolution source-coded, numerical, final-release-failure and twelve short production-cell evidence.
2. Bind successful tests to the final opt-in native binary and deployed source. Demonstrate that the final-source hook fired after warmup at each topology and prevented normal completion. The capture binary must be the qualified binary, with the hook absent from its capture environment.
3. Verify all fixed numerical cases and tolerances, source/slot/token ownership, empty success error lists and complete short-cell telemetry. Preserve failures; do not count engineering frames as scientific samples.
4. After independent evidence review, create and verify the exact freeze covering models, Godot, runtime, native library, project/shader/policy assets, scripts/protocols/review and environment identity. Preserve the existing desktop and disclose its activity; do not imply controlled cross-board speed causality.

Until these conditions are satisfied, scientific capture remains unapproved by this review. No source repair is requested on the evidence currently inspected.

## Inspected SHA-256 identities

| File | SHA-256 |
|---|---|
| RK3576 protocol | 3f3010f0735b9f42c27eb2c78bc8ff9c9d021a4e161f933d396456abd67301a9 |
| Inherited protocol | 86727b52529cbdd36b7a252aa1c6712b4f6cc73ddb6adffc3f201c5b9f6e6ea0 |
| main.gd | ebc5135bfaabba82d1bde126fe3fc9db3a06e7837645a2133408a77e31cce00d |
| composition_audit.gd | b22b2b738e09c22c9f4677d07ef1fccd124f2633c62789f899d9d6d71b168e51 |
| native_bridge/SConstruct | bb30a67943b6b4713e58a257bdfeca6762f26e1113b066c9bb6ee849bdc3f429 |
| rk3576_native_bridge.cpp | 8779ce84685ce55129cd8bec3515247abad78a4d3b2211ab603ff33af9df3c58 |
| RK3576 runner | 33d009d0edbceaaa23140b7971b67c5e02a9f6bbcc0cc8a312fabe2d5312df22 |
| RK3576 freezer | 482f4ad2e1a80d297eb1bb3c02bfd8f8f5f8eaaa89cac3ba1006cbd9ec37ce65 |
| RK3576 engineering sealer | 8c56309276e9bbff0c0b82532bcb64ce87e88a66894da682cc80ccca8c4757e4 |
| Final-release qualifier | db2efe95064ed68d9e1d388005bf3f01b8f772aca4cee5fe9d767516237103f4 |
| Numerical checker | 50addd31ed42014f1f98e12e257c6a64ab612d290ca25878e8babcc0d091006a |

## Addendum: V3 orientation repair, source review only

Reviewed the subsequent opt-in orientation changes on 2026-09-14. Current native source SHA-256 is `ec411a66ae120116fea8499dac94ea99f6dd7879e72685da3b7d9b9dc23d0f4a`; updated RK3576 protocol SHA-256 is `16822f28bef84b7363a2264df1574aa081ab2ace1a9447c137c230c1609976a4`.

In-memory reversal of exactly the two orientation-site changes reproduces the previously reviewed native hash `8779ce84...df3c58`. Thus the earlier release-error and validation-readback repairs remain unchanged. The input-packing shader now uses `source_y = model_y` for the audit build, and the retained LR capture blit uses the corresponding non-reversed destination rectangle. Both paths read the same source texture; changing both avoids correcting the model input while leaving the retained composition base inverted. Legacy non-audit RK3576 branches retain their original behavior.

This is a defensible functional correction before scientific capture, conditional on the prescribed V3 qualification. Byte-exact residuals on a wrongly oriented input do not establish end-to-end correctness; spatially varying source/input and final-composition comparisons are necessary here and already exist in the fixed numerical fixture. The checker still compares against the unflipped observed viewport and unchanged tolerances. It does not silently flip the expected reference to accommodate the failure.

No additional source blocker was identified. Final acceptance requires the V3 archive to demonstrate all fixed numerical cases, including the four spatial-pattern cases, pass against that unchanged reference, together with the complete repeated synthetic/native-source/release-failure/short-integration qualification on the final binary. Constant-color or residual-only success is insufficient to close this specific orientation failure. These are existing qualification requirements, not new performance experiments.

The reported V2 failure and Mesa/Panfrost diagnosis were supplied by the orchestrator; their raw evidence has not yet been independently examined in this addendum. Retain them with the successful V3 evidence. Describe the repair as specific to the qualified current stack, not proof that an earlier session was inverted. No historical result is backdated, invalidated, or overwritten by this source inspection. Physical capture remains unapproved pending the final evidence review and freeze.

## Final engineering-evidence review and bounded decision

Date: 2026-09-14. This section supersedes the pending-evidence disposition above for the exact qualification and source identities stated here.

Decision: GO for RK3576 freeze and capture

Scope: create and verify the final hash-bound freeze, then execute exactly the prescribed single `capture-v1` session: twelve fixed cells, 300 source frames per cell, 3,600 total, under `paper1_composition_audit_rk3576_v1.md` and its inherited protocol. This approval does not authorize changed models, source, topology, policy, clocks, deadlines, commands, replacement cells, retries or additional experiments. Preserve zero outcomes and any terminal failure. No hardware action was performed by this reviewer.

### Independently verified evidence

- Archive `output/paper1_composition_rk3576_v1/engineering-evidence-v1.tar.gz`: 2,097,101 bytes; SHA-256 `56cab28de76cd1b0bf1fd68a191a01b9c131d55374bd37d172da0ea65b19792a`. All 534 manifest entries matched both archive bytes and extracted evidence. There are 535 regular archive files including the manifest itself.
- `engineering-qualified-v1.json`: SHA-256 `4d75681d58fad70b7350b11e9872c1f1baae8e236fd0e233b6d65f069dd045fd`, binding 58 source/asset/dependency paths. Available local source counterparts match those identities, accounting for LF/CRLF representation where necessary. The final build log and qualified record agree on native binary SHA-256 `1ba7efab958313052e9aa2c16310136a36cef5025c686cf25c0aad29944b478c`. Runtime SHA is `cf6ea624489225ddc9d334b370c64083b0fd9d6a5c9166eed47d999cc85a806b`; accepted models and Godot hashes remain those specified above.
- `synthetic-v3`: 9 sources, 46 draws (27 classical, 18 neural, one blank), no success-header errors, all nine expected rejection markers and final PASS. The deliberate write-failure prefix is retained and not mistaken for successful evidence.
- `native-source-v3`: both widths contain source IDs 0–8 exactly once, all native input errors zero, with delayed consumption/live-source advancement present. Both saved datasets pass the production source/token/draw/release validator.
- `release-v3`: source 0 has token 4 at width 320 and token 7 at width 640 after their respective warmups. Both renderer logs contain the explicit engineering fault and runtime release error. Both retain failed audit headers and zero successful source rows or source-terminal events. The qualified harness requires exit 3 before producing its PASS record. These are failed-return propagation tests after safe release, not induced driver failures.
- `numerical-v3`: reran the actual checker against a disposable copy using the available bundled Python dependencies; reproduced the saved `check.json` exactly. All sixteen cases pass: residual bytes exactly match ordinary RKNN on the exact INT8 tensor, maximum input error 1, maximum composition error 1, maximum composition MAE `0.010168909143518519`. No original evidence or check file was overwritten.
- `integration-v2`: all twelve eight-source cells pass the production validator, exact schedule and command comparison; no renderer-error markers occur in their stderr. Logging on/off uses the same ownership/capture behavior.
- Prior attempts remain in the archive. In particular, `numerical-v2` retains the four failed spatial-pattern cases (patterns 3 and 7 at each width), with input/composition maximum errors 255; V3 passes the unchanged checker. The retained pre-V3 native source matches the previously reviewed native hash. This supports the bounded current-stack orientation correction, not a historical-session claim.

### Numerical scope clarification

An additional read-only comparison found that the separately saved legacy copied-RGB residual payloads are not byte-identical to the direct payloads. The numerical PASS is specifically the independent ordinary-RKNN reference using the exact INT8 input, together with viewport/input and final-composition checks. The copied-RGB path is a different input path and is not the scientific capture path. Do not describe this evidence as unrestricted direct/copied-RGB equivalence. This distinction does not invalidate the direct-path qualification or require another experiment for the proposed composition study.

### Final source/freeze checks and limits

The native source remains `ec411a66ae120116fea8499dac94ea99f6dd7879e72685da3b7d9b9dc23d0f4a`. Current runner SHA is `8063bd11ef1b68135586ff66027ce7562b4b745551e3be2be5e75b27014cbb08`; removing only its new all-CPU-policy comparison reproduces the previously reviewed runner hash. The final freezer (`fafd0232495fbd4bfe01f55f9740f44410e0950310531139e73131854b99f723`) records that same complete policy map. The sealer (`284571e3d522f7222d385e2241cf43781d5348c74449f9c9d2a9a2a3c6fce54b`) now also binds resolved executable dependencies and preserves earlier revision snapshots. These changes do not alter measured commands or scientific gates. In-memory checks again rejected engineering-hook and loader-injection environments.

No remaining acceptance-relevant blocker was found. Final freeze verification must use this review snapshot, the exact qualified record and final files, with all CPU/GPU/NPU governor policies and the recorded package/kernel identity. Any mismatch blocks the authorized session. The frozen qualifier status is a historical pre-review label, not a substitute for this explicit decision.

Keep the current desktop/environment disclosure, source-throughput versus draw-age distinction, and single-session scope. Do not pool or backdate results into earlier RK3576 or RK3566 campaigns, claim scanout/GPU completion, or infer an isolated chip-speed advantage. Only independent review of the retrieved terminal capture will establish its scientific outcome. This reviewer ran no physical action and made no source or manuscript edits.
