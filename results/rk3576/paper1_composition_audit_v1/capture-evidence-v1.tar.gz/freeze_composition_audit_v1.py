"""Bind reviewed qualification to one immutable RK3576 capture schedule."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
from run_composition_audit_v1 import BASE, OLD, sha, schedule, environment

ap = argparse.ArgumentParser()
ap.add_argument('--source-commit',required=True)
ap.add_argument('--review-turn',required=True)
ap.add_argument('--qualification',required=True)
args = ap.parse_args()
assert not (BASE/'capture').exists()
environment()
review = BASE/'independent-review.md'
assert 'Decision: GO for RK3576 freeze and capture' in review.read_text()
qualification = OLD/args.qualification
qualified = json.loads(qualification.read_text())
assert qualified['status'] == 'ENGINEERING_QUALIFIED_REVIEW_PENDING'
for path,digest in qualified['source_files'].items():
    assert sha(Path(path)) == digest,path
packages = subprocess.check_output(['dpkg-query','-W'],text=True)
kernel = subprocess.check_output(['uname','-a'],text=True).strip()
assert packages == qualified['packages'] and kernel == qualified['kernel']
files = dict(qualified['source_files'])
for p in (review,qualification,BASE/'freeze_composition_audit_v1.py',BASE/'protocol.md',BASE/'paper1_composition_audit_v1.md'):
    files[str(p)] = sha(p)
record = dict(protocol='paper1_composition_rk3576_v1',schema=2,capture_identity='capture-v1',
              independent_approval=True,review_turn=args.review_turn,review_sha256=sha(review),
              source_commit=args.source_commit,frozen_at_utc=datetime.now(timezone.utc).isoformat(),
              schedule=schedule(),packages=packages,kernel=kernel,
              cpu_governor=Path('/sys/devices/system/cpu/cpufreq/policy0/scaling_governor').read_text().strip(),
              cpu_governors={str(p):p.read_text().strip() for p in Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_governor')},
              gpu_npu_governors={str(p):p.read_text().strip() for p in Path('/sys/class/devfreq').glob('*/governor')},files=files)
with (BASE/'freeze.json').open('x') as f:
    json.dump(record,f,indent=2)
print('FROZEN',sha(BASE/'freeze.json'),len(files))
