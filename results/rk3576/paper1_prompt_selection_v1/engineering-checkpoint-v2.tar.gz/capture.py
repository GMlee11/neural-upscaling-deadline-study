"""One reviewed/frozen prompt-policy comparison. No engineering or retries."""
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time
from validate import validate
from bindings import merged,verify
BASE=Path('/home/radxa/experiments/paper1-prompt-selection-v1')
OLD=Path('/home/radxa/experiments/paper1-composition-rk3576-v1')
spec=importlib.util.spec_from_file_location('old_runner',OLD/'run_composition_audit_v1.py')
r=importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def schedule():
    result=[]
    for rep in range(2):
        for i,(width,control,modes) in enumerate([(320,'bicubic',['ordered','prompt']),(320,'always',['prompt','ordered']),(640,'always',['ordered','prompt']),(640,'bicubic',['prompt','ordered'])]):
            for mode in (modes if rep==0 else modes[::-1]):
                result.append(dict(repetition=rep+1,width=width,control=control,mode=mode))
    return result

def command(row,out):
    cmd=r.command(dict(row,logging=True),out,300)
    cmd[cmd.index('--path')+1]=str(BASE/'project')
    return cmd+['--selection-mode='+row['mode']]

def platform():
    return dict(packages=subprocess.check_output(['dpkg-query','-W'],text=True),kernel=subprocess.check_output(['uname','-a'],text=True).strip(),
        cpu_governors={str(p):p.read_text().strip() for p in Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_governor')},
        gpu_npu_governors={str(p):p.read_text().strip() for p in Path('/sys/class/devfreq').glob('*/governor')})

def source_files():
    files=[p for p in (BASE/'project').rglob('*') if p.is_file() and '.godot' not in p.relative_to(BASE/'project').parts]
    files += [BASE/n for n in ['capture.py','validate.py','bindings.py','protocol.md','qualification-v2.json','independent-review.md','project/.godot/extension_list.cfg']]
    files += [OLD/'run_composition_audit_v1.py',OLD/'engineering/godot/Godot_v4.6.3-stable_linux.arm64',Path('/usr/lib/librknnrt.so')]
    files += [OLD/f'engineering/models/{w}x{w*9//16}/model.rknn' for w in (320,640)]
    return {str(p):sha(p) for p in files}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--freeze',action='store_true')
    args=ap.parse_args()
    env=r.environment()
    target=BASE/'capture-v1'
    if args.freeze:
        assert not target.exists()
        review=(BASE/'independent-review.md').read_text()
        assert 'Decision: GO for prompt-selection freeze and capture' in review
        q=json.loads((BASE/'qualification-v2.json').read_text())
        assert q['qualified'] is True
        for p,h in q['source_files'].items():
            assert sha(Path(p))==h,p
        assert platform()==q['platform']
        commands=[command(row,target/f'{i:02d}_{row["width"]}_{row["control"]}_{row["mode"]}') for i,row in enumerate(schedule())]
        closure=merged(q['source_files'],source_files())
        record=dict(protocol='paper1_prompt_selection_v1',created_utc=datetime.now(timezone.utc).isoformat(),files=closure,platform=platform(),schedule=schedule(),commands=commands)
        with (BASE/'freeze.json').open('x') as f:
            json.dump(record,f,indent=2)
        print('FROZEN',sha(BASE/'freeze.json'),flush=True)
        return
    frozen=json.loads((BASE/'freeze.json').read_text())
    assert frozen['protocol']=='paper1_prompt_selection_v1' and frozen['schedule']==schedule()
    assert frozen['platform']==platform()
    verify(frozen['files'])
    target.mkdir(exist_ok=False)
    state=dict(status='RUNNING',freeze_sha256=sha(BASE/'freeze.json'),cells=[])
    try:
        for i,row in enumerate(schedule()):
            cell=target/f'{i:02d}_{row["width"]}_{row["control"]}_{row["mode"]}'
            cell.mkdir()
            cmd=command(row,cell)
            assert cmd==frozen['commands'][i]
            (cell/'command.json').write_text(json.dumps(cmd,indent=2))
            record=dict(row,index=i,status='STARTED')
            state['cells'].append(record)
            temp=lambda:int(Path('/sys/class/thermal/thermal_zone0/temp').read_text())/1000
            until=time.monotonic()+300
            while temp()>55:
                assert time.monotonic()<until,'cooling limit'
                time.sleep(1)
            with (cell/'stdout.log').open('x') as stdout,(cell/'stderr.log').open('x') as stderr,(cell/'system.jsonl').open('x') as system:
                start=time.monotonic()
                proc=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=stderr)
                try:
                    while proc.poll() is None:
                        temperature=temp()
                        system.write(json.dumps(dict(monotonic=time.monotonic(),temperature_c=temperature))+'\n')
                        system.flush()
                        assert temperature<80 and time.monotonic()-start<180,'thermal/timeout stop'
                        time.sleep(.5)
                    assert proc.returncode==0,('renderer exit',proc.returncode)
                finally:
                    if proc.poll() is None:
                        proc.terminate()
                        try: proc.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            proc.kill();proc.wait()
            assert 'ERROR:' not in (cell/'stderr.log').read_text()
            r.validate(cell,300,True)
            record.update(validate(cell,300,row['mode'],row['control']),status='COMPLETE')
            (target/'progress.json').write_text(json.dumps(state,indent=2))
            print('COMPLETE',i+1,16,cell.name,flush=True)
        state['status']='COMPLETE'
    except BaseException as error:
        state.update(status='FAILED',error=repr(error))
        raise
    finally:
        changed=[p for p,h in frozen['files'].items() if sha(Path(p))!=h]
        if changed: state.update(status='FAILED',changed_files=changed)
        (target/'terminal.json').write_text(json.dumps(state,indent=2))
        manifest={str(p.relative_to(target)):sha(p) for p in sorted(target.rglob('*')) if p.is_file()}
        (target/'sha256.json').write_text(json.dumps(manifest,indent=2))

if __name__=='__main__':main()
