"""Engineering-only eight-cell smoke, disjoint from scientific capture."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
from validate import validate as validate_selection

BASE = Path('/home/radxa/experiments/paper1-prompt-selection-v1')
OLD = Path('/home/radxa/experiments/paper1-composition-rk3576-v1')
spec = importlib.util.spec_from_file_location('old_runner',OLD/'run_composition_audit_v1.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

parser = argparse.ArgumentParser()
parser.add_argument('--identity',required=True)
args = parser.parse_args()
assert args.identity.startswith('smoke-') and args.identity.replace('-','').isalnum()
out = BASE/'engineering'/args.identity
out.mkdir(parents=True,exist_ok=False)
for width in (320,640):
    for control in ('bicubic','always'):
        for mode in ('ordered','prompt'):
            cell = out/f'{width}_{control}_{mode}'
            cell.mkdir()
            command = runner.command(dict(width=width,control=control,logging=True),cell,8)
            command[command.index('--path')+1] = str(BASE/'project')
            command.append('--selection-mode='+mode)
            (cell/'command.json').write_text(json.dumps(command,indent=2))
            with (cell/'run.log').open('x') as log:
                result = subprocess.Popen(command,env=runner.environment(),stdout=log,stderr=subprocess.STDOUT)
                libraries=set()
                deadline=time.monotonic()+90
                try:
                    while result.poll() is None:
                        assert time.monotonic()<deadline,'engineering timeout'
                        try:
                            maps=Path(f'/proc/{result.pid}/maps').read_text()
                            for line in maps.splitlines():
                                fields=line.split(None,5)
                                if len(fields)==6 and fields[5].startswith('/') and Path(fields[5]).is_file():
                                    libraries.add(fields[5])
                        except FileNotFoundError:pass
                        time.sleep(.05)
                finally:
                    if result.poll() is None:
                        result.kill();result.wait()
                    (cell/'mapped_files.json').write_text(json.dumps(sorted(libraries),indent=2))
            text = (cell/'run.log').read_text()
            assert result.returncode==0 and 'ERROR:' not in text, text[-4000:]
            check = runner.validate(cell,8,True)
            validate_selection(cell,8,mode,control)
            print(cell.name,check,flush=True)
print('ENGINEERING_SMOKE_PASS',flush=True)
