"""Qualification closure is never narrowed when constructing a capture freeze."""
import hashlib
from pathlib import Path

def verify(files):
    for name,digest in files.items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name

def merged(qualified,extra):
    verify(qualified)
    for name,digest in extra.items():
        assert name not in qualified or qualified[name]==digest,name
    result=dict(qualified)
    result.update(extra)
    return result
