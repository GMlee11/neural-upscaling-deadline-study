"""Ordinary RKNN reference for engineering inputs only; no model changes."""
from pathlib import Path
import subprocess
import argparse
ap=argparse.ArgumentParser()
ap.add_argument('--identity',required=True)
a=ap.parse_args()
assert a.identity.startswith('functional-') and a.identity.replace('-','').isalnum()
BASE=Path('/home/radxa/experiments/paper1-prompt-selection-v1/engineering')/a.identity
OLD=Path('/home/radxa/experiments/paper1-composition-rk3576-v1/engineering')
for width in (320,640):
    cell=BASE/f'{width}_native'
    for source in range(9):
        target=cell/f'source_{source}_reference.nchw'
        assert not target.exists()
        with (cell/f'source_{source}_reference.log').open('x') as log:
            subprocess.run([str(OLD/'numerical-v3/reference'),str(OLD/f'models/{width}x{width*9//16}/model.rknn'),str(cell/f'source_{source}_input_int8.bin'),str(target)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
    print('REFERENCE_COMPLETE',width,flush=True)
