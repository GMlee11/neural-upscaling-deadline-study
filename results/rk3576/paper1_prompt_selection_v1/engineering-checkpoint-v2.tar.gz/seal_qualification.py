"""Seal the final engineering checkpoint, including retained failed attempts."""
import json
from pathlib import Path
import tarfile
from capture import BASE,OLD,r,sha,platform
from validate import validate
engineering=BASE/'engineering'
assert not (BASE/'qualification-v2.json').exists() and not (BASE/'capture-v1').exists()
for cell in (engineering/'smoke-v6').iterdir():
    if cell.is_dir():
        width,control,mode=cell.name.split('_')
        r.validate(cell,8,True)
        validate(cell,8,mode,control)
for name,marker in [('synthetic-v3.log','PROMPT_SYNTHETIC_PASS'),('baseline-synthetic-v1.log','COMPOSITION_SYNTHETIC_QUALIFICATION_PASS')]:
    text=(engineering/name).read_text()
    assert marker in text and 'ERROR:' not in text,name
numerical=json.loads((engineering/'functional-v4/numerical-check-v2.json').read_text())
assert numerical['all_pass'] and len(numerical['cases'])==18 and all(c['selected'] for c in numerical['cases'])
for w in (320,640):
    cell=engineering/f'functional-v4/{w}_native'
    r.validate(cell,9,True)
    assert len(list(cell.glob('source_*_root.png')))==9
    failure=engineering/f'functional-v4/{w}_release'
    assert not (failure/'godot_frames.jsonl').read_text().strip()
    ev=[json.loads(x) for x in (failure/'selection_events.jsonl').read_text().splitlines()]
    assert ev[-1]['unresolved'] and not ev[-1]['drained']
    assert any(e['event']=='release' and not e['ok'] and 'ENGINEERING_RELEASE_FAULT' in str(e) for e in ev)
sources=[p for p in (BASE/'project').rglob('*') if p.is_file() and '.godot' not in p.relative_to(BASE/'project').parts]
sources += [p for p in BASE.glob('*.py')]
sources += [BASE/'protocol.md',OLD/'run_composition_audit_v1.py',OLD/'engineering/godot/Godot_v4.6.3-stable_linux.arm64',Path('/usr/lib/librknnrt.so')]
sources += [BASE/'project/.godot/extension_list.cfg']
mapped=set()
for mapping in (engineering/'smoke-v6').glob('*/mapped_files.json'):
    mapped.update(json.loads(mapping.read_text()))
assert any('panfrost' in p or 'gallium' in p for p in mapped),'missing actual GPU driver mapping'
assert any('librknnrt' in p for p in mapped),'missing NPU runtime mapping'
sources += [Path(p) for p in sorted(mapped)]
sources += [OLD/f'engineering/models/{w}x{w*9//16}/model.rknn' for w in (320,640)]
record=dict(qualified=True,review_pending=True,scientific_samples=0,
    final_smoke='smoke-v6',native='functional-v4',synthetic='synthetic-v3',baseline_synthetic='baseline-synthetic-v1',
    numerical=numerical,platform=platform(),source_files={str(p):sha(p) for p in sources},
    evidence_files={str(p.relative_to(BASE)):sha(p) for p in sorted(engineering.rglob('*')) if p.is_file()})
with (BASE/'qualification-v2.json').open('x') as f:json.dump(record,f,indent=2)
archive=BASE/'engineering-checkpoint-v2.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    tar.add(engineering,arcname='engineering')
    tar.add(BASE/'qualification-v2.json',arcname='qualification-v2.json')
    for path in sources:
        if path.is_relative_to(BASE):tar.add(path,arcname=str(path.relative_to(BASE)))
print('QUALIFICATION_SEALED',sha(BASE/'qualification-v2.json'),sha(archive),flush=True)
