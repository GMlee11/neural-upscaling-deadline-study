"""Append-only functional native/root and real release-fault qualification."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
BASE=Path('/home/radxa/experiments/paper1-prompt-selection-v1')
OLD=Path('/home/radxa/experiments/paper1-composition-rk3576-v1')
spec=importlib.util.spec_from_file_location('old_runner',OLD/'run_composition_audit_v1.py')
r=importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
ap=argparse.ArgumentParser()
ap.add_argument('--identity',required=True)
a=ap.parse_args()
assert a.identity.replace('-','').isalnum()
out=BASE/'engineering'/a.identity
out.mkdir(exist_ok=False)
for width in (320,640):
    for case in ('native','release'):
        cell=out/f'{width}_{case}'
        cell.mkdir()
        cmd=r.command(dict(width=width,control='always',logging=True),cell,9 if case=='native' else 1)
        cmd[cmd.index('--path')+1]=str(BASE/'project')
        cmd+=['--selection-mode=prompt']
        env=r.environment()
        if case=='native':
            cmd.insert(cmd.index('--'),'res://qualify_prompt_native.tscn')
            # Qualification readback is slow. An expanded acceptance gate ensures
            # pixels are exercised; these data can never be performance evidence.
        else:
            env['PAPER1_ENGINEERING_RELEASE_FAIL_TOKEN']='4' if width==320 else '7'
        (cell/'command.json').write_text(json.dumps(cmd,indent=2))
        with (cell/'run.log').open('x') as log:
            run=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
        log=(cell/'run.log').read_text()
        if case=='native':
            assert run.returncode==0 and 'ERROR:' not in log,log[-4000:]
            matches=[json.loads(line.split('=',1)[1]) for line in log.splitlines() if line.startswith('NATIVE_SOURCE_MATCH=')]
            assert sorted(x['source'] for x in matches)==list(range(9))
            roots=[int(line.split('=',1)[1]) for line in log.splitlines() if line.startswith('NATIVE_ROOT_SAVED=')]
            assert len(roots)>=3 and len(roots)==len(set(roots)),roots
            r.validate(cell,9,True)
        else:
            assert run.returncode==3 and 'ENGINEERING_RELEASE_FAULT' in log and 'prompt native release failed' in log,log[-4000:]
            assert not (cell/'godot_frames.jsonl').read_text().strip()
            events=[json.loads(x) for x in (cell/'selection_events.jsonl').read_text().splitlines()]
            assert any(x['event']=='release' and not x['ok'] for x in events)
            assert events[-1]['event']=='finalize' and not events[-1]['drained'] and events[-1]['unresolved']
            audit=[json.loads(x) for x in (cell/'composition.jsonl').read_text().splitlines()]
            assert audit[0]['errors']
        print('FUNCTIONAL_PASS',width,case,flush=True)
