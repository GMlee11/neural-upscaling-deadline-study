# Independent prompt-selection successor design review

Date: 2026-09-14

Decision: scientifically defensible design; conditional source readiness. No capture approval is given. One concrete failure-evidence defect in the current implementation must be closed, followed by the already planned independent qualification/source/freeze gate.

## Scope and diagnosis

Read the protocol, ordering diagnosis and three current successor source files. Compared the successor main/logger against the retained composition implementation. Ran only the read-only ordering reducer over sealed evidence; no hardware, inference, renderer, qualification or performance run was performed. Only this report was written.

The diagnosis reproduces: all 300 sources in the logged RK3576 lower-resolution always-neural cell encounter the realized ordering gate after 33.33 ms, including all 81 response-eligible sources. Their minimum gate age is 74.943 ms. For source 31, the recorded gate is at 115.446 ms, versus worker receipt at 32.987 ms and first neural pre-draw at 116.798 ms. The 82.459-ms exclusion bound and 1.352-ms gate-to-pre interval follow directly. The source's depth-three loop and final drain support the stated gate construction.

This establishes an application ordering restriction, not CPU idle time, callback availability, an intrinsic NPU/display delay or a counterfactual speedup. The diagnosis explicitly acknowledges the missing callback timestamp and does not backdate composition observations. Those limits are scientifically appropriate.

## Design assessment

The proposed sixteen-cell comparison answers a concrete unresolved question: whether a ready-result presenter improves actual timely source-linked selection relative to the source-ordered recorder on the same qualified implementation. It is not a redundant request for broader hardware evidence. Keeping native computation, slots, depth, profiles, scene, budgets and ownership rules fixed makes the comparison interpretable.

The treatment is the complete declared presentation policy: pre-draw service, oldest-ready order, monotonic neural-source progression, supersession and earlier safe retirement. It is not solely the cost of removing one line or one wait. Changed overlap, occupancy and source pacing are downstream treatment effects. The protocol already limits the claim accordingly. Two balanced-order repetitions in one session support a bounded paired comparison, not independent-device generalization or a decomposition of individual mechanism effects.

The current presenter selects through the audited writer, waits for post-draw before retiring its active source, detaches before checked native consume, and records the disposition before source-ordered telemetry can finish. Receipt-plus-assignment acceptance remains distinct from actual selection age. Superseded/expired sources must remain in the all-source denominator, even when they cannot be shown without regressing the selected neural source. Bicubic controls retain the non-native path. No scheduler extension or positive outcome is needed for this design gate.

## Concrete defect to close before capture

**Presenter failure prefixes are not preserved.** In the inspected `experiments/paper1_prompt_selection_v1/main.gd`, the sole `prompt_presenter.finish()` call is on normal completion at line 1508. `_composition_integrity_failed()` (1527) and `_finalize_composition_on_exit()` (1533) flush only the composition audit. Furthermore, `prompt_presenter.gd::finish()` (93–95) immediately returns false when a queue or active selection remains, before serializing its events.

Counterexample: inject the already specified native release failure on the final prompt source. `retire()` appends its detach/release events, then calls the owner's failure exit before publishing an outcome or removing the queued source. The composition prefix survives, but `selection_events.jsonl` is never written. Merely adding the existing `finish()` call to the exit handler would still discard the buffer because the queued source remains. This loses the new causal/ownership event history precisely in a failed cell that the protocol requires preserving.

Smallest repair: provide one idempotent normal/error presenter finalizer, invoke it on ordinary early exits as well as normal completion, and serialize the existing event prefix plus failure reason and unresolved source/token state even when not drained. Incomplete state must remain failure, never forced success or silently cleared state. Verify write/readback and retain a labeled stderr fallback if persistence fails. Keep hard-kill/power-loss loss explicitly incomplete. Qualify final-source release failure, an outstanding-queue ordinary exit and a write failure through the actual common finalization path. No new scientific run is needed to repair or test this.

## Conditions for the forthcoming checkpoint review

- Supply the planned functional evidence for out-of-order readiness, late arrivals after a newer selection, overwritten/no-draw outcomes, repeated draws, safe slot reuse, expiry, final release error and final drain. Root-pixel/reference checks must inspect the newly selected root output, not a recorder-owned texture variable left over from ordered mode. Reuse unchanged native numerical authority; do not substitute it for validating the new presentation linkage.
- Close the promised event contract before freeze. Currently `before_draw()` does not explicitly timestamp entry/decision, and the event called `recorder_exit` is emitted at line 1880 before terminal construction and the telemetry write at line 2041. Record the actual boundaries or name narrower ones honestly; do not later interpret these timestamps as measured full recorder residence or pre-draw scheduling delay. Apply common-boundary instrumentation consistently across modes, with policy-specific events distinguished as planned.
- Freeze exact source/binary/model identities, sixteen ordered commands, denominators and disposition checks only after qualification. Every selected source must join an eligible generation and validated draw; every submitted source must terminate with a reported selection or nonselection disposition. The old compose/response validator alone is not a complete validator for the new event and supersession contract.

These are bounded implementation/qualification conditions, not optional experiment additions. No further source defect is asserted without an evidence-invalidating counterexample. The complete checkpoint and qualification evidence remain pending; this design review does not claim they have passed.

## Inspected working-byte SHA-256 identities

| File | SHA-256 |
|---|---|
| Prompt-selection protocol | 705dd8dd666afd864cf5c6902179d36d82a2e2c7cb7192158b65e2cf029f6f6d |
| Ordering diagnosis | 688ffea89a0948917a3e40664b62d602668006a64ed31345d60ab3a230c37752 |
| Successor main.gd | dffa88c569eca04911d0318c3642fc9700b5d7a3517b38f3738044723c4231c6 |
| Successor composition_audit.gd | 1c3d099820093c379a060e78849d36281b7b845f228ad04c977bbecb2fa0ec7a |
| prompt_presenter.gd | a4885b4bd0e691728079c34f28b3f4eea7c67646808d045bd2af11bef108eca2 |

## Runner/validator interim review

Date: 2026-09-14. Disposition: qualification checkpoint pending; no freeze/capture GO. The original failure-prefix defect is repaired at source level. Two concrete pre-freeze validation/provenance gaps remain in the inspected runner and validator.

### Confirmed source repairs

The presenter now connects to `SceneTree.process_frame`; the audit's pre-draw callback observes rather than initiating assignment. This is the appropriate distinction to test against actual pixels after the retained pre-draw-assignment failure. Final acceptance still depends on the final source-matched root-pixel qualification, not signal names alone.

The presenter finalizer is idempotent, disconnects its scheduling signal, serializes unresolved source/token state and failure reason, and emits a labeled stderr prefix on persistence failure. Both `_composition_integrity_failed()` and `_finalize_composition_on_exit()` invoke it. The ordinary final-source release-failure path can now retain the new event prefix. `recorder_exit` follows the telemetry write; the earlier timing marker is separately named `recorder_timing_end`. Scheduling/decision events have been added. Full checkpoint evidence remains forthcoming.

### 1. Capture validation can certify false primary outcome fields

`validate.py::validate()` checks some prompt acceptance ages but does not recompute `within_one_frame_at_post` or strict response eligibility from the source clocks and assignment duration. Its `by_source` mapping is created but unused. The inherited ownership validator checks agreement between recorded eligibility flags, not their numerical truth. Prompt decision/detach/process-boundary events can also be absent without rejection despite the declared complete-event contract.

Reproduced without files, hardware or a renderer: supplied one-source JSON records to the actual two validators through an in-memory `Path.read_text` replacement. A structurally valid accepted source had receipt age 50 ms, assignment duration zero, pre-draw age 70 ms and post-draw age 80 ms. Both validators accepted (a) a mutated `within_one_frame_at_post=true`, and (b) matching mutated terminal/telemetry response-eligible flags set true. The same records lacked decision, detach and presenter/pre-draw-entry events entirely and were accepted. These are validator counterexamples, not allegations that the current renderer has emitted false measurements.

Smallest repair: derive and verify timely selection from raw source/post-draw timestamps and strict eligibility from raw worker-receipt/source timestamps plus the actual recorded assignment duration; cross-bind the terminal and telemetry fields in both modes. Validate the required event sequence for accepted and nonselected dispositions, including the decision explaining supersession/expiry, so missing required events cannot produce COMPLETE. Add in-memory mutations covering both false flags, dropped required events and an unjustified nonselection reason. Do not change the deadlines or scientific protocol.

### 2. Freeze construction drops qualification-bound runtime inputs

`capture.py::source_files()` (lines 36–41) excludes the entire `.godot` subtree and enumerates only a small external dependency list. Freeze creation checks `q['source_files']` at lines 55–56 but then stores only a newly constructed `source_files()` map at line 59. Capture and finalization subsequently check that narrower map, not the qualification map.

Concrete counterexamples: the project `.godot/extension_list.cfg` used to load the qualified native extension can change after freeze without a frozen-file mismatch; a resolved runtime dependency present in the qualification closure but absent from the new enumeration can likewise change without detection. A stable package version string does not detect changed library bytes. These are relevant to preserving the numerically qualified executable path, not a request to hash unrelated caches.

Smallest repair: retain the reviewed qualification input closure in the capture freeze, adding the runner/protocol/review/commands without discarding qualified runtime dependencies. Explicitly include the extension-loading configuration and the actual resolved runtime/graphics dependencies used by the accepted build. Check those same bindings before capture and on finalization. Ordinary irrelevant editor caches may remain excluded. Include a disposable mutation check demonstrating that either of the concrete changes above blocks capture before renderer launch.

### Scope of this interim review

The sixteen-cell balanced schedule, explicit commands, disjoint one-shot directory, unchanged core profiles/depth/slots, environment rejection and thermal/timeout stops remain appropriate. No performance experiment, new hardware case, scheduler extension or optional polish is requested. The checks here are source inspection and in-memory validator counterexamples; they neither rerun qualification nor supersede the required final sealed-checkpoint review.

Inspected SHA-256 identities:

| File | SHA-256 |
|---|---|
| capture.py | 7bba7f156266b8f2debfcb01018a44bfbf2f7fbdd9159c5fd682c8c6aef81ee0 |
| validate.py | f0d1449e1a9f1c189ae05a34b63ea66632871ebc2a393cac51dfdc195dc9e37b |
| prompt_presenter.gd | 93c2960b27c34fdc240dc1d9c6a0e47fa75f6daaa9805bbd860c68ac9b67f357 |
| main.gd | 7bd13d0977787957da6e081bc26c0814d24084fd9ce620d63faffd7b22d89933 |
| composition_audit.gd | b42e97e4424738b67cde5f828db20ae3e6cee5b067aa5ea4f408d39fb0726811 |
| Protocol | b845e5dcd8cd0314ca7e629ccab7abee04f6f9851d07fd65fa5c191bc420296c |

## Delivered checkpoint verification

Date: 2026-09-14. Decision: NO GO for capture at this checkpoint. The two runner/validator gaps above remain; no additional blocker is asserted.

Verified qualification SHA-256 `b157aa45a1e118a4c5f32d5e86f7772d8261bb69dc457c29980f2ae43c8f8e1c` and archive SHA-256 `7d50eca7bec20d96a5157f0aaa01f9cadcc31de5257062677217b8f5b9264976` (1,743,777 bytes). All 532 `evidence_files` entries match the archive. The archive contains 581 regular files, including project/source and qualification files in addition to those evidence entries. The archived qualification matches the supplied JSON. Archived main/logger/presenter/runner/validator bytes match the current local counterparts, and available archived qualification source bindings verify.

The delivered checkpoint binds exactly the same capture/validator hashes as the interim review, not repaired versions. All eight saved smoke-v5 cells pass both current validators, which confirms the reported positive checks but does not close their negative-test gaps.

Strengthened the reproduction using the actual sealed `smoke-v5/320_always_prompt` records, changed only in memory. Both production validators still accept each of these independent mutations:

1. Flip a real neural draw's `within_one_frame_at_post` flag without changing its raw timestamps.
2. Flip a real source's terminal and telemetry response-eligibility flags together without changing its measured receipt/assignment age.
3. Remove every `decision` and `detach` event from the selection log.

Thus the issue is not confined to a hand-built toy record. It permits incorrect primary outcome fields or incomplete required provenance to pass the actual capture-completion gates. The freeze still uses the narrower enumeration rather than retaining the qualified dependency closure, and still excludes the extension-loader configuration.

Bounded next action: repair only the validator and freeze-input closure as specified above, preserve this checkpoint and all existing engineering evidence, run the strengthened validator against the saved normal cells and adversarial mutations, and rebind the offline checkpoint for review. Reuse already qualified unchanged native computation and functional evidence; this finding does not itself require another board run or scientific sample. No freeze or capture is authorized by this report.

## V2 repaired checkpoint: final independent decision

Date: 2026-09-14. Reviewed at local HEAD `3db622449307e7e91ef10c0e25cfa54e84f4341c`. This decision binds the exact V2 artifact and executable bytes below; it is not a certification of checkout synchronization or an authorization to alter the frozen inputs. The earlier V1 NO GO remains the disposition of that historical checkpoint.

Decision: GO for prompt-selection freeze and capture

Both previously identified blockers are closed in the delivered V2 checkpoint. No remaining acceptance-relevant blocker was found for this bounded ordered-versus-prompt comparison.

### Exact reviewed identities

| Artifact | SHA-256 |
|---|---|
| `results/rk3576/paper1_prompt_selection_v1/qualification-v2.json` | `8e307a8fa1bec24c737598e47e64dd54fbf4cc6c37459a68bf1d9e0533c99fea` |
| `results/rk3576/paper1_prompt_selection_v1/engineering-checkpoint-v2.tar.gz` | `31da57c2604b5335ddb0d929edcceea362bdff3af670ce80740c97323cb1fd9a` |
| `experiments/paper1_prompt_selection_v1/capture.py` | `3ae9fe6e6bd4cfa113ccedf6913b949705ff80e17f0a1ac78eb0bd4e2cec5262` |
| `experiments/paper1_prompt_selection_v1/validate.py` | `7df9c4d52eed09c6fc7f2a99f3750a63507f47035d00700bb29dd33e8879a686` |
| `experiments/paper1_prompt_selection_v1/bindings.py` | `94b158154986e0aecb7ca51fd298ac3c27920fdf9b166a49cadf462f711ad1ec` |
| `prompt_presenter.gd` | `93c2960b27c34fdc240dc1d9c6a0e47fa75f6daaa9805bbd860c68ac9b67f357` |
| `main.gd` | `7bd13d0977787957da6e081bc26c0814d24084fd9ce620d63faffd7b22d89933` |
| `composition_audit.gd` | `b42e97e4424738b67cde5f828db20ae3e6cee5b067aa5ea4f408d39fb0726811` |

### Decisive verification

- The repaired validator recomputes post-draw freshness from raw timestamps and response eligibility from receipt age plus actual assignment duration. Prompt decisions, process-frame entries, detach/release ordering, disposition reasons and terminal/telemetry joins are enforced. The former false-field and missing-provenance counterexamples are rejected. The focused suite independently reran: **23 passed** with bytecode and pytest cache disabled.
- All eight saved `smoke-v6` cells pass the current production selection validator. Earlier inspection also checked the ownership validator. The current renderer bytes remain those qualified by `functional-v4`; the process-frame presenter, not the rejected pre-draw assignment variant, is bound.
- All **580 evidence-file hashes** match the V2 archive. Its qualification record and inspected executable bytes agree with the delivered checkpoint. All locally read functional evidence used for numerical replay is byte-identical to its archived counterpart.
- The actual offline numerical checker was replayed against saved evidence with its sole output redirected to memory: **18/18 cases pass**, all 18 roots are present, input error is zero, residuals match the ordinary RKNN reference byte-for-byte, and maximum composition and root errors are each **one integer level**. The complete recomputed result equals the qualification's numerical object. No generator or inference was run.
- Saved synthetic/root-pixel checks cover source mapping, out-of-order readiness, expiry and final drain. The retained native-release-failure evidence preserves the selection prefix, failed release and unresolved ownership instead of reporting a successful capture.
- The freeze now merges rather than narrows the qualified **137-file closure**. It includes the extension-loader configuration and mapped EGL/GLES/Gallium/RKNN dependencies; every path in all eight saved mapped-library records is covered. Qualified-input drift is rejected while constructing the freeze and the retained file map is rehashed before capture. The dependency-mutation tests pass.

### Authorized boundary

This approves the reviewed runner for **one immutable freeze followed by one fixed 16-cell, 4,800-source RK3576 ordered/prompt capture**, using the declared two resolutions, bicubic/always controls, alternating two-repetition schedule, unchanged native graph/core/slot profiles and fixed thermal/timeout stops. The final freeze must retain the complete qualified dependency closure, exact commands, platform record, qualification and this review. No capture is authorized on mismatching bytes or a failed freeze check. Existing capture state must refuse reuse; failure is preserved without replacement cells, retuning or rescue runs.

The resulting comparison concerns this implementation's presentation policy, including its changed scheduling/load/overlap. It is not a measurement of intrinsically recoverable NPU latency, GPU completion or panel scanout. All sources, stale/superseded outcomes and failures remain in the denominator; two repetitions in one session are not independent-device evidence. Either a positive or negative timely-selection result is scientifically usable under those boundaries.

No scheduler extension, additional model, new experiment or manuscript claim is approved here. Preserve V1, all earlier captures and the rejected engineering variants. This review performed no board contact, deployment, freeze, capture or physical action; its only persistent change is this appended decision.
