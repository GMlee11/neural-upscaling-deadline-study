# Paper 1 prompt-selection successor V1

Authorized 2026-09-14 after the sealed composition audit and offline ordering
diagnosis. Identity `paper1_prompt_selection_v1`; board workspace
`/home/radxa/experiments/paper1-prompt-selection-v1`. All prior captures,
source trees, freezes and publication packages are immutable.

Question: does removing source-ordered presentation blockage improve timely
source-linked selection in this implementation? This is not an intrinsic NPU
speed claim or a retrospective repair of historical measurements.

## Engineering design and qualification (before measurement freeze)

Use the already qualified opt-in native binary, unchanged width-24 INT8 models,
Godot 4.6.3 and current display stack. Keep pipeline depth three, native slots,
core profiles, native capture holds, fallback, source identity and draw validation.
Add one `ordered`/`prompt` presentation option in a separate renderer source tree.
Ordered keeps the old recorder-driven selection. Prompt queues native-ready
responses for a single-writer process-frame presenter independently of telemetry order,
before canvas state is flushed for the audited draw. Engineering synthetic V1
showed that assignment inside frame_pre_draw itself was too late for the pixels;
the unqualified V1 attempt is retained, not used as scientific evidence.
It selects at most one ready source per draw, processes ready sources oldest-first,
never regresses behind an already selected neural source, and records superseded
responses rather than displaying older neural sources. No ready-result dropping
to manufacture a higher deadline fraction; denominator is all source frames.

The common acceptance score remains worker receipt age plus actual selection
assignment duration, with the existing 100-ms gate; report actual selection age
separately. Do not silently change this acceptance policy to a draw-age gate.
All buffers remain native-owned until completion, are never reused while selected,
and are detached before release after validated post-draw. Results overwritten
before a draw receive no selection credit. Prompt outcomes are recorded in source
order only after presentation/disposition and release complete; logging does not
drive prompt selection. Classical control does not allocate native slots.

Log worker receipt, callback enqueue, pre-draw scheduling decision, assignment,
post-draw, detach/release, and recorder entry/exit in both modes where applicable.
No timing claim for unlogged boundaries. Buffered logs only, same instrumentation
in both modes, with policy-specific events explicitly marked.

Engineering iterations may fix functionality, never tune performance on observed
results. Retain failed fixtures. Qualify parser/startup, source-coded root pixels,
multi-slot reuse, out-of-order ready responses, supersession, repeated draws,
expired responses, release faults and final drain. Reuse prior numerical fixtures
for unchanged native computation, and verify output/reference agreement under
the new presenter. Independent source/protocol/qualification review is required
before freezing the physical comparison. No positive outcome is required.

## Planned fixed comparison (freeze only after qualification)

One RK3576 session, corridor_neon, 30 FPS, both existing resolutions (320x180
to 640x360 and 640x360 to 1280x720), bicubic and always-neural controls. All cells
use logging-on, 20 render warmup frames, existing native warmup, 300 source frames,
and the original per-resolution core profiles and unchanged 100/33.33-ms rules.
Two repetitions per resolution/control/mode, alternating order:

1. 360p bicubic ordered, prompt; 360p always prompt, ordered.
2. 720p always ordered, prompt; 720p bicubic prompt, ordered.
3. Repeat those four pairs with the presentation order reversed.

16 cells / 4,800 source frames; no scheduler extension unless the resulting
evidence makes a specific headline recheck necessary and a new protocol is made.
Report source counts, actual source-linked selection ages/distributions, timely
selected/all-source fraction, receipt eligibility, fallback selection/cadence,
superseded/late/unselected outcomes, source throughput, stage and event timings.
Paired cells are two repetitions in one session, not independent device samples.
Within-mode changes in load, overlap and capture pacing are treatment effects,
not an isolated measurement of one instruction's cost.

Pre-cell <=55 C (up to five-minute cooling); stop >=80 C, ownership/source error,
missing events, incomplete telemetry or 180-second timeout. Preserve all outcomes;
no replacements or performance retuning after freeze. Hash source, binaries,
models, exact schedule, arguments, review and platform state before any physical
performance capture. Freeze accepted engineering checkpoint separately.

Current stage: protocol/implementation engineering, no successor samples taken.
