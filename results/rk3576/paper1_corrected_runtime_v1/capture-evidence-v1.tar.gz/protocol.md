# Paper 1 corrected-runtime reassessment V1

Authorized 2026-09-15. Identity `paper1_corrected_runtime_v1`, with independent
RK3576 and RK3566 freezes/results. This supersedes the earlier advice that the
small correction study alone was sufficient for the main performance comparison.
No scientific samples for this campaign have been collected at registration.

## Purpose and historical disposition

Measure the corrected prompt-presenter system across the manuscript's complete
primary runtime matrix. Verified new results become primary; old runtime data
remain labeled historical implementation evidence, never silently deleted or
pooled. The original comparison and correction experiment remain auditable.
Offline quality/reprojection evidence is unchanged provided numerical inputs and
outputs remain unchanged. Paper 2/3 are outside scope.

These are existing, previously examined workloads: a controlled reassessment,
not fresh untouched confirmation or a new independent generalization set.
Any contrary result changes the paper, not the frozen rules or retained samples.

## Fixed design

On each board, use the qualified corrected process-frame presenter. Preserve
width-24 INT8 models, board-specific native runtime and NPU core profiles,
pipeline depth three, three native slots per context, 30 FPS target, 20 render
warmup frames, existing native warmup, and 300 measured sources per cell.
Runtime acceptance stays 100 ms; primary timely selection is first neural
post-draw age <= 1000/30 ms from matching source capture.

Five original scenes in fixed order: corridor_neon, forest_outpost, barrier_yard,
reflective_plaza, hud_particles. Both inputs: 320x180 and 640x360 (2x output).
Four controls: GPU bicubic, always-neural, fixed-period-2, and the unchanged
renderer_deadline_refresh_v1 scheduler artifact. No unverified runtime Lanczos
row, adverse selector, 60-FPS secondary study or new policy is introduced.

Two repetitions per cell, 80 cells / 24,000 source frames per board. The first
repetition visits scenes and resolutions in the order above, rotating the four
controls by the scene/resolution block index. The second reverses scene,
resolution and each block's control order. The executable schedule is frozen
before capture. Report both repetitions, all scenes and all-source denominators;
do not select the better repetition or manufacture confidence from frames.

Each cell launches a fresh renderer process with fresh policy EWMA, pending and
last-submit/commit state. After the unchanged render warmup, measured source IDs
start at zero; fixed-2 admits exactly even IDs 0,2,...,298. Scheduler admissions
may differ with measured load; do not force matching submission masks. An
audit-only decision event records actual causal inputs and the unchanged
evaluator's decision so a frozen Python reference can independently check it.
Qualification must contain both scheduler admissions and bypasses (or a bounded
synthetic functional fixture if the physical integration produces only one).

## Frozen primary reduction

For each board/resolution/control report ten cells (five scenes, two repeats),
with eligible/selected/timely counts divided by all 3,000 measured sources.
Also report each repetition's 1,500-source totals and all individual cells.
Primary source-capture rate is 299 intervals / elapsed time between the first
and last measured capture starts. Terminal rate uses the analogous 299 terminal
intervals; complete-run throughput is separately 300 / (last terminal minus
first source). Draw rate uses observed draw-count minus one over first-to-last
post-draw time. None is physical panel FPS. All-scene rates are equal-cell
arithmetic means of those per-cell rates, never pooled-duration rates.
Retain per-cell selected-only age medians and counts; no pooled age headline or
frame-as-independent confidence interval. Report NPU submissions/completions,
late/superseded/bypassed complements and mean per-cell service/stage costs with
their actual contributing counts. Freeze this reducer before performance capture.

## Engineering and freeze gates

Use separate board directories; never modify frozen historical workspaces.
No retraining, recompilation, threshold selection, governor/clock sweep or
performance tuning. RK3576 inherits the hash-bound prompt V2 source/numerical/
pixel/ownership qualification, then exercises all 40 scene/resolution/control
combinations with eight sources each as engineering only. Extend the validator
to verify sparse submitted/bypassed sets for fixed and scheduler controls;
do not relax source matching, ownership, expiry or selection validation.

RK3566 requires its own native/pixel/numerical and control integration check
under the corrected presenter before its independent freeze. RK3576 numerical
qualification alone cannot establish RK3566 correctness. Board identity and
actual mapped graphics/NPU runtime files must be captured and hashed.

Bind scripts, project assets including extension loading, native binary, models,
unchanged scheduler, inherited qualification and all mapped libraries. Record
kernel, package versions, CPU/GPU/NPU governors, environment and exact commands.
Independent protocol/source/qualification GO is required before each board's
immutable measurement freeze. Engineering failures may be diagnosed and fixed,
with all attempts retained; they are never scientific performance samples.

## Measurement and failure policy

Before each cell require temperature <=55 C, waiting at most five minutes.
Stop at >=80 C, 180-second cell timeout, source/ownership inconsistency, native
error, incomplete telemetry or frozen-byte drift. Preserve partial output and
terminal status. No replacement cell, performance-conditioned restart or tuning.
A network disconnect does not authorize a restart: inspect whether the original
process completed and recover its retained files first.

Report per-cell/all-scene response eligibility, selected and timely-selected
sources, submissions, bypasses, late/superseded dispositions, actual first-pre/
post ages and source capture/terminal/draw rates. Keep legacy fallback cadence
labeled separately from source-linked selection. No physical scanout, energy,
intrinsic NPU limit, isolated chip-speed or isolated-wait claim. Selected-only
age summaries always include selected counts and excluded dispositions.

After independent outcome verification, replace manuscript primary runtime
tables/prose with this corrected implementation's results and retain a concise
historical/correction narrative. If one board cannot be run, do not silently
represent its historical implementation as corrected-system replication.
