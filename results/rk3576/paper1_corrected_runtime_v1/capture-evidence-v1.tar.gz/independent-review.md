# Paper 1 corrected-runtime V1: independent protocol review

Date: 2026-09-15.

Decision: PASS DESIGN for implementation and qualification; NOT capture approval

Reviewed protocol: `docs/paper1_corrected_runtime_v1.md`, SHA-256 `73c0fcf5bdd8c4dc29eac5944680c518041f3987b22a4d42a5811922d788da73`, inspected at local HEAD `9f6e6cc3df721f70524d06a4fb2e2fac1d16e7f8`. This verdict covers the protocol, not the runner or qualification checkpoint being developed concurrently. Each board still requires independent source/qualification review and explicit GO before its immutable measurement freeze and capture.

## Scientific assessment

The proposed primary question is appropriate: how does the corrected, source-linked prompt-presenter system perform across the complete five-scene, two-resolution, four-control primary matrix? Five scenes x two resolutions x four controls x two repetitions gives **80 cells and 24,000 measured sources per board**. Separate RK3576 and RK3566 freezes/results are necessary and correctly specified. Neither raw timings nor samples should be pooled between boards.

Making verified corrected-system results primary is scientifically defensible. The old runtime campaign remains evidence about its historical implementation; the sealed 16-cell ordered/prompt study remains the controlled repair narrative. Neither should be silently relabeled as corrected-system data or used to fill missing corrected cells. Contrary outcomes must change the manuscript rather than trigger policy tuning, substituted cells or selective reporting.

These previously examined workloads support reassessment and within-workload control comparisons, not untouched confirmation. Reversing block/control order in the second repetition and retaining all cells is a reasonable bounded design. It does not establish cross-session robustness, eliminate all thermal/order effects, or turn source frames into independent experimental replicates. No additional scenes, boards, controls, power study or third repetition is required by this protocol review.

The primary deadline boundary is correctly fixed to **first source-matched neural post-draw age <= 1000/30 ms**, with all measured source frames in the denominator. Receipt-plus-assignment eligibility, the unchanged 100-ms acceptance score, actual selection age, and historical fallback cadence remain distinct. Selected-only age distributions must retain their selected counts and late/superseded/bypassed complements. The study estimates complete corrected-system/control behavior, not isolated wait cost, intrinsic NPU limitations, scanout, or chip-speed superiority.

## Two bounded specifications to close before source/qualification GO

### 1. Freeze cell initialization and exact sparse-control semantics

The protocol freezes the scheduler artifact and asks for submitted/bypassed-set validation, but does not explicitly fix the per-cell reset and fixed-period phase. These affect the scientific treatment, not just implementation detail.

The inherited source uses `frame_id % neural_refresh_period_frames` for fixed-period admission and state such as `neural_service_ewma_ms`, `last_submitted_neural_frame`, pending requests, and workload-specific initial service for scheduler decisions. An artifact hash alone cannot distinguish a fresh cell from a cell carrying state from a previous scene/control, or an altered measured-frame phase.

Smallest closure: in the runner/source checkpoint, freeze a fresh renderer/policy state per cell (or demonstrably identical explicit initialization), the measured source origin, warmup-to-measurement transition, deterministic scene replay, and fixed-2 phase. Preserve the inherited phase: measured even IDs 0,2,...,298 are due, not whichever phase happens to yield better timing. Bicubic must submit no neural work; always must attempt all measured sources; fixed-2 must partition the 300 IDs into its prescribed 150 due and 150 bypassed sources. Submitted/completed/released/selected/late/superseded sets must reconcile without crediting bypasses as neural results.

For the frozen scheduler, verify logged decisions against its actual decision inputs/state and unchanged evaluator; do **not** require the same submission mask across repetitions or boards, since measured service/load legitimately changes its decisions. Qualification must exercise or synthetically cover both admission and bypass, including final drain and sources with no neural callback. Eight-source engineering cells are useful integration checks, but a naturally all-bypassed scheduler cell alone does not qualify its admission path. This is bounded functional coverage, not a request for added performance measurements or a changed scheduler.

### 2. Freeze the primary all-scene reduction before capture

The current instruction to report per-cell/all-scene quantities leaves rate and age aggregation unspecified. Unequal elapsed durations and unequal selected populations can make pooled rates, means of rates, pooled medians and medians of medians materially different.

Smallest closure: bind the analysis rules with the source/qualification freeze. For each board, resolution and control, report the five-scene/two-repeat eligible and timely counts over **3,000 source frames**, alongside the ten individual cells. Retain repetition-specific results. Use explicit timestamp boundaries for capture, terminal and draw rates; for capture rate, the inherited 299 intervals between 300 source starts must not be confused with 300/elapsed or panel FPS. Specify one fixed all-scene rate reduction, such as the equal-cell mean of those rates, and use it consistently. Retain per-cell selected-age medians/counts; any additional pooled age statistic must be labeled selected-only and its pooling rule frozen. No confidence interval or significance claim should treat the 3,000 frames as independent trials.

These two items can be resolved in the coming runner/analysis specification and executable tests. They do not require expanding the authorized matrix. They remain conditions of a later capture GO, not grounds to abandon the design.

## Qualification, preservation and release boundary

The proposed source/library closure and RK3576 inheritance are appropriate provided the exact approved presenter, model, native computation and numerical/pixel identities verify. The RK3566 native/pixel/numerical and control integration qualification is indispensable; RK3576 results alone cannot establish it. A failure must remain a qualification failure, not be bypassed to reach the primary campaign. No new training or numerical threshold is justified.

Retain the existing no-replacement, thermal/timeout, incomplete-evidence and drift stops. A partial board campaign must be identified as incomplete; completed cells may be preserved and described with that missingness, but cannot be presented as the full corrected matrix or completed replication. Network recovery may retrieve the existing attempt, not launch another one. All command/schedule/control identities, qualified dependencies and source checks must survive the final freeze. Actual implementation and failure-path adequacy remain for the requested later source review.

Offline quality and reprojection evidence can remain unchanged and separately labeled because the correction changes presentation policy, not the already evaluated reconstruction. It does not prove that those offline quality gains are displayed in this new campaign. If qualification instead finds changed numerical inputs, outputs or reconstruction semantics, that inheritance must be reassessed before using it.

Maximum next step under this review: implement the fixed runner/reducers and complete the already authorized, separately controlled engineering qualification, then submit exact source, protocol, schedule, closure and qualification evidence for independent review. **No freeze or scientific capture is approved here.** This reviewer performed no board access, runner/generator execution, inference or physical action. Only this report was created; the frozen prompt study, prior reviews, manuscripts and evidence were not modified.

## Interim RK3576 source review — before completed qualification

Date: 2026-09-15. This addendum reviews the implementation supplied while engineering smoke was still running. It does not treat the unreceived complete qualification/source closure as inspected.

Decision: NOT READY for final source/qualification GO — two bounded gaps

The two protocol specifications are now present. The schedule contains 80 unique cells and exactly reverses the first 40 for repetition two; every cell starts a fresh subprocess. Fixed-2 validation requires the exact even-source set and odd-source fallback routes. Scheduler validation independently evaluates the unchanged policy and reconstructs last-submit, recorded accepted-terminal state and service EWMA. The reducer fixes all-source totals, per-repetition groups, equal-cell rate means and per-cell selected-only medians. The renderer diff is limited to decision/observation logging, and removal of that addition restores the qualified predecessor text. The copied evaluator and policy bytes match their canonical originals. Independently reran the design/reference-policy suite: **14 passed**.

Inspected SHA-256 identities:

| File | SHA-256 |
|---|---|
| Protocol | `57384fddb3d617e421f5bd33b822f01594904b2fdc25bf4ea568e5b9dc69dd43` |
| `run_rk3576.py` | `46c02aa69e465fc29d4d4fb843af8c2916fbf8bc96d9002ba52802ff4cd5db8d` |
| `validate.py` | `319790d4e0b2f239440c1362c3023181ceea13568f75e5111e0747880e1e840a` |
| `report.py` | `e109af9eaf608280c96d0301d8de9b7332bbce526145eaa82683983ca234f460` |
| `main.gd` | `3567b490b43369d3978ee6c8f65ff1f94a0cfad5f4ebcf634f5b0b8e137abb37` |
| `design.py` | `9cd287d1644ec983f88ce3a3d0a678d90547a1256ad6918fe7a0f2d29aba8eec` |

### 1. Unchecked pre-draw age reaches the published reduction

`report.py:39,42` consumes `age_at_pre_ms` directly for timely-pre counts and age summaries. The current `validate.py` draw loop recomputes post-draw age but never checks the stored pre-draw age against `pre_draw_usec` and the matching source capture. The inherited ownership validator likewise does not check that derived pre-age field.

Concrete in-memory reproduction, using the immutable prior capture cell `02_320_always_prompt`: the new production `cell_report` returns 31 timely-pre sources on the original data. Change only each neural draw's `age_at_pre_ms` to 0.0, leaving all raw timestamps, source identities and post-draw records unchanged. The new validator still passes and `cell_report` returns **300** timely-pre sources; timely-post remains 6. No evidence file was edited.

Smallest repair: derive pre-draw age from raw timestamps in the reducer, and reject a conflicting stored value in validation using the existing clock tolerance. Keep the current post-draw check. Add this real-record mutation as a regression test. This changes neither the renderer nor any sample and requires no board run.

### 2. Qualification sealing is not yet tied to the exact complete engineering run

In `run_rk3576.py:60` onward, engineering execution does not retain/check a new-source start identity; its post-run frozen-file check is conditional on a scientific `frozen` argument. In `main`'s `qualify` branch (`:140–157`), source hashes are first taken from the current files when sealing. The branch also accepts `COMPLETE` plus a 40-element cell list without enforcing the unique expected 40-cell schedule/commands and without verifying the existing engineering `sha256.json` before constructing a new evidence-hash map.

Two concrete consequences follow from that call path: (a) changing the new project/evaluator/runner bytes after engineering but before `qualify` can bind those unexercised bytes to old passing records; (b) repeating a valid cell record 40 times satisfies the length check and repeatedly validates the same directory, without proving the required scene/resolution/control matrix. The final scientific-capture schedule check in `report()` does not close this earlier qualification gate.

Smallest repair: bind the exercised new source/commands to engineering start evidence and verify the same identity at completion/sealing; verify the saved engineering file manifest; require each expected schedule tuple, unique directory, command and scene to match the 40-cell design exactly. Refuse drift, substitution, duplicates or missing cells before publishing `qualified=true`. Use bounded disposable/static fixtures for after-engineering source mutation and duplicated/missing/swapped cells. If the running smoke already has independently retained pre-run deployment hashes and exact command evidence, those may establish the missing binding when verified; this finding does not by itself require rerunning otherwise adequately bound engineering evidence. Do not manufacture a pre-run identity retrospectively.

These are validation/provenance gaps, not evidence that a physical smoke cell failed or that the design question is unsound. No further mechanism, performance campaign or governance system is requested. The complete 40-cell evidence and exact final source closure remain pending, including proof of scheduler admission/bypass functional coverage. Final RK3576 freeze/capture GO remains withheld; RK3566 remains a later, separately qualified board phase. Only this review addendum was written, with no board access or changes to prior freezes or evidence.

## Delivered engineering checkpoint review

Decision: NO GO for freeze/capture on the supplied checkpoint; repaired qualification pending

Verified the supplied qualification SHA-256 `a3b3dfc6dd0f8f8f8d15bd07703480c12a5049d669b9f9d76ccb95aea7919f17` and engineering archive SHA-256 `006555a31913ccb05a32d9c89b96460583a0822c9ba25d3078e3344e6040dc9f`. The archived qualification matches the delivered JSON. All **362 qualification evidence bindings** match the archive and local expanded evidence; these comprise the **361 engineering manifest entries plus the manifest itself**. This is not a discrepant sample count.

Independent reconstruction confirms all 40 unique intended smoke-v2 scene/resolution/control cells in the exact one-repetition schedule. All 40 saved cells pass the inspected control/ownership-selection validation and per-cell reduction. Across the ten scheduler engineering cells, **35 sources are submitted and 45 bypassed**; both functional paths are exercised. No favorable-performance selection was used in this review. The delivered 190-file qualification map and source bytes were inspected; available archived files under the new workspace prefix match their recorded hashes.

The supplied packet still binds the same runner, validator and reducer hashes listed in the interim findings. Thus its pre-draw derived-field counterexample and absent engineering-start source binding are not repaired merely by the completed positive smoke. The actual unique 40-cell matrix is now independently verified; that closes the duplicate/missing-cell concern for these delivered data, but does not supply the missing pre-run source provenance or repair the sealing gate for another packet. The retained smoke-v1 source archive shows the final runner adds the policy-copy identity guard and extends its file enumeration; its presence alone is not a timestamped, hash-verified start record for smoke-v2.

During this review, concurrent local edits changed the runner/validator/reducer away from the delivered qualification. The new local validator rejects an impossible negative pre-draw age, and the runner now references an engineering-start verifier and `qualification-v2.json`. These are prospective repairs, not bytes authenticated by the supplied `a3b3...` qualification. They have not received a final source/qualification verdict here.

Bounded next step: preserve this packet, finish the two specified repairs, establish the engineering source/command binding using genuine retained start evidence or a separately identified functional qualification if that evidence is unavailable, and deliver the new exact qualification/archive/closure for review. Revalidate the unchanged saved numerical and control evidence where its provenance permits reuse; do not rerun performance or fabricate earlier provenance. No new scientific experiment or expanded matrix is requested. This report does not authorize a freeze or capture, and does not call the completed smoke a scientific failure.

## Final RK3576 source-bound qualification V2 review

Date: 2026-09-15.

Decision: GO for RK3576 corrected-runtime freeze and capture

This decision applies only to the repaired source and fresh **smoke-v3** qualification identified below. It supersedes the pending verdict for this successor, not the findings or disposition of the preserved earlier packet.

| Artifact | SHA-256 |
|---|---|
| `qualification-v2.json` | `7a0d34bbb78cff40b879b2c417a5ec750cf9c8f4b031435a9e2f4a590e894c25` |
| `engineering-evidence-v2.tar.gz` | `874c43b4601322a69275a0b3bf0346fa994c45b46cec3b623ecbe9812673116a` |
| smoke-v3 `start.json` | `64d46328c7528bb4f4caf895d476db9acc7e6ca91a742fab4043d743f266ba4e` |
| smoke-v3 `terminal.json` | `297ad3e125fdfcc6fd8cf4440695326f33a3a014790039c1b603473f5e81cafb` |
| `run_rk3576.py` | `f956445250baf002dfc404729e87c555ab5ad754931c76b6c2c019a9e62e03b8` |
| `ledger.py` | `554510648c4ba09a9a5240c68fcd7fcba29d6a5caee83951218f16472cb1a04c` |
| `validate.py` | `6d6dbe486ffab383eacdb4dafc012d4993b62ef455689ab28ceba61f9d658334` |
| `report.py` | `b9bff89f812df1980bb48642237f05b6ce61f902f32bf855f5d2070db0502f94` |

### Independent evidence checks

Verified both delivered artifact hashes and exact archived/local qualification equality. All 414 regular archive members match the expanded files, without duplicate member names. All **363 qualification evidence bindings** verify: the **362 engineering manifest entries plus the manifest itself**. The exact manifest file set and every digest match.

The start record binds 191 files, the full ordered schedule, commands, platform and relevant environment before the first cell is launched in the reviewed execution path. The terminal binds that start hash, records COMPLETE, and reports no source drift. All 191 start bindings agree with qualification. Of the qualification bindings, 49 are independently rehashed against supplied successor files and 142 agree with the previously examined inherited bindings, including the unchanged extension-loader configuration. All 83 observed mapped-library paths are already present with matching hashes in the start closure; they are not newly introduced only at sealing. The local repaired executable, policy, protocol and renderer bytes match the supplied archive. Old qualification and archive hashes remain unchanged.

Independently reconstructed all 40 commands from the authenticated inherited command constructor and current command adaptation, rather than accepting the start command list as its own reference. Exact schedule tuples, order, directory identities, scene telemetry and commands match. All 40 cells pass both the inherited saved-record validator and repaired control/ownership validator and reducer. The production engineering ledger checks also pass with a read-only local path adapter: Linux path spelling is preserved, and board-absolute source reads are replaced only by the archive/inherited-binding verification described above. No board validation was performed.

The ten scheduler cells contain **37 submitted and 43 bypassed sources**, exercising both branches with decisions checked against logged state and the unchanged evaluator. Maximum recorded engineering temperature is 54.538 C. These are functional qualification checks, not a favorable-performance selection or a scientific result.

### Closure of the two findings

The validator now independently recomputes pre-draw and post-draw ages from matching raw source/draw timestamps; the reducer also derives both rather than trusting stored derived ages. The real-record pre-age mutation is rejected.

The runner now writes the source/command start binding before any cell, checks bound files at completion, and the qualification path verifies the original start identity, complete evidence manifest, exact 40-cell sequence, unique directories, commands and scenes. This fresh run establishes the missing provenance without retrospectively inventing a smoke-v2 start record. Source drift and duplicate, missing, swapped or substituted commands/cells are rejected in disposable tests. Independently reran the corrected-runtime, reference-policy and prompt-selection suites: **47 passed**.

No acceptance-relevant source/qualification blocker remains for this exact RK3576 packet. The unchanged presenter/native/model identities retain the already examined numerical and pixel qualification; the audit-only decision logging and fixed controls do not justify another numerical or performance experiment before the prescribed capture.

### Authorized boundary

This GO permits the reviewed runner to create its exact qualification-bound RK3576 freeze and execute the single prescribed 80-cell, two-repetition capture: five existing scenes, two resolutions, four controls, 300 measured source frames per cell. It does not permit retuning, replacement runs, expanded workloads, weakening drift/thermal/timeout checks, pooling historical campaigns, or a claim of untouched generalization. Preserve and report any failed or incomplete campaign under the protocol. This approval is invalid for changed qualified bytes or a substituted qualification.

RK3566 remains pending its own numerical/pixel/control qualification and independent approval. Engineering success does not establish the scientific deadline outcome. This reviewer performed no board access, inference, generator, freeze or capture; only saved-evidence/static checks and disposable tests were run, and only this review was appended.
