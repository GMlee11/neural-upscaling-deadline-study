"""Append-only RK3576 engineering, qualification, freeze and one capture."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

from design import schedule, cell_name, adapt_command
from validate import validate
from ledger import verify_engineering

BASE = Path('/home/radxa/experiments/paper1-corrected-runtime-v1')
PRIOR = Path('/home/radxa/experiments/paper1-prompt-selection-v1')
sys.path.insert(0, str(PRIOR))
spec = importlib.util.spec_from_file_location('prior_capture', PRIOR / 'capture.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
EXPECTED_PRIOR_FREEZE = 'c4d733744e3ce10305d16155bc00cb3bbff41871c558b1857d6cd55f416598c8'


def dump(path, payload):
    with path.open('x') as stream:
        json.dump(payload, stream, indent=2)


def inherited():
    assert sha(PRIOR / 'freeze.json') == EXPECTED_PRIOR_FREEZE
    frozen = json.loads((PRIOR / 'freeze.json').read_text())
    p.verify(frozen['files'])
    assert p.platform() == frozen['platform'], 'prior platform drift; requalification required'
    assert sha(BASE / 'policy.json') == sha(p.OLD / 'engineering/repo/results/models/rk3576_neural_refresh_paper1_v1.json')
    return frozen


def command(row, target, frames):
    cmd = p.r.command(dict(row, logging=True), target, frames) + ['--selection-mode=prompt']
    return adapt_command(cmd, row, BASE / 'project')


def environment_identity():
    env = p.r.environment()
    # Bind experiment settings, not transient SSH/session fields or secrets.
    return {key: env.get(key) for key in ('DISPLAY', 'XAUTHORITY', 'LD_LIBRARY_PATH',
            'OMP_NUM_THREADS', 'MESA_LOADER_DRIVER_OVERRIDE', 'LIBGL_ALWAYS_SOFTWARE',
            'GALLIUM_DRIVER', 'EGL_PLATFORM', 'DRI_PRIME')}


def files():
    paths = [path for path in (BASE / 'project').rglob('*')
             if path.is_file() and '.godot' not in path.relative_to(BASE / 'project').parts]
    paths += [BASE / name for name in ('run_rk3576.py', 'design.py', 'validate.py', 'report.py', 'ledger.py', 'neural_refresh_policy.py', 'policy.json', 'protocol.md', 'project/.godot/extension_list.cfg')]
    paths += [p.OLD / 'engineering/repo/results/models/rk3576_neural_refresh_paper1_v1.json', PRIOR / 'freeze.json']
    return {str(path): sha(path) for path in paths}


def execute(target, repetitions, frames, frozen=None):
    target.mkdir(parents=True, exist_ok=False)
    state = dict(protocol='paper1_corrected_runtime_v1', board='rk3576', status='RUNNING',
                 engineering=frozen is None, cells=[], frames_per_cell=frames)
    if frozen:
        state['freeze_sha256'] = sha(BASE / 'freeze.json')
    bound = frozen['files'] if frozen else p.merged(inherited()['files'], files())
    if frozen is None:
        dump(target / 'start.json', dict(files=bound, schedule=schedule(repetitions),
             commands=[command(row, target/cell_name(i,row), frames) for i,row in enumerate(schedule(repetitions))],
             platform=p.platform(), environment=environment_identity()))
        state['start_sha256'] = sha(target / 'start.json')
    temperatures = lambda: int(Path('/sys/class/thermal/thermal_zone0/temp').read_text()) / 1000
    try:
        for index, row in enumerate(schedule(repetitions)):
            cell = target / cell_name(index, row)
            cell.mkdir()
            argv = command(row, cell, frames)
            if frozen:
                assert argv == frozen['commands'][index]
            dump(cell / 'command.json', argv)
            record = dict(row, index=index, status='STARTED', directory=cell.name)
            state['cells'].append(record)
            deadline = time.monotonic() + 300
            while temperatures() > 55:
                assert time.monotonic() < deadline, 'cooling timeout'
                time.sleep(1)
            libraries = set()
            with (cell / 'stdout.log').open('x') as stdout, (cell / 'stderr.log').open('x') as stderr, (cell / 'system.jsonl').open('x') as system:
                start = time.monotonic()
                process = subprocess.Popen(argv, env=p.r.environment(), stdout=stdout, stderr=stderr)
                try:
                    while process.poll() is None:
                        temperature = temperatures()
                        system.write(json.dumps(dict(monotonic=time.monotonic(), temperature_c=temperature)) + '\n')
                        system.flush()
                        assert temperature < 80 and time.monotonic() - start < 180, 'thermal/timeout stop'
                        if frozen is None:
                            try:
                                for line in Path(f'/proc/{process.pid}/maps').read_text().splitlines():
                                    fields = line.split(None, 5)
                                    if len(fields) == 6 and fields[5].startswith('/') and Path(fields[5]).is_file():
                                        libraries.add(fields[5])
                            except FileNotFoundError:
                                pass
                        time.sleep(.1 if frozen is None else .5)
                    assert process.returncode == 0, ('renderer exit', process.returncode)
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
            if frozen is None:
                dump(cell / 'mapped_files.json', sorted(libraries))
            assert 'ERROR:' not in (cell / 'stderr.log').read_text(), 'renderer error'
            p.r.validate(cell, frames, True)
            record.update(validate(cell, frames, 'prompt', row['control']), status='COMPLETE')
            telemetry = [json.loads(line) for line in (cell / 'godot_frames.jsonl').read_text().splitlines()]
            assert all(f['scene_variant_id'] == row['scene'] for f in telemetry), 'scene mismatch'
            dump(target / f'progress-{index:02d}.json', state)
            print('COMPLETE', index + 1, len(schedule(repetitions)), cell.name, flush=True)
        state['status'] = 'COMPLETE'
    except BaseException as error:
        state.update(status='FAILED', error=repr(error))
        raise
    finally:
        changed = [name for name, digest in bound.items() if not Path(name).is_file() or sha(Path(name)) != digest]
        if changed:
            state.update(status='FAILED', changed_files=changed)
        dump(target / 'terminal.json', state)
        dump(target / 'sha256.json', {str(path.relative_to(target)): sha(path) for path in sorted(target.rglob('*')) if path.is_file()})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('phase', choices=('engineering', 'qualify', 'freeze', 'capture'))
    ap.add_argument('--identity', default='smoke-v1')
    args = ap.parse_args()
    assert args.identity.startswith('smoke-') and args.identity.replace('-', '').isalnum()
    original = inherited()
    if args.phase == 'engineering':
        execute(BASE / 'engineering' / args.identity, 1, 8)
    elif args.phase == 'qualify':
        engineering = BASE / 'engineering' / args.identity
        start = verify_engineering(engineering, schedule(1),
                    [command(row, engineering/cell_name(i,row), 8) for i,row in enumerate(schedule(1))])
        assert start['platform'] == p.platform() and start['environment'] == environment_identity()
        terminal = json.loads((engineering / 'terminal.json').read_text())
        assert terminal['status'] == 'COMPLETE' and len(terminal['cells']) == 40
        for record in terminal['cells']:
            cell = engineering / record['directory']
            p.r.validate(cell, 8, True)
            validate(cell, 8, 'prompt', record['control'])
        mapped = set()
        for path in engineering.glob('*/mapped_files.json'):
            mapped.update(json.loads(path.read_text()))
        assert any('gallium' in path or 'panfrost' in path for path in mapped)
        assert any('librknnrt' in path for path in mapped)
        closure = p.merged(start['files'], files())
        closure = p.merged(closure, {name: sha(Path(name)) for name in mapped})
        dump(BASE / 'qualification-v2.json', dict(qualified=True, engineering_identity=args.identity,
             inherited_freeze_sha256=EXPECTED_PRIOR_FREEZE, files=closure, platform=p.platform(),
             evidence={str(path.relative_to(BASE)): sha(path) for path in engineering.rglob('*') if path.is_file()}))
        print('QUALIFIED', sha(BASE / 'qualification-v2.json'), flush=True)
    elif args.phase == 'freeze':
        assert not (BASE / 'capture-v1').exists()
        q = json.loads((BASE / 'qualification-v2.json').read_text())
        assert q['qualified'] and q['platform'] == p.platform()
        review = BASE / 'independent-review.md'
        assert 'Decision: GO for RK3576 corrected-runtime freeze and capture' in review.read_text()
        closure = p.merged(q['files'], {str(review): sha(review), str(BASE / 'qualification-v2.json'): sha(BASE / 'qualification-v2.json')})
        dump(BASE / 'freeze.json', dict(protocol='paper1_corrected_runtime_v1', board='rk3576',
             created_utc=datetime.now(timezone.utc).isoformat(), files=closure, platform=p.platform(),
             environment=environment_identity(), schedule=schedule(),
             commands=[command(row, BASE / 'capture-v1' / cell_name(i, row), 300) for i, row in enumerate(schedule())]))
        print('FROZEN', sha(BASE / 'freeze.json'), flush=True)
    else:
        frozen = json.loads((BASE / 'freeze.json').read_text())
        assert frozen['protocol'] == 'paper1_corrected_runtime_v1' and frozen['schedule'] == schedule()
        assert frozen['platform'] == p.platform()
        assert frozen['environment'] == environment_identity()
        p.verify(frozen['files'])
        execute(BASE / 'capture-v1', 2, 300, frozen)


if __name__ == '__main__':
    main()
