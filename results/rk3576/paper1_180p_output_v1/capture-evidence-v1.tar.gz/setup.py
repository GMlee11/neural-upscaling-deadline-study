"""Board-local setup: immutable predecessor read, new project copy only."""
from pathlib import Path
import hashlib
import json
import shutil

BASE=Path(__file__).resolve().parent
PRIOR=Path('/home/radxa/experiments/paper1-corrected-runtime-v1')
assert BASE==Path('/home/radxa/experiments/paper1-180p-output-v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=PRIOR/'freeze.json'
assert sha(freeze)=='fb16207b3de5b2416c60f2715cc321c16d0f1c1fbbe822ac88de9bb974dde6e3'
bound=json.loads(freeze.read_text())['files']
for name,digest in bound.items():
    assert sha(Path(name))==digest,name
for name,digest in json.loads((BASE/'package-sha256.json').read_text()).items():
    assert sha(BASE/name)==digest,name
shutil.copytree(PRIOR/'project',BASE/'project',ignore=shutil.ignore_patterns('.godot'))
(BASE/'project/.godot').mkdir()
shutil.copyfile(PRIOR/'project/.godot/extension_list.cfg',BASE/'project/.godot/extension_list.cfg')
shutil.copyfile(BASE/'main.gd',BASE/'project/main.gd')
(BASE/'engineering/display').mkdir(parents=True)
print('NEW_WORKSPACE_READY; old freeze and package hashes verified')

shutil.copyfile('/home/radxa/experiments/paper1-composition-rk3576-v1/engineering/numerical-v3/reference', BASE/'reference_quantized_input')
(BASE/'reference_quantized_input').chmod(0o755)
