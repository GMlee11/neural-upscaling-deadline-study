# RK3576 platform qualification appendix

2026-09-24, before RK3576 engineering or scientific samples at 180p output.
The registered `paper1_180p_output_v1` protocol remains unchanged. The RK3566
result has been viewed, but no outcome-based workload, policy, threshold or
sample-count change is made for this second board.

Use the existing RK3576 corrected presenter and exact inherited composition
native source, with only the new renderer resolution/policy entry and the
byte-preserving 960x45 input-view adapter already qualified on RK3566. Retain
source/binary before adaptation. RK3576 uses its original
`PAPER1_COMPOSITION_AUDIT` build, not `PAPER1_TARGET_RK3566`.

Explicitly inherit `single_dualcore_01` from the old 320x180-input/360p-output
case, not the old runner's width-based default for 720p. Three slots, depth
three, 30-Hz target, source-capture and post-draw timing definitions unchanged.
The earlier core profile and policy are not retuned using RK3566 results.

Start a separate authenticated Xorg display :2, with GPU rendering verified.
The first startup failed because the idle GDM greeter held DRM master; no user
desktop was logged in. Retain those logs, temporarily stop the greeter, then
restore it after capture. The successor display uses `engineering/display-v2`;
no authentication cookie is archived. Bind the exact resulting display
environment. The first functional preflight stopped before execution because
the earlier freeze included Mesa's mutable shader-cache index. All other
inherited hashes match. Record old/current index hashes; exclude only that
known regenerable cache directory from immutable inputs/mapped dependencies.
Do not restore, delete or alter historical evidence to force a hash match.
This is not a model/library exemption or cache-disable performance change.
Use the existing ordinary RKNN reference executable,
copied into the new workspace without altering its source or invocation
semantics. All model, platform and source identities must pass verification.

Run nine constant-source and nine source/coordinate-coded native cases, with
the same numerical tolerances and fixture-only expanded readback allowance.
Run all twenty eight-source scene/control checks. Discover libraries first,
then bind them before the accepted pass. Independent approval precedes freeze
and the sole 40-cell / 12,000-source scientific campaign. Engineering repairs
remain append-only and are not performance evidence.

This is a new session, model shape, input-view adapter and display session.
Cross-resolution/device comparisons remain descriptive, not isolated causal
effects. No scanout, energy, quality-generalization or native-720p claim.
