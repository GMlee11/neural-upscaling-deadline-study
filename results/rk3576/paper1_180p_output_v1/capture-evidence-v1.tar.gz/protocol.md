# Paper 1: 180p-output operating-range extension V1

Registered 2026-09-24 before new compilation or physical samples. Identity:
`paper1_180p_output_v1`. Author authorized the extension; RK3566 runs first.

## Question and scope

Does reducing native input to 160x90 and reconstructed output to 320x180
increase timely neural selection in the existing corrected presenter? This is
an operating-range extension, not a novelty remedy or a search for a favorable
resolution. No further resolutions are authorized. Existing 360p/720p results,
failed predecessors, source graphs, weights and public artifact remain unchanged.
New results stay separate; no pooling across boards, resolutions or sessions.

## Fixed conditions

Each board: five existing scenes (corridor_neon, forest_outpost, barrier_yard,
reflective_plaza, hud_particles), four controls (bicubic, always, fixed2,
scheduler), two repetitions, 300 measured sources/cell: 40 cells and 12,000
sources. First repetition rotates controls by scene index; second exactly
reverses the first schedule. Fresh renderer/policy state each cell; 20 render
warmup frames, inherited native warmup, 30 Hz, pipeline depth three, three
native slots/context, 100-ms runtime acceptance score. Root/window stays
1280x720 as in predecessor: the 320x180 reconstruction is scaled for display.
Do not call this native 720p neural reconstruction or physical scanout.

Fixed2 admits even measured IDs; bicubic none; always all. Add only
`mode_90p_to_180p` to renderer modes. The successor policy copies the existing
30-Hz `mode_180p_to_360p` workload parameters verbatim under the new mode ID
(initial service 30 ms, refresh period two, maximum age three). Evaluator,
EWMA, margins, priority and all old workload entries stay unchanged. This is
a preregistered workload extension, not the identical historical policy file
and not a calibrated/optimized 180p policy. No timing-based threshold changes.

## Model and compilation

Unchanged width-24 INT8 source ONNX SHA-256
`1584c69f7d098bd82d7c02b9b7406a32e56dbea7eb4964d291d6ad97fc094377`.
RKNN Toolkit2 2.3.2, optimization level three, mean zero/std 255,
NCHW 1x3x90x160, quantization enabled. Reuse the exact 200-image ordered
calibration list from the accepted 320x180 export; do not select new images.
Compiler resizing is fixed by that accepted toolkit workflow. Record every
image hash, original list hash, compiler wheel/package/environment identity,
command, stdout/stderr, compiled file and quantization metadata. Separate
RK3566/RK3576 exports. No retraining or compiler/precision strategy shopping.
New shape quantization may change scales; do not assume cross-shape byte identity
or claim unchanged deployed image quality without measuring it.

## Qualification before performance

Engineering is separate, append-only and repairable; preserve failed attempts.
Verify the inherited board deployment identities and record platform drift.
Hardware GPU and mapped RKNPU runtime are required; no silent CPU/software
fallback. Preserve old board workspaces. Source-bound synthetic presenter tests
must cover expiry, supersession and safe slot reuse. Nine source-coded native
inputs at 160x90 must match ordinary RKNN reference residual bytes using the
same captured quantized inputs; require all nine actual selected roots.
Input max error <=1 RGB level, composition/root max error <=2 and MAE <=0.25,
as in predecessor; root bilinear scaling is checked against 1280x720.
The functional fixture alone may expand acceptance to 900 frames for readback.
All twenty scene/control combinations pass eight-source integration tests,
including actual scheduler-decision replay. Discover mapped libraries, bind
them before the accepted integration pass. No engineering latency is scientific
performance evidence. Review the exact source and qualification before freeze.

## Capture, analysis and stopping

Freeze hashes, model, policy, assets, binaries, libraries, platform/governors,
exact commands, schedule, numerical evidence and reducer before the sole
campaign per board. Start cells <=55 C (wait <=300 s); stop >=80 C or after
180 s/cell, source/ownership/numerical error, incomplete telemetry or input drift.
Retain partial and failed captures, with no replacement cells or result-based
retry. Recover the original process/files after a disconnect before any action.

Primary: first source-matched neural post-draw <=1000/30 ms from source capture,
denominator all 3,000 sources/control/board. Report eligible, eventual selection,
timely selection, all dispositions, each scene/repetition and selected-only ages.
Receipt-side eligibility excludes intervening waiting and is not actual delivery.
Capture rate is 299 intervals/elapsed capture time; aggregate rates are equal-cell
means. Preserve the predecessor reduction definitions, with only the new width
and 40-cell schedule. Frames are not independent statistical repetitions.
No physical scanout, energy, universal real-time, isolated resolution-causality
or cross-device arithmetic-equivalence claim. New runs occur in a later session
and new shape compilation; compare historical resolutions descriptively.

After evidence verification, report any success, null or failure honestly.
Update paper/site only with verified outcomes; do not rewrite submitted files
or publish artifact changes automatically. Paper 2/3 experiments remain closed.
