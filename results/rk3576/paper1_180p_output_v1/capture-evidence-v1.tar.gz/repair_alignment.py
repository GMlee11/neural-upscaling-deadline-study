"""Engineering-only packed-input view repair; unchanged contiguous NHWC bytes."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

BASE=Path('/home/radxa/experiments/paper1-180p-output-v1')
OLD=Path('/home/radxa/experiments/paper1-composition-rk3576-v1/engineering')
BUILD=BASE/'engineering/alignment-build-v1'


def replace(text,old,new,count=1):
    assert text.count(old)==count,(old,text.count(old))
    return text.replace(old,new)


def repaired(text):
    text=replace(text,'uniform int u_height;\nuniform float u_input_scale;',
                 'uniform int u_height;\nuniform int u_packed_width;\nuniform float u_input_scale;')
    text=replace(text,'''  int packed_x = int(gl_FragCoord.x);
  int pixel_x = packed_x / 3;
  int channel = packed_x - pixel_x * 3;
  int model_y = int(gl_FragCoord.y);''','''  // The image view may group two rows; the tensor remains packed NHWC.
  int byte_index = int(gl_FragCoord.y) * u_packed_width + int(gl_FragCoord.x);
  int pixel_index = byte_index / 3;
  int pixel_x = pixel_index % u_width;
  int channel = byte_index % 3;
  int model_y = pixel_index / u_width;''')
    text=replace(text,'input_width_ * 3,\n      EGL_HEIGHT,\n      input_height_,',
                 '(input_width_ == 160 && input_height_ == 90 ? 960 : input_width_ * 3),\n      EGL_HEIGHT,\n      (input_width_ == 160 && input_height_ == 90 ? 45 : input_height_),')
    text=replace(text,'input_width_ * 3,\n      EGL_NONE};',
                 '(input_width_ == 160 && input_height_ == 90 ? 960 : input_width_ * 3),\n      EGL_NONE};')
    text=replace(text,'      glViewport(0, 0, input_width_ * 3, input_height_);',
                 '''      const int packed_width = input_width_ == 160 && input_height_ == 90 ? 960 : input_width_ * 3;
      const int packed_height = input_width_ == 160 && input_height_ == 90 ? 45 : input_height_;
      glViewport(0, 0, packed_width, packed_height);''')
    text=replace(text,'          glGetUniformLocation(input_program_, "u_height"), input_height_);',
                 '''          glGetUniformLocation(input_program_, "u_height"), input_height_);
      glUniform1i(glGetUniformLocation(input_program_, "u_packed_width"), packed_width);''')
    return text


def main():
    BUILD.mkdir(exist_ok=False)
    bridge=BASE/'project/native_bridge'
    source=bridge/'src/rk3576_native_bridge.cpp'
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest(source)=='ec411a66ae120116fea8499dac94ea99f6dd7879e72685da3b7d9b9dc23d0f4a'
    shutil.copyfile(source,BUILD/'original.cpp')
    shutil.copyfile(bridge/'bin/librk3576_native_bridge.so',BUILD/'original.so')
    candidate=BUILD/'repaired.cpp'
    candidate.write_text(repaired(source.read_text()))
    cpp=OLD/'godot-cpp'
    original_bridge=OLD/'repo/demo/godot_upscaling_benchmark/native_bridge'
    includes=[bridge/'src',cpp/'include',cpp/'gen/include',cpp/'gdextension',
              Path('/usr/include/rga'),OLD/'repo/src/deployment',Path('/usr/include/libdrm')]
    compile_command=['g++','-std=c++17','-O3','-fPIC','-fopenmp','-fexceptions',
                     '-DPAPER1_COMPOSITION_AUDIT','-DNDEBUG',*['-I'+str(p) for p in includes],
                     '-c',str(candidate),'-o',str(BUILD/'bridge.o')]
    link_command=['g++','-shared','-fopenmp','-pthread','-o',str(BUILD/'candidate.so'),
                  str(BUILD/'bridge.o'),str(original_bridge/'src/register_types.os'),
                  str(OLD/'repo/src/deployment/rk3576_dmabuf_runtime.os'),
                  str(cpp/'bin/libgodot-cpp.linux.template_release.arm64.a'),
                  '-L/usr/lib','-lrknnrt','-lrga','-lEGL','-lGLESv2']
    inputs=[source,Path(__file__),original_bridge/'src/register_types.os',
            OLD/'repo/src/deployment/rk3576_dmabuf_runtime.os',cpp/'bin/libgodot-cpp.linux.template_release.arm64.a']
    record=dict(scientific_samples=0,reason='prequalified aligned 960x45 R8 view for unchanged 160x90 NHWC bytes; inherited RK3576 composition-audit build',
                input_hashes={str(p):digest(p) for p in inputs},commands=[compile_command,link_command])
    (BUILD/'start.json').write_text(json.dumps(record,indent=2)+'\n')
    try:
        with (BUILD/'build.log').open('x') as log:
            for cmd in (compile_command,link_command):
                subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
        record.update(status='BUILT_NOT_QUALIFIED',candidate_sha256=digest(BUILD/'candidate.so'))
        shutil.copyfile(candidate,source)
        shutil.copyfile(BUILD/'candidate.so',bridge/'bin/librk3576_native_bridge.so')
    except BaseException as error:
        record.update(status='FAILED',error=repr(error))
        raise
    finally:
        (BUILD/'terminal.json').write_text(json.dumps(record,indent=2)+'\n')
    print(record['status'],record['candidate_sha256'])


if __name__=='__main__':
    main()
