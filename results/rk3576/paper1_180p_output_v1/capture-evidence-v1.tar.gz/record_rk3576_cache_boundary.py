"""Record a regenerable cache mismatch without changing any historical file."""
import hashlib
import json
from pathlib import Path

base=Path('/home/radxa/experiments/paper1-180p-output-v1')
prior=Path('/home/radxa/experiments/paper1-prompt-selection-v1/freeze.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(prior)=='c4d733744e3ce10305d16155bc00cb3bbff41871c558b1857d6cd55f416598c8'
bindings=json.loads(prior.read_text())['files']
cache='/home/radxa/.cache/mesa_shader_cache_db/index'
old=bindings.pop(cache)
assert old=='0d260768301ca3c06bf214430573ef59d8db81fd80b7a7ea8283693c32e1a69b'
assert all(sha(Path(n))==h for n,h in bindings.items())
record=dict(scientific_samples=0,excluded_inherited_path=cache,prior_sha256=old,
    observed_sha256=sha(Path(cache)),all_other_bindings_match=True,
    reason='Regenerable Mesa shader-cache index changed during display initialization; not code, model, library or experimental evidence. Exclude only this known cache directory from frozen runtime inputs and mapped executable dependencies.')
with (base/'cache-boundary.json').open('x') as f:
    json.dump(record,f,indent=2)
with (base/'engineering/functional-v1/preflight-failure.json').open('x') as f:
    json.dump(dict(status='FAILED_BEFORE_EXECUTION',scientific_samples=0,
        error='Inherited Mesa shader-cache index mismatch before functional start/commands'),f,indent=2)
print('ALL_NONCACHE_INHERITED_BINDINGS_MATCH',len(bindings))
