"""Offline verification of all input pixels, channels and exact RKNN outputs."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

directory=Path(sys.argv[1])
cell=directory/'160_native'
y,x=np.indices((90,160))
results=[]
for source in range(9):
    expected=np.stack([np.full_like(x,32+source*20),32+(x*7+y*3)%192,16+(x*3+y*11)%192],axis=-1)
    actual=np.fromfile(cell/f'source_{source}_input_rgb.bin',np.uint8).reshape(90,160,3)
    error=int(np.abs(expected-actual.astype(np.int16)).max())
    ref=np.fromfile(cell/f'source_{source}_reference.nchw',np.int8)
    packed=(ref.astype(np.int16)+128).astype(np.uint8).reshape(3,2,2,90,160).transpose(3,1,4,2,0).reshape(180,320,3)
    native=np.fromfile(cell/f'source_{source}_residual_rgb.bin',np.uint8).reshape(180,320,3)
    exact=bool(np.array_equal(packed,native))
    assert error<=1 and exact
    assert (cell/f'source_{source}_root.png').exists()
    results.append(dict(source=source,input_max_abs=error,residual_exact=exact))
manifest={p.relative_to(directory).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.rglob('*')) if p.is_file()}
out=dict(scientific_samples=0,all_pass=True,cases=results,raw_files=manifest)
with (directory/'spatial-check.json').open('x') as f:
    json.dump(out,f,indent=2)
print('PASS: nine spatially varying inputs and byte-exact residuals')
