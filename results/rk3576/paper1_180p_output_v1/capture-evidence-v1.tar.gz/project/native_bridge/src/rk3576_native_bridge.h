#ifndef RK3576_GODOT_NATIVE_BRIDGE_H_
#define RK3576_GODOT_NATIVE_BRIDGE_H_

#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>

#include <godot_cpp/classes/ref_counted.hpp>
#include <godot_cpp/variant/dictionary.hpp>
#include <godot_cpp/variant/packed_byte_array.hpp>
#include <godot_cpp/variant/rid.hpp>
#include <godot_cpp/variant/string.hpp>

namespace godot {

// Bind the target-native RKNN/DMA-BUF runtime directly into Godot. Explicit
// core profiles allow controlled comparison of independent frame workers and
// one graph spanning multiple RK3576 NPU cores.
class RK3576NativeBridge : public RefCounted {
  GDCLASS(RK3576NativeBridge, RefCounted)

 public:
  RK3576NativeBridge();
  ~RK3576NativeBridge() override;

  // Create the requested RKNN core allocation and allocate the bounded
  // DMA-BUF rings used by calls from Godot worker threads.
  Dictionary configure(
      const String& model_path,
      int input_width,
      int input_height,
      int slot_count,
      const String& core_profile);

  // Execute one graph and return its PixelShuffled INT8 residual plus timing
  // metadata. The GPU performs the final bicubic/residual reconstruction.
  Dictionary upscale_residual(const PackedByteArray& input_rgb);

  // Describe the configured geometry without exposing native runtime pointers.
  Dictionary status() const;

  // Clear the render-context probe before GDScript schedules it through
  // RenderingServer.call_on_render_thread().
  void reset_render_probe();

  // Inspect the actual context owned by Godot's render thread. Running this
  // method anywhere else would produce a false negative because EGL contexts
  // are thread-local.
  void probe_render_context();

  // Reserve a bounded GPU/NPU slot and return an opaque frame token. The
  // topology hint is used only by the preloaded split/fused experiment; fixed
  // profiles retain their original round-robin behavior.
  Dictionary reserve_direct_frame(const String& topology_hint);

  // Copy one Godot GL texture into the slot's RGBA8 DMA-BUF on the render
  // thread. This is a device-to-device blit, not an ARM readback.
  void capture_direct_frame(
      std::int64_t frame_token,
      const RID& source_viewport);

  // Execute RGA conversion and RKNN on a captured slot from a worker thread.
  Dictionary upscale_direct_frame(std::int64_t frame_token);

  // Materialize exact post-RGA input and RKNN residual tensors only when a
  // correctness run explicitly requests same-frame validation data.
  Dictionary read_direct_validation(std::int64_t frame_token);

  // Fuse bicubic, PixelShuffle, dequantization, residual addition, clamp, and
  // packing into a render-thread draw targeting a Godot-owned texture.
  void compose_direct_frame(
      std::int64_t frame_token,
      const RID& output_texture);

  // Poll asynchronous render callbacks without exposing native synchronization
  // objects to GDScript.
  Dictionary direct_frame_status(std::int64_t frame_token);

  // Return final telemetry and forget one completed frame token.
  Dictionary consume_direct_frame(std::int64_t frame_token);

  // Release both RKNN contexts and all imported DMA-BUF slots.
  void close();

 protected:
  // Publish the bridge's small method surface to Godot's ClassDB.
  static void _bind_methods();

 private:
  struct DirectFrameState;
  struct RenderSlotResources;

  // Convert native failures into the same dictionary contract as successful
  // worker calls so GDScript can handle both without exceptions.
  Dictionary error_result(const std::string& message) const;

  // Look up one token while retaining shared ownership after the map unlocks.
  std::shared_ptr<DirectFrameState> find_direct_frame(
      std::uint64_t token) const;

  // Release a runtime slot exactly once on failures or successful composition.
  void release_direct_slot(const std::shared_ptr<DirectFrameState>& frame);

  // Lazily import permanent runtime DMA-BUF descriptors into Godot's EGL
  // context. Resources are reused across all frames assigned to a ring slot.
  bool ensure_render_slot(
      const std::shared_ptr<DirectFrameState>& frame,
      std::string* error);

  // Compile the complete residual-reconstruction shader once per process.
  bool ensure_composition_program(std::string* error);

  // Compile the RGB-to-affine-INT8 packing shader once per process.
  bool ensure_input_program(std::string* error);

  // Workers 0/1 own independent core-0/core-1 contexts. Worker 2 optionally
  // owns one context spanning both cores. Preloading all three avoids context
  // reconstruction during the measured policy experiment.
  std::array<void*, 3> runtimes_{{nullptr, nullptr, nullptr}};
  std::array<std::mutex, 3> runtime_mutexes_;
  std::array<int, 3> core_masks_{{0, 0, 0}};
  std::size_t active_worker_count_ = 0;
  std::string core_profile_;
  std::atomic<std::uint64_t> next_worker_{0};
  int input_width_ = 0;
  int input_height_ = 0;
  int output_bytes_ = 0;
  int slot_count_ = 0;
  std::string model_path_;
  mutable std::mutex lifecycle_mutex_;
  std::atomic<bool> render_probe_complete_{false};
  bool render_probe_compatible_ = false;
  std::string egl_vendor_;
  std::string gl_renderer_;
  std::string gl_version_;
  std::string render_probe_error_;
  mutable std::mutex render_probe_mutex_;
  std::atomic<std::uint64_t> next_direct_token_{1};
  std::atomic<std::uint64_t> next_direct_worker_{0};
  mutable std::mutex direct_frames_mutex_;
  std::unordered_map<
      std::uint64_t,
      std::shared_ptr<DirectFrameState>>
      direct_frames_;
  std::array<std::array<std::unique_ptr<RenderSlotResources>, 8>, 3>
      render_slots_;
  unsigned int capture_read_fbo_ = 0;
  unsigned int capture_draw_fbo_ = 0;
  unsigned int compose_fbo_ = 0;
  unsigned int input_program_ = 0;
  unsigned int input_vao_ = 0;
  unsigned int compose_program_ = 0;
  unsigned int compose_vao_ = 0;
};

}  // namespace godot

#endif  // RK3576_GODOT_NATIVE_BRIDGE_H_
