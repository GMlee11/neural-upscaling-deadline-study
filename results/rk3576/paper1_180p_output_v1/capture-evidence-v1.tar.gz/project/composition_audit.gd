extends RefCounted
## Single-writer viewport boundary, NOT GPU completion or scanout.
signal draw_completed
var owner_node: Node
var enabled := true
var rows: Array[Dictionary] = []
var errors: Array[String] = []
var sources: Dictionary = {}
var textures: Dictionary = {}
var tokens: Dictionary = {}
var current_source := -1
var rendered_source := -1
var capturing := -1
var selection_version := 0
var pending: Dictionary = {}
var pending_state: Dictionary = {}
var draw_id := 0
var active := true

func _init(node: Node, log_enabled: bool = true) -> void:
	owner_node = node
	enabled = log_enabled
	RenderingServer.frame_pre_draw.connect(pre_draw)
	RenderingServer.frame_post_draw.connect(post_draw)

func fail(reason: String) -> void:
	errors.append(reason)
	if owner_node.has_method("_composition_integrity_failed"):
		owner_node.call_deferred("_composition_integrity_failed", reason)

func source(frame_id: int, capture_usec: int) -> void:
	if sources.has(frame_id) or capturing >= 0 or not pending.is_empty():
		fail("duplicate source or source advanced during capture/draw")
		return
	current_source = frame_id
	sources[frame_id] = capture_usec
	if enabled:
		rows.append({"event": "source", "source_id": frame_id, "capture_usec": capture_usec})

func select(texture: Texture2D, material: Material) -> void:
	selection_version += 1
	if not pending.is_empty():
		fail("selection mutated during draw interval")
	owner_node.output_rect.texture = texture
	owner_node.output_rect.material = material

func reserve(index: int, frame_id: int, token: int) -> void:
	if index < 0 or index >= owner_node.direct_output_textures.size() or tokens.has(token):
		fail("invalid slot or duplicate token")
		return
	if capturing >= 0 or rendered_source != frame_id or current_source != frame_id or not pending.is_empty():
		fail("capture not bound to completed current LR generation")
		return
	if textures.has(index) and textures[index].state != "released":
		fail("reserved slot still owned")
		return
	if owner_node.output_rect.texture == owner_node.direct_output_textures[index]:
		fail("reserved slot remains selected")
		return
	capturing = token
	tokens[token] = index
	textures[index] = {"source_id": frame_id, "token": token, "state": "capturing", "last_draw": -1}

func matches(index: int, frame_id: int, token: int, state: String) -> bool:
	return textures.has(index) and int(textures[index].source_id) == frame_id and int(textures[index].token) == token and textures[index].state == state

func captured(token: int) -> void:
	var index := int(tokens.get(token, -1))
	if capturing != token or not matches(index, current_source, token, "capturing") or rendered_source != current_source:
		fail("captured source/token mismatch")
		return
	textures[index].state = "captured"
	capturing = -1
	if enabled:
		rows.append({"event": "captured", "source_id": current_source, "native_token": token, "slot": index, "recorded_usec": Time.get_ticks_usec()})

func writing(index: int, frame_id: int, token: int) -> void:
	if not matches(index, frame_id, token, "captured"):
		fail("writing source/slot/token mismatch")
		return
	if owner_node.output_rect.texture == owner_node.direct_output_textures[index]:
		fail("writing selected texture")
	textures[index].state = "writing"

func ready(index: int, frame_id: int, token: int) -> void:
	if not matches(index, frame_id, token, "writing"):
		fail("ready source/slot/token mismatch")
		return
	textures[index].state = "ready"

func release(token: int) -> void:
	var index := int(tokens.get(token, -1))
	if index < 0 or not textures.has(index) or int(textures[index].token) != token or textures[index].state != "ready":
		fail("release token/state mismatch")
		return
	if not pending.is_empty() or owner_node.output_rect.texture == owner_node.direct_output_textures[index]:
		fail("release during draw or while selected")
		return
	textures[index].state = "released"
	if enabled:
		rows.append({"event": "release", "native_token": token, "source_id": textures[index].source_id, "last_draw": textures[index].last_draw, "recorded_usec": Time.get_ticks_usec()})

func snapshot() -> Dictionary:
	var rect: TextureRect = owner_node.output_rect
	var index: int = owner_node.direct_output_textures.find(rect.texture) if rect.texture is ImageTexture else -1
	return {"texture": rect.texture.get_rid().get_id() if rect.texture != null else -1,
		"material": rect.material.get_instance_id() if rect.material != null else -1,
		"version": selection_version, "source": current_source,
		"visible": rect.is_visible_in_tree() and rect.get_viewport().is_visible(),
		"size": rect.size, "lr_mode": owner_node.lr_viewport.render_target_update_mode,
		"generation": textures.get(index, {}).duplicate(true)}

func pre_draw() -> void:
	if not active or current_source < 0:
		return
	if owner_node.prompt_presenter != null:
		owner_node.prompt_presenter.stamp("pre_draw_entry", owner_node.prompt_presenter.active)
	if not pending.is_empty():
		fail("unpaired pre_draw")
	pending_state = snapshot()
	if not pending_state.visible or pending_state.size.x <= 0 or pending_state.size.y <= 0 or pending_state.lr_mode != SubViewport.UPDATE_ALWAYS:
		fail("root output or LR viewport not drawable")
	var base_id := current_source
	var neural_id := -1
	var token := -1
	var selected_path := "classical"
	var rect: TextureRect = owner_node.output_rect
	if rect.texture == null:
		base_id = -1
		selected_path = "blank"
	elif rect.material == owner_node.phase7_fallback_material:
		if rect.texture != owner_node.lr_viewport.get_texture():
			fail("fallback texture is not live LR viewport")
	elif rect.material == null:
		var index: int = owner_node.direct_output_textures.find(rect.texture) if rect.texture is ImageTexture else -1
		if index < 0 or not textures.has(index) or textures[index].state != "ready":
			fail("untracked, writing or released texture selected")
			selected_path = "invalid"
		else:
			base_id = int(textures[index].source_id)
			neural_id = base_id
			token = int(textures[index].token)
			selected_path = "neural"
	else:
		fail("untracked material selected")
		selected_path = "invalid"
	if base_id >= 0 and not sources.has(base_id):
		fail("missing base source")
	var now := Time.get_ticks_usec()
	pending = {"event": "draw", "draw_id": draw_id, "pre_draw_usec": now,
		"base_source_id": base_id, "neural_source_id": neural_id,
		"current_source_id": current_source, "selected_path": selected_path,
		"texture_rid": pending_state.texture, "native_token": token,
		"selection_version": selection_version, "source_capture_usec": int(sources.get(base_id, -1))}
	draw_id += 1

func post_draw() -> void:
	if not active or pending.is_empty():
		return
	if snapshot() != pending_state:
		fail("selection/source/generation changed across draw")
	var now := Time.get_ticks_usec()
	pending["post_draw_usec"] = now
	pending["age_at_pre_ms"] = (int(pending.pre_draw_usec) - int(pending.source_capture_usec)) / 1000.0 if int(pending.base_source_id) >= 0 else -1.0
	pending["age_at_post_ms"] = (now - int(pending.source_capture_usec)) / 1000.0 if int(pending.base_source_id) >= 0 else -1.0
	pending["within_one_frame_at_post"] = pending.selected_path == "neural" and float(pending.age_at_post_ms) <= 1000.0 / owner_node.benchmark_fps
	if int(pending.native_token) >= 0:
		textures[tokens[pending.native_token]].last_draw = pending.draw_id
	rendered_source = int(pending.current_source_id)
	if enabled:
		rows.append(pending)
	if owner_node.prompt_presenter != null:
		owner_node.prompt_presenter.after_draw(pending)
	pending = {}
	pending_state = {}
	draw_completed.emit()

func terminal(frame_id: int, accepted: bool, eligible: bool, response_age_ms: float, route: String) -> void:
	if enabled:
		rows.append({"event": "terminal", "source_id": frame_id,
			"runtime_accepted": accepted, "response_eligible": eligible,
			"response_age_ms": response_age_ms, "route": route,
			"recorded_usec": Time.get_ticks_usec()})

func finish(path: String, reason: String = "") -> bool:
	if not active:
		return false
	active = false
	RenderingServer.frame_pre_draw.disconnect(pre_draw)
	RenderingServer.frame_post_draw.disconnect(post_draw)
	if not reason.is_empty():
		errors.append(reason)
	if not pending.is_empty():
		errors.append("unflushed draw")
		rows.append({"event": "incomplete_draw", "record": pending})
	var payload := JSON.stringify({"event": "header", "schema": 2,
		"boundary": "Godot root viewport pre/post draw; not GPU completion or panel scanout",
		"logging_enabled": enabled, "source_count": sources.size(),
		"draw_count": draw_id, "errors": errors}) + "\n"
	for row in rows:
		payload += JSON.stringify(row) + "\n"
	var file := FileAccess.open(path, FileAccess.WRITE)
	var wrote := false
	if file != null:
		file.store_string(payload)
		file.flush()
		wrote = file.get_error() == OK and file.get_length() == payload.to_utf8_buffer().size()
		file.close()
		wrote = wrote and FileAccess.get_file_as_string(path) == payload
	if not wrote:
		errors.append("audit write verification failed")
		printerr("COMPOSITION_PREFIX_WRITE_FAILURE\n", payload)
	return wrote and errors.is_empty()
