extends SceneTree
## Engineering-only synthetic root-pixel and out-of-order ownership tests.
class FakeBridge extends RefCounted:
	var releases: Array[int] = []
	func consume_direct_frame(token: int) -> Dictionary:
		assert(not releases.has(token))
		releases.append(token)
		return {"ok": true}
	func close() -> void:
		pass
class FixtureOwner extends "res://main.gd":
	func _ready() -> void:
		pass
	func _process(_delta: float) -> void:
		pass
	func _unhandled_input(_event: InputEvent) -> void:
		pass

var owner: FixtureOwner
var destination := ""

func _initialize() -> void:
	call_deferred("run")

func capture(source: int, slot: int) -> Dictionary:
	var token := 100 + source
	owner.composition_audit.source(source, Time.get_ticks_usec())
	owner._present_gpu_fallback()
	await owner._await_audited_draw()
	owner.composition_audit.reserve(slot,source,token)
	owner.composition_audit.captured(token)
	owner.composition_audit.writing(slot,source,token)
	return {"frame_capture_start_usec": owner.composition_audit.sources[source],
		"response_received_usec": owner.composition_audit.sources[source]+1000,
		"response": {"texture": owner.direct_output_textures[slot], "metadata": {"direct_frame_token":token}}}

func ready(source: int, slot: int, context: Dictionary) -> void:
	owner.composition_audit.ready(slot,source,100+source)
	owner.prompt_presenter.enqueue(source,context)

func selected(source: int, color: Color) -> void:
	await owner._await_audited_draw()
	assert(owner.composition_audit.rows[-1].neural_source_id == source)
	var actual := root.get_texture().get_image().get_pixel(64,64)
	print("ROOT_PIXEL=", JSON.stringify({"source":source,"expected":str(color),"actual":str(actual)}))
	assert(abs(actual.r-color.r)<0.02 and abs(actual.g-color.g)<0.02 and abs(actual.b-color.b)<0.02)
	# Next draw retires the selected generation only after validated post-draw.
	await owner._await_audited_draw()
	assert(owner.prompt_presenter.outcomes[source].accepted)

func run() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output-dir="):
			destination = argument.trim_prefix("--output-dir=")
	assert(not destination.is_empty() and not DirAccess.dir_exists_absolute(destination))
	DirAccess.make_dir_recursive_absolute(destination)
	owner = FixtureOwner.new()
	root.add_child(owner)
	owner.benchmark_output_dir = destination
	owner.native_bridge = FakeBridge.new()
	root.size = Vector2i(128,128)
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	root.content_scale_size = Vector2i.ZERO
	owner.lr_viewport = SubViewport.new()
	owner.lr_viewport.size = Vector2i(128,128)
	owner.lr_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	owner.add_child(owner.lr_viewport)
	var fallback := ColorRect.new()
	fallback.size = Vector2(128,128)
	fallback.color = Color.WHITE
	owner.lr_viewport.add_child(fallback)
	owner.output_rect = TextureRect.new()
	owner.output_rect.size = Vector2(128,128)
	owner.add_child(owner.output_rect)
	var shader := Shader.new()
	shader.code = "shader_type canvas_item; render_mode unshaded; void fragment(){ COLOR=texture(TEXTURE,UV); }"
	owner.phase7_fallback_material = ShaderMaterial.new()
	owner.phase7_fallback_material.shader = shader
	for color in [Color.RED,Color.GREEN,Color.BLUE]:
		var img := Image.create(128,128,false,Image.FORMAT_RGBA8)
		img.fill(color)
		owner.direct_output_textures.append(ImageTexture.create_from_image(img))
	owner._present_gpu_fallback()
	await RenderingServer.frame_post_draw
	owner.composition_audit = load("res://composition_audit.gd").new(owner,true)
	owner.prompt_presenter = load("res://prompt_presenter.gd").new(owner,true)
	var older: Dictionary = await capture(0,0)
	var newer: Dictionary = await capture(1,1)
	ready(1,1,newer)
	await selected(1,Color.GREEN)
	ready(0,0,older)
	await owner._await_audited_draw()
	assert(owner.prompt_presenter.outcomes[0].reason == "prompt_superseded")
	assert(owner.composition_audit.rows[-1].selected_path == "classical")
	var expired: Dictionary = await capture(2,2)
	expired.response_received_usec = int(expired.frame_capture_start_usec)+200000
	ready(2,2,expired)
	await owner._await_audited_draw()
	assert(owner.prompt_presenter.outcomes[2].reason == "client_late_neural_discarded")
	for source in range(3,12):
		var slot := source%3
		var context: Dictionary = await capture(source,slot)
		ready(source,slot,context)
		await selected(source,[Color.RED,Color.GREEN,Color.BLUE][slot])
	assert(owner.native_bridge.releases.size() == 12)
	assert(owner.prompt_presenter.finish(destination.path_join("selection_events.jsonl")))
	assert(owner.composition_audit.finish(destination.path_join("composition.jsonl")))
	# Actual main finalization path: an ordinary exit preserves outstanding work.
	owner.prompt_presenter = load("res://prompt_presenter.gd").new(owner,true)
	owner.prompt_presenter.enqueue(99,{"response_received_usec":Time.get_ticks_usec(),"response":{"metadata":{"direct_frame_token":999}}})
	owner.benchmark_output_dir = destination.path_join("outstanding")
	DirAccess.make_dir_recursive_absolute(owner.benchmark_output_dir)
	owner._finalize_composition_on_exit()
	assert(not owner.prompt_presenter.final_ok)
	assert(FileAccess.get_file_as_string(owner.benchmark_output_dir.path_join("selection_events.jsonl")).contains('"token":999'))
	# Actual main path also preserves a labeled stderr prefix on write failure.
	owner.prompt_presenter = load("res://prompt_presenter.gd").new(owner,true)
	owner.prompt_presenter.stamp("write_failure_fixture",-1)
	owner.benchmark_output_dir = destination.path_join("missing/directory")
	owner._finalize_composition_on_exit()
	assert(not owner.prompt_presenter.final_ok)
	print("PROMPT_SYNTHETIC_PASS root_pixels three_slot_reuse out_of_order supersession expiry final_drain outstanding_exit write_failure")
	quit(0)
