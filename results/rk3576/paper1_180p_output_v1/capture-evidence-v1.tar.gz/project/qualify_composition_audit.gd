extends SceneTree
## Known-pixel and fault-injection tests through the production selection/wait hooks.
class FixtureOwner extends "res://main.gd":
	func _ready() -> void:
		pass
	func _process(_delta: float) -> void:
		pass
	func _unhandled_input(_event: InputEvent) -> void:
		pass
	func _composition_integrity_failed(_reason: String) -> void:
		# Fault tests inspect finalization explicitly instead of ending this suite.
		pass

func _initialize() -> void:
	call_deferred("run")

func check_pixel(expected: Color) -> void:
	var actual := root.get_texture().get_image().get_pixel(64, 64)
	assert(abs(actual.r-expected.r) < 0.02 and abs(actual.g-expected.g) < 0.02 and abs(actual.b-expected.b) < 0.02, "root pixel mismatch")

func run() -> void:
	var destination := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output-dir="):
			destination = argument.trim_prefix("--output-dir=")
	if destination.is_empty() or DirAccess.dir_exists_absolute(destination):
		quit(2)
		return
	DirAccess.make_dir_recursive_absolute(destination)
	var owner := FixtureOwner.new()
	root.add_child(owner)
	root.size = Vector2i(128,128)
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	root.content_scale_size = Vector2i.ZERO
	owner.lr_viewport = SubViewport.new()
	owner.lr_viewport.size = Vector2i(128,128)
	owner.lr_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	owner.add_child(owner.lr_viewport)
	var color_rect := ColorRect.new()
	color_rect.size = Vector2(128,128)
	color_rect.color = Color.RED
	owner.lr_viewport.add_child(color_rect)
	owner.output_rect = TextureRect.new()
	owner.output_rect.size = Vector2(128,128)
	owner.add_child(owner.output_rect)
	var shader := Shader.new()
	shader.code = "shader_type canvas_item; render_mode unshaded; void fragment(){ COLOR=texture(TEXTURE,UV); }"
	owner.phase7_fallback_material = ShaderMaterial.new()
	owner.phase7_fallback_material.shader = shader
	for color in [Color.RED,Color.GREEN,Color.BLUE]:
		var img := Image.create(128,128,false,Image.FORMAT_RGBA8)
		img.fill(color)
		owner.direct_output_textures.append(ImageTexture.create_from_image(img))
	owner._present_gpu_fallback()
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var audit = load("res://composition_audit.gd").new(owner,true)
	owner.composition_audit = audit
	for source in range(9):
		var slot := source % 3
		var color: Color = [Color.RED,Color.GREEN,Color.BLUE][slot]
		audit.source(source,Time.get_ticks_usec())
		color_rect.color = color
		owner._present_gpu_fallback()
		await owner._await_audited_draw()
		check_pixel(color)
		audit.reserve(slot,source,100+source)
		# Delayed callback with unchanged source remains valid.
		await owner._await_audited_draw()
		audit.captured(100+source)
		audit.writing(slot,source,100+source)
		audit.ready(slot,source,100+source)
		# Transient assignment overwritten before the draw is not neural.
		audit.select(owner.direct_output_textures[slot],null)
		owner._present_gpu_fallback()
		await owner._await_audited_draw()
		assert(audit.rows[-1].selected_path == "classical")
		audit.select(owner.direct_output_textures[slot],null)
		await owner._await_audited_draw()
		check_pixel(color)
		assert(audit.rows[-1].neural_source_id == source)
		await owner._await_audited_draw()
		assert(audit.rows[-1].neural_source_id == source)
		owner._present_gpu_fallback()
		audit.release(100+source)
		assert(audit.errors.is_empty())
	audit.select(null,null)
	await owner._await_audited_draw()
	assert(audit.rows[-1].selected_path == "blank")
	assert(audit.finish(destination.path_join("valid.jsonl")))
	owner.composition_audit = null

	for case in ["duplicate_source","delayed_source","wrong_ready_source","wrong_ready_token","release_selected","mutation_restore","generation_mutation","failure_prefix","write_failure"]:
		var bad = load("res://composition_audit.gd").new(owner,true)
		owner.composition_audit = bad
		bad.source(0,Time.get_ticks_usec())
		owner._present_gpu_fallback()
		await owner._await_audited_draw()
		bad.reserve(0,0,201)
		if case == "duplicate_source":
			bad.source(0,Time.get_ticks_usec())
		elif case == "delayed_source":
			bad.source(1,Time.get_ticks_usec())
		else:
			bad.captured(201)
			bad.writing(0,0,201)
			if case == "wrong_ready_source":
				bad.ready(0,1,201)
			elif case == "wrong_ready_token":
				bad.ready(0,0,202)
			else:
				bad.ready(0,0,201)
				bad.select(owner.direct_output_textures[0],null)
				await owner._await_audited_draw()
				if case == "release_selected":
					bad.release(201)
				elif case == "mutation_restore":
					bad.pre_draw()
					owner._present_gpu_fallback()
					bad.select(owner.direct_output_textures[0],null)
					bad.post_draw()
				elif case == "generation_mutation":
					bad.pre_draw()
					bad.textures[0].source_id = 99
					bad.post_draw()
				elif case == "failure_prefix":
					bad.fail("injected renderer failure")
		var path := destination.path_join(case+".jsonl")
		if case == "write_failure":
			path = destination.path_join("missing/record.jsonl")
		assert(not bad.finish(path), "invalid case accepted: "+case)
		assert(not bad.errors.is_empty())
		if case != "write_failure":
			var header = JSON.parse_string(FileAccess.get_file_as_string(path).get_slice("\n",0))
			assert(not header.errors.is_empty())
		owner.composition_audit = null
		print("REJECTED_EXPECTED=",case)
	print("COMPOSITION_SYNTHETIC_QUALIFICATION_PASS production_hooks known_pixels three_slots delayed_source overwrite repeated_draw identity mutation release failure")
	quit(0)
