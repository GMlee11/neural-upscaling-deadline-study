extends SceneTree

var bridge
var copied_bridge
var failure := false
var root_dir := ""

func _initialize() -> void:
	call_deferred("run_qualification")

func require_ok(record: Dictionary, stage: String) -> bool:
	if not record.get("ok", false):
		print("QUALIFICATION_FAILURE=" + JSON.stringify({"stage":stage,"detail":record}))
		failure = true
		return false
	return true

func await_stage(token: int, key: String) -> bool:
	for index in range(300):
		await process_frame
		var state: Dictionary = bridge.direct_frame_status(token)
		if not require_ok(state, key):
			return false
		if state.get(key, false):
			return true
	print("QUALIFICATION_FAILURE=timeout " + key)
	failure = true
	return false

func save_bytes(name: String, bytes: PackedByteArray) -> void:
	var file := FileAccess.open(root_dir + "/" + name, FileAccess.WRITE)
	file.store_buffer(bytes)
	file.close()

func run_qualification() -> void:
	var width := 320
	for arg in OS.get_cmdline_user_args():
		if arg == "--width=640":
			width = 640
		if arg.begins_with("--qualification-root="):
			root_dir = arg.trim_prefix("--qualification-root=")
	if not root_dir.begins_with("/home/radxa/experiments/paper1-composition-rk3576-v1/engineering/numerical-"):
		quit(8)
		return
	root_dir += "_" + str(width)
	if DirAccess.dir_exists_absolute(root_dir):
		quit(8)
		return
	DirAccess.make_dir_recursive_absolute(root_dir)
	bridge = ClassDB.instantiate("RK3576NativeBridge")
	copied_bridge = ClassDB.instantiate("RK3576NativeBridge")
	for shape in [[width, width * 9 / 16]]:
		var w: int = shape[0]
		var h: int = shape[1]
		var profile := "single_dualcore_01" if w == 320 else "dual_independent_01"
		var model := "/home/radxa/experiments/paper1-composition-rk3576-v1/engineering/models/%dx%d/model.rknn" % shape
		var config: Dictionary = bridge.configure(model, w, h, 3, profile)
		print("QUALIFICATION_CONFIG=" + JSON.stringify(config))
		if not require_ok(config, "configure"):
			break
		if not require_ok(copied_bridge.configure(model,w,h,3,profile), "configure_independent_reference"):
			break
		bridge.reset_render_probe()
		RenderingServer.call_on_render_thread(bridge.probe_render_context)
		for index in range(60):
			await process_frame
			if bridge.status().get("render_probe_complete",false):
				break
		if not bridge.status().get("render_probe_compatible",false):
			failure = true
			print("QUALIFICATION_FAILURE=" + JSON.stringify(bridge.status()))
			break
		for sample in range(8):
			var pattern: int = sample % 4
			var data := PackedByteArray()
			data.resize(w*h*3)
			for y in range(h):
				for x in range(w):
					for channel in range(3):
						var value: int = [0,127,255,(x*3+y*7+channel*53)%256][pattern]
						data[(y*w+x)*3+channel] = value
			var source := Image.create_from_data(w,h,false,Image.FORMAT_RGB8,data)
			var source_texture := ImageTexture.create_from_image(source)
			var viewport := SubViewport.new()
			viewport.size = Vector2i(w,h)
			viewport.own_world_3d = true
			viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
			root.add_child(viewport)
			var camera := Camera3D.new()
			camera.projection = Camera3D.PROJECTION_ORTHOGONAL
			camera.size = h
			camera.position.z = 1
			camera.current = true
			viewport.add_child(camera)
			var plane := MeshInstance3D.new()
			var quad := QuadMesh.new()
			quad.size = Vector2(w,h)
			plane.mesh = quad
			var material := StandardMaterial3D.new()
			material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			material.albedo_texture = source_texture
			material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
			plane.material_override = material
			viewport.add_child(plane)
			for index in range(5):
				await process_frame
			var observed_source: Image = viewport.get_texture().get_image()
			observed_source.convert(Image.FORMAT_RGB8)
			var reserved: Dictionary = bridge.reserve_direct_frame("")
			if not require_ok(reserved,"reserve"):
				break
			var token: int = reserved["frame_token"]
			RenderingServer.call_on_render_thread(bridge.capture_direct_frame.bind(token,viewport.get_viewport_rid()))
			if not await await_stage(token,"capture_complete"):
				break
			var inferred: Dictionary = bridge.upscale_direct_frame(token)
			if not require_ok(inferred,"infer"):
				break
			var direct: Dictionary = bridge.read_direct_validation(token)
			if not require_ok(direct,"readback"):
				break
			var copied: Dictionary = copied_bridge.upscale_residual(direct["input_rgb"])
			if not require_ok(copied,"copied_reference"):
				break
			var output_image := Image.create(w*2,h*2,false,Image.FORMAT_RGBA8)
			var output_texture := ImageTexture.create_from_image(output_image)
			RenderingServer.call_on_render_thread(bridge.compose_direct_frame.bind(token,output_texture.get_rid()))
			if not await await_stage(token,"composition_complete"):
				break
			var consumed: Dictionary = bridge.consume_direct_frame(token)
			if not require_ok(consumed,"consume"):
				break
			var prefix := "%dx%d_p%d" % [w,h,sample]
			save_bytes(prefix+"_source.rgb",data)
			save_bytes(prefix+"_viewport.rgb",observed_source.get_data())
			save_bytes(prefix+"_input.int8",direct["input_int8"])
			save_bytes(prefix+"_input.rgb",direct["input_rgb"])
			save_bytes(prefix+"_direct_residual.rgb",direct["residual_rgb"])
			save_bytes(prefix+"_copied_residual.rgb",copied["payload"])
			output_texture.get_image().save_png(root_dir+"/"+prefix+"_composed.png")
			print("QUALIFICATION_PAIR="+JSON.stringify({"shape":shape,"pattern":sample,"output_scale":config["output_scale"],"output_zero_point":config["output_zero_point"],"slot":consumed.get("slot_index",-1)}))
			viewport.queue_free()
			await process_frame
		bridge.close()
		copied_bridge.close()
		if failure:
			break
	print("QUALIFICATION_EXECUTION_COMPLETE=" + str(not failure))
	quit(1 if failure else 0)
