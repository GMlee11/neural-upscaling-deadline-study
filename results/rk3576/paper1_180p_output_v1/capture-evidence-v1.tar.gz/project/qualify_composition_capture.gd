extends "res://main.gd"
## Engineering-only source-coded scene through the unchanged native capture path.
var source_color_rect: TextureRect
var checked_sources: Dictionary = {}

func _parse_arguments(arguments: PackedStringArray) -> void:
	var filtered := PackedStringArray()
	for argument in arguments:
		if argument != "--spatial-input-fixture=true":
			filtered.append(argument)
	super._parse_arguments(filtered)

func _set_replay_camera(frame_id: int) -> void:
	super._set_replay_camera(frame_id)
	world_root.visible = false
	if source_color_rect == null:
		source_color_rect = TextureRect.new()
		source_color_rect.size = Vector2(lr_viewport.size)
		lr_viewport.add_child(source_color_rect)
	var image := Image.create(lr_viewport.size.x, lr_viewport.size.y, false, Image.FORMAT_RGB8)
	for y in range(lr_viewport.size.y):
		for x in range(lr_viewport.size.x):
			var rgb := expected_pixel(frame_id,x,y)
			image.set_pixel(x,y,Color8(rgb[0],rgb[1],rgb[2]))
	source_color_rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	source_color_rect.texture = ImageTexture.create_from_image(image)

func expected_pixel(source: int, x: int, y: int) -> PackedByteArray:
	if OS.get_cmdline_user_args().has("--spatial-input-fixture=true"):
		return PackedByteArray([32+(source%9)*20,32+(x*7+y*3)%192,16+(x*3+y*11)%192])
	return PackedByteArray([32+(source%9)*20,96,160])

func _begin_direct_composition(frame_id: int, frame_token: int, inference: Dictionary) -> void:
	if not bool(inference.get("ok", false)):
		super._begin_direct_composition(frame_id, frame_token, inference)
		return
	# Delay the consumer, allowing the live LR source to advance where the queue
	# permits. The retained native input must still belong to this exact token.
	await _await_audited_draw()
	await _await_audited_draw()
	var validation: Dictionary = native_bridge.read_direct_validation(frame_token)
	if not bool(validation.get("ok", false)):
		_composition_integrity_failed("source fixture readback failed")
		return
	var data: PackedByteArray = validation["input_rgb"]
	var expected := PackedByteArray([32 + (frame_id % 9) * 20, 96, 160])
	var max_error := 0
	for index in range(data.size()):
		var pixel := int(index / 3)
		expected = expected_pixel(frame_id,pixel % lr_viewport.size.x,int(pixel / lr_viewport.size.x))
		max_error = maxi(max_error, absi(int(data[index]) - int(expected[index % 3])))
	if max_error > 1 or data.size() != lr_viewport.size.x * lr_viewport.size.y * 3 or checked_sources.has(frame_id):
		_composition_integrity_failed("source-coded native capture mismatch frame=%d max=%d" % [frame_id,max_error])
		return
	checked_sources[frame_id] = frame_token
	print("NATIVE_SOURCE_MATCH=", JSON.stringify({"source":frame_id,"token":frame_token,"max_abs":max_error,"live_source_at_check":composition_audit.current_source}))
	super._begin_direct_composition(frame_id, frame_token, inference)
