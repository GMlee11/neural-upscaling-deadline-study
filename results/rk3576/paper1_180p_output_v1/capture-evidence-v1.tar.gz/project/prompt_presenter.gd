extends RefCounted
## A single writer at process-frame, before canvas state is flushed for drawing;
## no native slot reuse
## until a matching post-draw followed by detachment and checked release.
var owner_node: Node
var enabled := false
var queue: Dictionary = {}
var outcomes: Dictionary = {}
var active := -1
var last_selected := -1
var draw_finished := false
var events: Array[Dictionary] = []
var finalized := false
var final_ok := false

func _init(node: Node, prompt: bool) -> void:
	owner_node = node
	enabled = prompt
	owner_node.get_tree().process_frame.connect(before_draw)

func stamp(kind: String, source: int, extra: Dictionary = {}) -> void:
	var row := {"event": kind, "source_id": source, "recorded_usec": Time.get_ticks_usec()}
	row.merge(extra)
	events.append(row)

func enqueue(source: int, context: Dictionary) -> void:
	stamp("callback_ready", source, {"worker_received_usec": context.response_received_usec, "native_token": context.response.metadata.direct_frame_token})
	if not enabled:
		return
	if queue.has(source) or outcomes.has(source):
		owner_node._composition_integrity_failed("duplicate prompt source")
		return
	queue[source] = context

func retire(source: int, accepted: bool, upload_ms: float, reason: String) -> void:
	var context: Dictionary = queue[source]
	var token := int(context.response.metadata.direct_frame_token)
	owner_node._present_gpu_fallback()
	stamp("detach", source)
	owner_node.composition_audit.release(token)
	if not owner_node.composition_audit.errors.is_empty():
		return
	var result: Dictionary = owner_node.native_bridge.consume_direct_frame(token)
	stamp("release", source, {"ok": bool(result.get("ok",false)), "native_result": result})
	if not bool(result.get("ok",false)):
		owner_node._composition_integrity_failed("prompt native release failed: " + JSON.stringify(result))
		return
	outcomes[source] = {"accepted": accepted, "upload_ms": upload_ms, "reason": reason}
	stamp("disposition", source, outcomes[source])
	queue.erase(source)

func before_draw() -> void:
	stamp("presenter_process_entry", active, {"prompt": enabled})
	if not enabled:
		return
	if active >= 0:
		if not draw_finished:
			owner_node._composition_integrity_failed("prompt selected frame missing post-draw")
			return
		var previous := active
		active = -1
		retire(previous, true, float(queue[previous].prompt_upload_ms), "accepted_neural")
		if not queue.has(previous):
			draw_finished = false
		else:
			return
	var ready := queue.keys()
	ready.sort()
	for source_variant in ready:
		var source := int(source_variant)
		var context: Dictionary = queue[source]
		var receipt_age := (int(context.response_received_usec)-int(context.frame_capture_start_usec))/1000.0
		var deadline: float = 1000.0 * owner_node.maximum_neural_age_frames / owner_node.benchmark_fps
		stamp("decision", source, {"receipt_age_ms": receipt_age, "last_selected": last_selected})
		if source <= last_selected or receipt_age > deadline:
			retire(source, false, 0.0, "prompt_superseded" if source <= last_selected else "client_late_neural_discarded")
			continue
		var start := Time.get_ticks_usec()
		owner_node.composition_audit.select(context.response.texture, null)
		var upload := (Time.get_ticks_usec()-start)/1000.0
		stamp("assignment", source, {"worker_received_usec": context.response_received_usec, "upload_ms": upload})
		if receipt_age + upload > deadline:
			retire(source, false, upload, "client_late_neural_discarded")
			continue
		context.prompt_upload_ms = upload
		active = source
		last_selected = source
		draw_finished = false
		break

func after_draw(row: Dictionary) -> void:
	if not enabled or active < 0:
		return
	if row.selected_path != "neural" or int(row.neural_source_id) != active:
		owner_node._composition_integrity_failed("prompt selection not drawn")
		return
	draw_finished = true
	stamp("validated_post_draw", active, {"draw_id": row.draw_id, "post_draw_usec": row.post_draw_usec})

func finish(path: String, reason: String = "") -> bool:
	if finalized:
		return final_ok
	finalized = true
	owner_node.get_tree().process_frame.disconnect(before_draw)
	var drained := not enabled or (queue.is_empty() and active < 0)
	var unresolved: Array[Dictionary] = []
	for source in queue:
		unresolved.append({"source_id": source, "token": int(queue[source].response.metadata.direct_frame_token)})
	stamp("finalize", active, {"reason": reason, "drained": drained, "unresolved": unresolved})
	var payload := ""
	for row in events:
		payload += JSON.stringify(row) + "\n"
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		printerr("SELECTION_PREFIX_PERSISTENCE_FAILURE " + payload)
		return false
	file.store_string(payload)
	file.flush()
	var ok := file.get_error() == OK
	file.close()
	var persisted := ok and FileAccess.get_file_as_string(path) == payload
	if not persisted:
		printerr("SELECTION_PREFIX_PERSISTENCE_FAILURE " + payload)
	final_ok = persisted and drained and reason.is_empty()
	return final_ok
