extends "res://qualify_composition_capture.gd"
## Engineering only: source-coded native inputs and actual selected root output.
var pixel_sources: Dictionary = {}

func _parse_arguments(arguments: PackedStringArray) -> void:
	super._parse_arguments(arguments)
	# Qualification only; never installed as the performance entry point.
	maximum_neural_age_frames = 900
	print("ENGINEERING_ONLY_EXPANDED_ACCEPTANCE_GATE=900")

func _build_interface() -> void:
	super._build_interface()
	for item in output_rect.get_parent().get_children():
		if item != output_rect and item is CanvasItem:
			item.hide()
	RenderingServer.frame_post_draw.connect(check_root)

func _apply_split_layout() -> void:
	super._apply_split_layout()
	output_rect.position = Vector2.ZERO
	output_rect.size = Vector2(1280,720)
	output_rect.stretch_mode = TextureRect.STRETCH_SCALE
	reference_rect.hide()

func _begin_direct_composition(frame_id: int, frame_token: int, inference: Dictionary) -> void:
	if bool(inference.get("ok",false)):
		var validation: Dictionary = native_bridge.read_direct_validation(frame_token)
		assert(validation.ok)
		for key in ["input_rgb","input_int8","residual_rgb"]:
			var file := FileAccess.open(benchmark_output_dir.path_join("source_%d_%s.bin" % [frame_id,key]),FileAccess.WRITE)
			file.store_buffer(validation[key])
			file.close()
		print("NATIVE_NUMERICAL_METADATA=",JSON.stringify({"source":frame_id,"scale":inference.get("output_scale",0),"zero_point":inference.get("output_zero_point",0)}))
	super._begin_direct_composition(frame_id,frame_token,inference)

func check_root() -> void:
	if composition_audit == null or output_rect.material != null or prompt_presenter == null:
		return
	var source: int = prompt_presenter.active
	if source < 0 or pixel_sources.has(source):
		return
	var actual := get_viewport().get_texture().get_image()
	var expected := output_rect.texture.get_image()
	# The known panel maps a 16:9 texture to the complete 1280x720 root.
	actual.save_png(benchmark_output_dir.path_join("source_%d_root.png" % source))
	expected.save_png(benchmark_output_dir.path_join("source_%d_texture.png" % source))
	pixel_sources[source] = true
	print("NATIVE_ROOT_SAVED=",source)
