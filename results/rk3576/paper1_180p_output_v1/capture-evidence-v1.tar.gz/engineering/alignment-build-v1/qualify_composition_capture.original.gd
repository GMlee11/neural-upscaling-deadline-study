extends "res://main.gd"
## Engineering-only source-coded scene through the unchanged native capture path.
var source_color_rect: ColorRect
var checked_sources: Dictionary = {}

func _set_replay_camera(frame_id: int) -> void:
	super._set_replay_camera(frame_id)
	world_root.visible = false
	if source_color_rect == null:
		source_color_rect = ColorRect.new()
		source_color_rect.size = Vector2(lr_viewport.size)
		lr_viewport.add_child(source_color_rect)
	source_color_rect.color = Color8(32 + (frame_id % 9) * 20, 96, 160)

func _begin_direct_composition(frame_id: int, frame_token: int, inference: Dictionary) -> void:
	if not bool(inference.get("ok", false)):
		super._begin_direct_composition(frame_id, frame_token, inference)
		return
	# Delay the consumer, allowing the live LR source to advance where the queue
	# permits. The retained native input must still belong to this exact token.
	await _await_audited_draw()
	await _await_audited_draw()
	var validation: Dictionary = native_bridge.read_direct_validation(frame_token)
	if not bool(validation.get("ok", false)):
		_composition_integrity_failed("source fixture readback failed")
		return
	var data: PackedByteArray = validation["input_rgb"]
	var expected := PackedByteArray([32 + (frame_id % 9) * 20, 96, 160])
	var max_error := 0
	for index in range(data.size()):
		max_error = maxi(max_error, absi(int(data[index]) - int(expected[index % 3])))
	if max_error > 1 or data.size() != lr_viewport.size.x * lr_viewport.size.y * 3 or checked_sources.has(frame_id):
		_composition_integrity_failed("source-coded native capture mismatch frame=%d max=%d" % [frame_id,max_error])
		return
	checked_sources[frame_id] = frame_token
	print("NATIVE_SOURCE_MATCH=", JSON.stringify({"source":frame_id,"token":frame_token,"max_abs":max_error,"live_source_at_check":composition_audit.current_source}))
	super._begin_direct_composition(frame_id, frame_token, inference)
