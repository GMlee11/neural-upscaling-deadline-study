# Paper 1 corrected-runtime V1 — RK3566 adapter/source review

Date: 2026-09-15.

Decision: CONDITIONAL — the board adaptation is scientifically appropriate; one functional-acceptance gap must close before final qualification GO. No freeze or scientific capture is approved.

This is an interim source/design review. The completed RK3566 functional/control qualification packet has not yet been received or approved. No statement below treats a pending engineering run as a scientific result or a failed physical test.

## Inspected identities

| File | SHA-256 |
|---|---|
| `experiments/paper1_corrected_runtime_v1/run_rk3566.py` | `fdfe1547dc604406db939aa27142fcf3d1bac6993636ddee071aa837429f1df1` |
| `experiments/paper1_corrected_runtime_v1/qualify_rk3566.py` | `319851ba3a7fddc367678043f8a09af589033923b6a707dcb97442185c82ce82` |
| `docs/paper1_corrected_runtime_v1_rk3566_qualification.md` | `91fd931b5c497f64c7aacde8c9bdd4a297da13c51764911d5cfe825d05ff1311` |

## Accepted adaptation and boundaries

The RK3566 command constructor matches the saved prior freeze, whose SHA-256 is `771eafdfdc8927b5e9aa1bcd927ef24c9be73efa55208de29969ec4c0f7e35e7`. Its native binary identity remains `37959be9d26b29c7e63bdce88db4babbaa13e7d65c5a93ed502f1dace344cf95` in the predecessor records. The adapter verifies inherited file hashes and package/kernel/governor identity, uses a disjoint workspace, and has its own literal review gate. This source review does not independently observe the live board or assert that every eventual deployment byte matches before the final packet arrives.

Pure command reconstruction checks passed for all 80 prescribed scientific cells: RK3566 model paths and `rk3566_single_default`, prompt selection, three-slot/depth-three operation, 300 sources, 30-Hz target, and maximum neural age of three frames. Bicubic, fixed-2 even-source admission and scheduler command selection remain separated. No scientific command selects a qualification scene. The 100-ms scientific acceptance setting is distinct from the strict 33.33-ms eligibility and primary post-draw deadline.

The execution-loop AST is identical to the reviewed RK3576 loop except for the board label. The seven shared renderer/design/ledger/validator/reducer/policy files checked are byte-identical to the approved RK3576 qualification. Consequently the existing source-start binding, exact 40-cell verification, fresh subprocess state, terminal source-drift check and no-replacement capture behavior are preserved rather than reimplemented differently for this board.

Mapped-library discovery followed by a fresh start-bound accepted smoke is appropriate. The qualification gate explicitly requires every observed mapped path to have been present in the accepted engineering start closure. It must not retrospectively qualify a discovery-only run whose libraries were absent at start. Environment and platform checks remain separate from this byte binding.

The separate 18-source functional study is justified: it checks the RK3566 native path and actual selected pixels for the corrected presenter. The inherited qualification scene alone overrides acceptance to 900 frames for slow diagnostic readbacks; normal scientific commands do not. Its timings must never enter the scientific reduction. Reusing the unchanged RK3566 release-error propagation evidence is reasonable; adding an RK3576-only native fault hook or rebuilding the bridge is not required by this review.

## One blocking functional-acceptance gap

`run_rk3566.py`, `main()` qualification branch, lines 189–197, accepts the functional stage using:

- a current-file/platform check of `start.json`;
- `all_pass`, a list length of 18 and `selected` truthiness;
- existence, but not contents, of `complete.json`;
- a synthetic log marker without an ERROR string.

It does not read the functional terminal or verify the exact numerical case identities, each case's pass/error fields, or agreement of the transferred numerical result with the retained raw evidence. The source of `qualify_rk3566.py` writes `complete.json` before its final terminal write, so existence of that file is not itself evidence of successful final terminal publication.

**Reproducible counterexample:** I evaluated the exact production functional acceptance statements in memory, leaving later engineering checks outside this isolated test. With a valid fixed platform, an existing empty `complete.json`, a functional `terminal.json` saying FAILED, and a numerical object containing `all_pass=true` plus 18 copies of `(width=320, source=0, selected=true, pass=false, residual_exact=false)`, these statements all pass. No board action or evidence file was created or modified. This is not a claim that the current physical engineering produced those records; it demonstrates that the new acceptance boundary does not enforce its stated contract.

**Smallest repair:** make functional acceptance inspect successful terminal/completion contents and their consistent start/source binding; require exactly the 18 unique `(width, source)` pairs `{320,640} × {0,…,8}`, every case selected, residual-exact and passing the fixed numerical/pixel tolerances. Verify the expected commands/source outputs and bind the transferred checker result to the retained raw inputs, reference/residual bytes and PNGs. Replaying the unchanged checker read-only against that evidence is sufficient; there is no need for a new numerical algorithm or governance system. Keep the functional source identity distinct from any later sealing-only repair rather than inventing an earlier hash.

Add bounded negative checks for a failed/missing terminal, empty or inconsistent completion, duplicate/missing case, false per-case pass/residual flag, and a numerical-result/raw-evidence mismatch. These are local saved-record or disposable tests, not additional performance samples. The final independent review can verify the actual 18 cases and their raw bindings as well.

## Pending final qualification

No other acceptance-changing adapter/design defect was established in this bounded review. Both new Python sources compile. The pure 80-command checks, prior constructor/freeze hashes, shared-file equality and execution-loop equivalence checks pass.

Final GO remains contingent on closure of the functional gate above and receipt of the exact completed source-bound qualification: all 18 functional cases, all 40 distinct scene/resolution/control smoke cells, scheduler admission/bypass coverage, complete source/library and command bindings, and preserved failures/setup history where applicable. An observed engineering failure may be honestly repaired within the engineering scope; it must not be represented as passing evidence or silently substituted into an earlier identity. This review does not prescribe a rerun of otherwise reusable, correctly bound raw functional evidence.

No new scene, control, native rebuild or scientific sample is requested. The separately approved RK3576 outcome and both earlier reviews remain frozen. This reviewer performed no board/SSH access, inference, generator, deployment, freeze or capture. Only this new review was written.

## Repaired functional-gate and saved numerical evidence review

Decision: PASS for the inspected functional-gate repair and saved numerical result; final source/qualification and capture GO remain pending.

Inspected successor `run_rk3566.py` SHA-256 `a72ead087c2ddae8489666444a1bad8e7023437eaa6ea0966de972d41c143575` and `functional_gate.py` SHA-256 `e091c6746a3512f6db27d7b92275183d0e60bc87d6b03fb3e2fdc3843d40cd65`. The production qualifier calls the repaired gate. Terminal and completion must now equal the exact successful zero-scientific-sample record; all 18 unique width/source identities, selected/pass/residual flags and fixed error bounds are checked. Native commands, source-match/root-save coverage, required input/reference/pixel files and ordinary-reference commands are validated. The checker digest, numerical-result digest/content and exact raw-file hashes must agree with the replay attestation.

The sole historical-runner exception is exact: the archived `source/run_rk3566.py` must hash to the runner entry in the original functional start. Every other originally bound file is still verified against its original binding. It is not a general source exclusion. The final delivered packet must supply that snapshot and the new smoke's source closure for independent verification; this addendum has not yet inspected that completed packet.

Independently verified the delivered functional archive SHA-256 `fd6eb74d50cfb295b686b2de825beef38686eddb2ebce83587301e577aed08f7`, numerical result SHA-256 `1ecc6267b6c2da2655c999e72e7ad85600bb4380e8d5997ebe2b12ada35616dd`, and replay attestation SHA-256 `edc53fef28fdc8b1d84634b995707fb1da41bfdb712d38f4cd523c86566c5de6`. All 161 archived/raw files match the expanded evidence and attestation. The supplied successful terminal and completion agree.

Recomputed the unchanged `check_native.py` arithmetic over the actual saved inputs, native residuals, ordinary reference tensors, textures and root PNGs. For read-only operation, executed its original calculation/import/assert AST statements with the directory supplied in memory; excluded only argument parsing and output publication. No checker output or evidence file was written. The resulting 18-case dictionary equals the delivered numerical result exactly: all sources selected, input maximum error zero, residuals byte-exact, composition/root maximum errors at most one, and all fixed mean-error limits passing. The checker bytes agree with the original functional start binding. Independent native-command reconstruction and the actual repaired gate also pass on these records.

Independently reran all four relevant corrected-runtime/policy/prompt/functional-gate test files: **59 passed**, including the 12 functional positive/negative tests. The previous failed-terminal, false-case and raw/result-mismatch acceptance gap is closed in the inspected successor. No additional numerical experiment or algorithm change is needed for these passing raw records.

This addendum does not approve the pending final smoke-v2, its library closure, the historical runner snapshot not yet delivered here, or a scientific freeze/capture. Those remain for the exact final source/qualification packet. Only this review was appended; prior reviews and frozen evidence/helpers remain untouched.

## Final source/qualification packet review

Date: 2026-09-15.

Decision: GO for RK3566 corrected-runtime freeze and capture

This approval binds the exact successor qualification below. The earlier conditional findings remain historical; their repair and the previously pending packet bindings are now verified. No material source/qualification blocker remains for this packet.

| Artifact | SHA-256 |
|---|---|
| `qualification-v2.json` | `cd480bffcb0a63a98f428e958d8118a3ee8c7196588f25973b59f7e9ffdc1e2c` |
| `engineering-evidence-v1.tar.gz` | `a0b7b0bced2462b5ad7ef1067813d4b06722614ad98562c4d8557b4877af2259` |
| Final smoke-v2 `start.json` | `327693251a8e721e531422802bf3f5c76b40150deac29e271e0644d03f1f466d` |
| Final smoke-v2 `terminal.json` | `b521636e48cfd9f31221cc3538e834d3b871e2c508e64d8ba87cf4cb4d53d5da` |
| Original functional `start.json` | `e9d5f77d71c97878b0ecbc4f23c8bfd3c111a4b0873e50156f192fd040104c63` |

The local source checkpoint inspected is `7c69d36490515b2f49d002b4fc712b6c8bd3ebbb`. The operative approval identities are the exact packet/source hashes, not an assumption about subsequent checkout state. The repaired runner and functional gate retain the `a72ead...` and `e091c6...` full hashes listed in the preceding addendum.

### Packet, source and historical binding

Verified both delivered hashes and archived/local qualification equality. All **956 regular archive members** match their expanded bytes; member names are unique, without escaping paths or symbolic/hard links. Authentication material is not included. Both smoke directories and setup history are retained. The discovery smoke records COMPLETE but is not substituted for the final source-bound smoke.

All **527 qualification evidence bindings** verify: the final smoke's 362 manifest entries plus its manifest, and 164 functional files. The exact smoke manifest file set and every digest match. Terminal COMPLETE binds the original smoke start and contains no recorded failure or changed files.

All **341 final start bindings** agree with qualification, including every functional artifact and the repaired sealer. Of the qualification bindings, 218 are directly checked against supplied archived bytes and 52 against inherited freeze entries. Remaining external bindings are recorded board-file identities; this read-only review did not independently reread those live files. The inherited freeze itself is additionally checked against its locally retained bytes. Every one of the **71 observed mapped paths** is present in the original smoke start with the same qualification hash, and the reviewed runner checks those files at completion and sealing. No observed runtime is introduced only after engineering.

The archived original functional runner hashes exactly to its original start entry, `fdfe1547dc604406db939aa27142fcf3d1bac6993636ddee071aa837429f1df1`. All other original functional source bindings agree with the final start closure. Its diff from the repaired runner is confined to functional evidence inclusion and acceptance/sealing, not command generation, renderer execution or native computation. The current runner/helper/source files match the supplied archive. The native binary matches the frozen RK3566 `37959b...` identity, and the presenter, audit and functional fixtures match the inspected qualified originals.

### Functional and control qualification

The original 161 raw functional archive files are byte-identical in this packet. The numerical JSON and replay attestation are also identical to the previously independently checked records. Reconstructed the two native commands independently and reran the actual repaired functional gate on these delivered records. All 18 unique sources remain selected, residual-byte-exact and within the fixed pixel bounds; the earlier independent numerical calculation therefore applies without another physical run. The exact historical-source exception is now evidenced, not merely promised.

Independently reconstructed all **40 final smoke commands** and verified exact schedule/order/directories and scene identities. The inherited validator, corrected ownership/control validator and per-cell reducer all pass. The production engineering ledger passes with a read-only path adapter preserving Linux relative-path spelling; board-absolute source reads are represented only by the independently checked packet/inherited binding comparisons above.

Both scheduler paths are exercised: 19 submissions and 21 bypasses at 360p, and five submissions and 35 bypasses at 720p. These are eight-source engineering cells, not measured scientific performance. Maximum recorded smoke temperature is 50.625 C. Independently reran the four relevant regression suites: **59 passed**. No expanded matrix, native rebuild or replacement numerical experiment is needed.

### Exact authorization scope

This GO permits the reviewed RK3566 runner to freeze this exact qualification/source closure and perform **one prescribed 80-cell campaign, 24,000 measured sources**: five existing scenes, two resolutions, bicubic/always/fixed-2/frozen-scheduler controls and the fixed two-repetition order. Keep the 100-ms scientific acceptance gate, strict 33.33-ms eligibility and actual source-matched post-draw deadline distinct. The 900-frame functional-only allowance must not enter capture.

No retry, retuning, source/library substitution, weaker drift/thermal/timeout check, favorable-cell replacement or pooling with historical campaigns is authorized. Preserve any incomplete/failing outcome under the existing protocol. A changed qualified file or substituted qualification invalidates this approval. Engineering success establishes readiness, not timely neural performance or manuscript readiness.

Only this RK3566 review was appended. Both RK3576 reviews retain their prior hashes. This reviewer performed no board access, deployment, inference, generator, freeze or capture.
