"""Offline fixed tolerances inherited from the native composition qualification.
New root mapping: complete 1280x720 panel, bilinear sampler, <=2 levels and
<=0.25 mean absolute error against retained native texture. No performance use.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image
ap=argparse.ArgumentParser()
ap.add_argument('directory',type=Path)
a=ap.parse_args()
records=[]
for w in (320,640):
    h=w*9//16
    cell=a.directory/f'{w}_native'
    metadata=[json.loads(x.split('=',1)[1]) for x in (cell/'run.log').read_text().splitlines() if x.startswith('NATIVE_NUMERICAL_METADATA=')]
    assert len(metadata)==9
    for row in metadata:
        s=row['source']
        inp=np.fromfile(cell/f'source_{s}_input_rgb.bin',np.uint8).reshape(h,w,3)
        direct=np.fromfile(cell/f'source_{s}_residual_rgb.bin',np.uint8).reshape(h*2,w*2,3)
        ref=np.fromfile(cell/f'source_{s}_reference.nchw',np.int8)
        packed=(ref.astype(np.int16)+128).astype(np.uint8).reshape(3,2,2,h,w).transpose(3,1,4,2,0).reshape(h*2,w*2,3)
        input_error=int(np.abs(inp.astype(np.int16)-np.array([32+(s%9)*20,96,160])).max())
        record=dict(width=w,source=s,input_max_abs=input_error,residual_exact=bool(np.array_equal(direct,packed)),selected=(cell/f'source_{s}_root.png').exists())
        record['pass']=input_error<=1 and record['residual_exact']
        if record['selected']:
            tex=Image.open(cell/f'source_{s}_texture.png').convert('RGB')
            expected=np.rint(np.clip(np.array([32+(s%9)*20,96,160])/255+(direct.astype(np.float32)-128-row['zero_point'])*row['scale'],0,1)*255)
            e=np.abs(expected-np.asarray(tex).astype(np.float32))
            root=np.asarray(Image.open(cell/f'source_{s}_root.png').convert('RGB')).astype(np.int16)
            er=np.abs(root-np.asarray(tex.resize((1280,720),Image.Resampling.BILINEAR)).astype(np.int16))
            record.update(composition_max_abs=int(e.max()),composition_mae=float(e.mean()),root_max_abs=int(er.max()),root_mae=float(er.mean()))
            record['pass'] = bool(record['pass'] and e.max()<=2 and e.mean()<=.25 and er.max()<=2 and er.mean()<=.25)
        records.append(record)
result=dict(all_pass=all(r['pass'] for r in records) and len(records)==18, scientific_samples=0,cases=records)
with (a.directory/'numerical-check-v2.json').open('x') as f:
    json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
assert result['all_pass']
