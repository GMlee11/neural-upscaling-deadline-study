"""Source-bound engineering only: synthetic ownership, native pixels/reference."""
import json
import subprocess
from run_rk3566 import BASE, r, command, environment, files, inherited, merged, verify, platform, dump


def main():
    out = BASE/'engineering/functional-v1'
    out.mkdir(exist_ok=False)
    bound = merged(inherited()['files'], files())
    env = environment()
    commands = []
    for width in (320,640):
        cell = out/f'{width}_native'
        argv = command(dict(width=width,control='always',scene='corridor_neon'), cell, 9)
        argv.insert(argv.index('--'), 'res://qualify_prompt_native.tscn')
        commands.append(argv)
    synthetic = [str(r.OLD/'godot/Godot_v4.6.3-stable_linux.arm64'),
        '--windowed','--resolution','128x128','--rendering-method','gl_compatibility',
        '--rendering-driver','opengl3_es','--audio-driver','Dummy',
        '--path',str(BASE/'project'),'--script','res://qualify_prompt.gd','--',
        '--output-dir='+str(out/'synthetic')]
    dump(out/'start.json', dict(files=bound, platform=platform(), commands=commands,
                               synthetic_command=synthetic, scientific_samples=0))
    state = dict(status='RUNNING', scientific_samples=0)
    try:
        with (out/'synthetic.log').open('x') as log:
            completed = subprocess.run(synthetic,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
        text = (out/'synthetic.log').read_text()
        assert completed.returncode==0 and 'ERROR:' not in text and 'PROMPT_SYNTHETIC_PASS' in text, text[-2500:]
        print('SYNTHETIC_PASS',flush=True)
        for width,argv in zip((320,640),commands):
            cell = out/f'{width}_native'
            cell.mkdir()
            dump(cell/'command.json',argv)
            with (cell/'run.log').open('x') as log:
                completed = subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
            text = (cell/'run.log').read_text()
            assert completed.returncode==0 and 'ERROR:' not in text, text[-4000:]
            matches=[json.loads(line.split('=',1)[1]) for line in text.splitlines() if line.startswith('NATIVE_SOURCE_MATCH=')]
            assert sorted(row['source'] for row in matches)==list(range(9))
            roots=[int(line.split('=',1)[1]) for line in text.splitlines() if line.startswith('NATIVE_ROOT_SAVED=')]
            assert sorted(roots)==list(range(9)), roots
            r.validate(cell,9,True)
            for source in range(9):
                target=cell/f'source_{source}_reference.nchw'
                assert not target.exists()
                ref=[str(r.OLD/'reference_quantized_input'),str(r.OLD/f'models/{width}x{width*9//16}/model.rknn'),
                     str(cell/f'source_{source}_input_int8.bin'),str(target)]
                dump(cell/f'source_{source}_reference-command.json',ref)
                with (cell/f'source_{source}_reference.log').open('x') as log:
                    subprocess.run(ref,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
            print('NATIVE_AND_REFERENCE_COMPLETE',width,flush=True)
        verify(bound)
        state['status']='COMPLETE'
        dump(out/'complete.json',state)
    except BaseException as error:
        state.update(status='FAILED',error=repr(error))
        raise
    finally:
        dump(out/'terminal.json',state)


if __name__=='__main__':
    main()
