# RK3566 corrected-runtime V1 qualification addendum

2026-09-15. Engineering only; no scientific samples have been taken for this
board's corrected-runtime campaign. The fixed primary design remains exactly
`paper1_corrected_runtime_v1.md`. RK3576 evidence and its approved source remain
unchanged. A separate RK3566 source/qualification GO is required before capture.

Use a new `/home/paper3/experiments/paper1-corrected-runtime-v1` workspace.
Reuse the original hash-verified RK3566 width-24 INT8 models, Godot 4.6.3,
RKNN/RGA libraries and native bridge. Do not recompile or change their arithmetic.
Copy the qualified corrected main, prompt presenter, composition audit and
engineering fixtures; the new main is the exact RK3576 campaign main including
audit-only scheduler decision logging. Keep the old RK3566 workspaces immutable.

Board setup restored per-boot buffer ACLs through the existing authorized
helper: zero packages upgraded or installed. Root-owned Xorg :1 was stopped;
an authenticated user-owned :2 uses the existing rootless seat/VT options.
Hardware rendering reports Mali-G52/Panfrost, Mesa 25.0.7. A failed initial
display launch without those seat/VT options is retained as setup history.
Authentication material is excluded from shared evidence archives.

The board adapter uses the old RK3566 command constructor and native core profile
`rk3566_single_default`, new project/output paths, and the same fixed scene,
resolution/control/order transformations as RK3576. It retains the reviewed
capture loop, source-before-engineering binding, complete matrix ledger, thermal
and timeout stops, exclusive output creation and post-run input drift check.
Host names, model bytes and native platform remain explicitly board-specific.

Before scientific capture:

1. Bind source, platform and functional commands before executing engineering.
2. Run the unchanged synthetic prompt fixture for root pixels, reuse, supersession,
   expiry and finalization behavior.
3. Run nine source-coded native inputs at each resolution, three-slot reuse and
   actual selected root output. In this fixture only, expand acceptance to 900
   frames so slow pixel readback cannot prevent checking selected pixels. Never
   use these times as performance evidence.
4. Compare all 18 native residuals byte-for-byte with the already qualified
   ordinary-RKNN reference using the exact captured INT8 input tensor. Retain
   input, residual, reference bytes and root/texture PNGs. The unchanged numerical
   checker requires input error <=1 RGB level; composition and bilinear root
   mapping max error <=2 levels and mean absolute error <=0.25. All 18 sources
   must be selected and pass. Run the checker locally if numerical Python
   dependencies are absent on the board, then transfer the exact result back.
5. Exercise all 40 scene/resolution/control combinations with eight sources each;
   verify source/token ownership, scheduler state/decisions and sparse bypasses.
   Discover actual mapped libraries, then require them all to have been bound
   before the final accepted engineering run. A discovery-only smoke cannot
   satisfy that last gate retrospectively.
6. Seal exact source/platform/numerical/control evidence; obtain independent GO.
   Only then freeze the unchanged prescribed 80-cell measurement campaign.

Existing RK3566 release-error propagation was qualified in its original native
branch and the native bytes are unchanged. The RK3576-only native fault-injection
hook is not assumed present on RK3566. No native rebuild is proposed merely to
install that diagnostic hook. Any engineering failure remains visible and may
be repaired before source freeze; no failed or passing engineering fixture is
counted as a scientific performance result.
