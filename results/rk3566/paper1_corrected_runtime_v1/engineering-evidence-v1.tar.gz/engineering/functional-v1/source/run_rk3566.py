"""RK3566 adapter of the frozen RK3576 campaign loop; separate qualification."""
import argparse
import os
from types import SimpleNamespace
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

from design import schedule, cell_name, adapt_command
from validate import validate
from ledger import verify_engineering

BASE = Path('/home/paper3/experiments/paper1-corrected-runtime-v1')
PRIOR = Path('/home/paper3/experiments/paper1-composition-audit-v1')
spec = importlib.util.spec_from_file_location('old_composition', PRIOR / 'run_composition_audit_v1.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
EXPECTED_PRIOR_FREEZE = '771eafdfdc8927b5e9aa1bcd927ef24c9be73efa55208de29969ec4c0f7e35e7'


def environment():
    env = os.environ.copy()
    assert not env.get('LD_PRELOAD') and not env.get('LD_AUDIT')
    assert not any(key.startswith('PAPER1_ENGINEERING_') for key in env)
    env.update(DISPLAY=':2', XAUTHORITY=str(BASE/'engineering/display/Xauthority'),
               LD_LIBRARY_PATH=str(r.OLD/'sdk/lib')+':'+str(r.OLD/'sdk/usr/lib/aarch64-linux-gnu'),
               OMP_NUM_THREADS='2')
    return env


def platform():
    assert subprocess.check_output(['hostname'], text=True).strip() == 'paper3-opi3b'
    return dict(packages=subprocess.check_output(['dpkg-query','-W'], text=True),
        kernel=subprocess.check_output(['uname','-a'], text=True).strip(),
        cpu_governors={str(p):p.read_text().strip() for p in Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_governor')},
        gpu_npu_governors={str(p):p.read_text().strip() for p in Path('/sys/class/devfreq').glob('*/governor')})


def verify(bindings):
    for name, digest in bindings.items():
        assert Path(name).is_file() and sha(Path(name)) == digest, name


def merged(original, extra):
    verify(original)
    assert all(name not in original or original[name] == digest for name,digest in extra.items())
    return dict(original, **extra)


r.environment = environment
p = SimpleNamespace(r=r, OLD=PRIOR, verify=verify, merged=merged, platform=platform)


def dump(path, payload):
    with path.open('x') as stream:
        json.dump(payload, stream, indent=2)


def inherited():
    assert sha(PRIOR / 'freeze.json') == EXPECTED_PRIOR_FREEZE
    frozen = json.loads((PRIOR / 'freeze.json').read_text())
    p.verify(frozen['files'])
    current = platform()
    assert current['packages'] == frozen['packages'] and current['kernel'] == frozen['kernel'], 'prior platform drift'
    assert current['cpu_governors']['/sys/devices/system/cpu/cpufreq/policy0/scaling_governor'] == frozen['cpu_governor']
    assert current['gpu_npu_governors'] == frozen['gpu_npu_governors']
    assert sha(BASE/'policy.json') == sha(r.OLD/'repo/results/models/rk3576_neural_refresh_paper1_v1.json')
    return frozen


def command(row, target, frames):
    cmd = p.r.command(dict(row, logging=True), target, frames) + ['--selection-mode=prompt']
    return adapt_command(cmd, row, BASE / 'project')


def environment_identity():
    env = p.r.environment()
    # Bind experiment settings, not transient SSH/session fields or secrets.
    return {key: env.get(key) for key in ('DISPLAY', 'XAUTHORITY', 'LD_LIBRARY_PATH',
            'OMP_NUM_THREADS', 'MESA_LOADER_DRIVER_OVERRIDE', 'LIBGL_ALWAYS_SOFTWARE',
            'GALLIUM_DRIVER', 'EGL_PLATFORM', 'DRI_PRIME')}


def files():
    paths = [path for path in (BASE / 'project').rglob('*')
             if path.is_file() and '.godot' not in path.relative_to(BASE / 'project').parts]
    paths += [BASE / name for name in ('run_rk3566.py', 'design.py', 'validate.py', 'report.py', 'ledger.py', 'neural_refresh_policy.py', 'policy.json', 'protocol.md', 'rk3566-qualification.md', 'qualify_rk3566.py', 'check_native.py', 'project/.godot/extension_list.cfg')]
    paths += [r.OLD / 'repo/results/models/rk3576_neural_refresh_paper1_v1.json', PRIOR / 'freeze.json']
    paths += [r.OLD/'reference_quantized_input', r.OLD/'reference_quantized_input.cpp']
    # Bind already discovered libraries at the next engineering start, not only after it.
    for previous in (BASE/'engineering').glob('smoke-*/*/mapped_files.json'):
        paths.extend(Path(name) for name in json.loads(previous.read_text()))
    return {str(path): sha(path) for path in paths}


def execute(target, repetitions, frames, frozen=None):
    target.mkdir(parents=True, exist_ok=False)
    state = dict(protocol='paper1_corrected_runtime_v1', board='rk3566', status='RUNNING',
                 engineering=frozen is None, cells=[], frames_per_cell=frames)
    if frozen:
        state['freeze_sha256'] = sha(BASE / 'freeze.json')
    bound = frozen['files'] if frozen else p.merged(inherited()['files'], files())
    if frozen is None:
        dump(target / 'start.json', dict(files=bound, schedule=schedule(repetitions),
             commands=[command(row, target/cell_name(i,row), frames) for i,row in enumerate(schedule(repetitions))],
             platform=p.platform(), environment=environment_identity()))
        state['start_sha256'] = sha(target / 'start.json')
    temperatures = lambda: int(Path('/sys/class/thermal/thermal_zone0/temp').read_text()) / 1000
    try:
        for index, row in enumerate(schedule(repetitions)):
            cell = target / cell_name(index, row)
            cell.mkdir()
            argv = command(row, cell, frames)
            if frozen:
                assert argv == frozen['commands'][index]
            dump(cell / 'command.json', argv)
            record = dict(row, index=index, status='STARTED', directory=cell.name)
            state['cells'].append(record)
            deadline = time.monotonic() + 300
            while temperatures() > 55:
                assert time.monotonic() < deadline, 'cooling timeout'
                time.sleep(1)
            libraries = set()
            with (cell / 'stdout.log').open('x') as stdout, (cell / 'stderr.log').open('x') as stderr, (cell / 'system.jsonl').open('x') as system:
                start = time.monotonic()
                process = subprocess.Popen(argv, env=p.r.environment(), stdout=stdout, stderr=stderr)
                try:
                    while process.poll() is None:
                        temperature = temperatures()
                        system.write(json.dumps(dict(monotonic=time.monotonic(), temperature_c=temperature)) + '\n')
                        system.flush()
                        assert temperature < 80 and time.monotonic() - start < 180, 'thermal/timeout stop'
                        if frozen is None:
                            try:
                                for line in Path(f'/proc/{process.pid}/maps').read_text().splitlines():
                                    fields = line.split(None, 5)
                                    if len(fields) == 6 and fields[5].startswith('/') and Path(fields[5]).is_file():
                                        libraries.add(fields[5])
                            except FileNotFoundError:
                                pass
                        time.sleep(.1 if frozen is None else .5)
                    assert process.returncode == 0, ('renderer exit', process.returncode)
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
            if frozen is None:
                dump(cell / 'mapped_files.json', sorted(libraries))
            assert 'ERROR:' not in (cell / 'stderr.log').read_text(), 'renderer error'
            p.r.validate(cell, frames, True)
            record.update(validate(cell, frames, 'prompt', row['control']), status='COMPLETE')
            telemetry = [json.loads(line) for line in (cell / 'godot_frames.jsonl').read_text().splitlines()]
            assert all(f['scene_variant_id'] == row['scene'] for f in telemetry), 'scene mismatch'
            dump(target / f'progress-{index:02d}.json', state)
            print('COMPLETE', index + 1, len(schedule(repetitions)), cell.name, flush=True)
        state['status'] = 'COMPLETE'
    except BaseException as error:
        state.update(status='FAILED', error=repr(error))
        raise
    finally:
        changed = [name for name, digest in bound.items() if not Path(name).is_file() or sha(Path(name)) != digest]
        if changed:
            state.update(status='FAILED', changed_files=changed)
        dump(target / 'terminal.json', state)
        dump(target / 'sha256.json', {str(path.relative_to(target)): sha(path) for path in sorted(target.rglob('*')) if path.is_file()})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('phase', choices=('engineering', 'qualify', 'freeze', 'capture'))
    ap.add_argument('--identity', default='smoke-v1')
    args = ap.parse_args()
    assert args.identity.startswith('smoke-') and args.identity.replace('-', '').isalnum()
    original = inherited()
    if args.phase == 'engineering':
        execute(BASE / 'engineering' / args.identity, 1, 8)
    elif args.phase == 'qualify':
        engineering = BASE / 'engineering' / args.identity
        functional = BASE/'engineering/functional-v1'
        functional_start = json.loads((functional/'start.json').read_text())
        verify(functional_start['files'])
        assert functional_start['platform'] == platform()
        numerical = json.loads((functional/'numerical-check-v2.json').read_text())
        assert numerical['all_pass'] and len(numerical['cases']) == 18 and all(row['selected'] for row in numerical['cases'])
        assert (functional/'complete.json').is_file()
        synthetic = (functional/'synthetic.log').read_text()
        assert 'PROMPT_SYNTHETIC_PASS' in synthetic and 'ERROR:' not in synthetic
        start = verify_engineering(engineering, schedule(1),
                    [command(row, engineering/cell_name(i,row), 8) for i,row in enumerate(schedule(1))])
        assert start['platform'] == p.platform() and start['environment'] == environment_identity()
        terminal = json.loads((engineering / 'terminal.json').read_text())
        assert terminal['status'] == 'COMPLETE' and len(terminal['cells']) == 40
        for record in terminal['cells']:
            cell = engineering / record['directory']
            p.r.validate(cell, 8, True)
            validate(cell, 8, 'prompt', record['control'])
        mapped = set()
        for path in engineering.glob('*/mapped_files.json'):
            mapped.update(json.loads(path.read_text()))
        assert all(name in start['files'] for name in mapped), 'mapped library not bound at engineering start; qualify a fresh smoke after discovery'
        assert any('gallium' in path or 'panfrost' in path for path in mapped)
        assert any('librknnrt' in path for path in mapped)
        closure = p.merged(start['files'], files())
        closure = p.merged(closure, {name: sha(Path(name)) for name in mapped})
        dump(BASE / 'qualification-v2.json', dict(qualified=True, engineering_identity=args.identity,
             inherited_freeze_sha256=EXPECTED_PRIOR_FREEZE, files=closure, platform=p.platform(),
             numerical=numerical, functional_start_sha256=sha(functional/'start.json'),
             evidence={str(path.relative_to(BASE)): sha(path) for folder in (engineering,functional) for path in folder.rglob('*') if path.is_file()}))
        print('QUALIFIED', sha(BASE / 'qualification-v2.json'), flush=True)
    elif args.phase == 'freeze':
        assert not (BASE / 'capture-v1').exists()
        q = json.loads((BASE / 'qualification-v2.json').read_text())
        assert q['qualified'] and q['platform'] == p.platform()
        review = BASE / 'independent-review.md'
        assert 'Decision: GO for RK3566 corrected-runtime freeze and capture' in review.read_text()
        closure = p.merged(q['files'], {str(review): sha(review), str(BASE / 'qualification-v2.json'): sha(BASE / 'qualification-v2.json')})
        dump(BASE / 'freeze.json', dict(protocol='paper1_corrected_runtime_v1', board='rk3566',
             created_utc=datetime.now(timezone.utc).isoformat(), files=closure, platform=p.platform(),
             environment=environment_identity(), schedule=schedule(),
             commands=[command(row, BASE / 'capture-v1' / cell_name(i, row), 300) for i, row in enumerate(schedule())]))
        print('FROZEN', sha(BASE / 'freeze.json'), flush=True)
    else:
        frozen = json.loads((BASE / 'freeze.json').read_text())
        assert frozen['protocol'] == 'paper1_corrected_runtime_v1' and frozen['schedule'] == schedule()
        assert frozen['platform'] == p.platform()
        assert frozen['environment'] == environment_identity()
        p.verify(frozen['files'])
        execute(BASE / 'capture-v1', 2, 300, frozen)


if __name__ == '__main__':
    main()
