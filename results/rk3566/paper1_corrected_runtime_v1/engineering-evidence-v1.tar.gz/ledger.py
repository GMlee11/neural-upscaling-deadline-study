"""Exact engineering run identity and immutable inputs before qualification."""
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_files(files):
    for name, digest in files.items():
        assert Path(name).is_file() and sha(Path(name)) == digest, name


def verify_engineering(directory, expected, commands):
    start = json.loads((directory / 'start.json').read_text())
    terminal = json.loads((directory / 'terminal.json').read_text())
    manifest = json.loads((directory / 'sha256.json').read_text())
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file() and p.name != 'sha256.json'}
    assert actual == set(manifest), 'engineering file-set mismatch'
    assert all(sha(directory/name) == digest for name,digest in manifest.items()), 'engineering evidence hash mismatch'
    verify_files(start['files'])
    assert terminal['start_sha256'] == sha(directory/'start.json')
    assert terminal['status'] == 'COMPLETE' and terminal['engineering']
    assert start['schedule'] == expected and start['commands'] == commands
    assert len(terminal['cells']) == len(expected) == len(commands) == 40
    directories = set()
    for index, (record, planned, command) in enumerate(zip(terminal['cells'], expected, commands)):
        assert record['status'] == 'COMPLETE' and record['index'] == index
        assert all(record[key] == value for key,value in planned.items())
        assert record['directory'] not in directories
        directories.add(record['directory'])
        recorded = json.loads((directory/record['directory']/'command.json').read_text())
        assert recorded == command
        telemetry = [json.loads(line) for line in (directory/record['directory']/'godot_frames.jsonl').read_text().splitlines()]
        assert len(telemetry) == 8 and all(r['scene_variant_id'] == planned['scene'] for r in telemetry)
    return start
