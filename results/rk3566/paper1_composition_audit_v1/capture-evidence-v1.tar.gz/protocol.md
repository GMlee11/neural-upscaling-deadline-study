# Paper 1 composition audit V1

Authorized 2026-09-14. Engineering protocol, not a claim of completed capture.
Identity: `paper1_composition_audit_v1`. Prior captures and publication evidence
remain immutable. Engineering and measurements use separate new directories.

## Question and boundary

Join each Godot root-viewport draw to its actual selected texture/material,
base-source identity, neural-source identity, and source-relative age. Distinguish
request acceptance from render selection and viewport-update completion.
Godot frame_pre_draw/frame_post_draw bracket viewport updates, not scanout or
hardware GPU completion timestamps. Name this boundary explicitly. Do not claim
panel latency, perceptual usefulness, or an isolated chip-speed comparison.

The original RK3566 has no positive one-frame cell. Run it first as a negative
case and instrumentation demonstration; do not tune it into a positive case.
The planned RK3576 lower-resolution always-neural cell is the prospective
positive case, not a required outcome. A zero outcome is retained honestly.

## Engineering qualification before freeze

Instrument an opt-in successor of the frozen renderer. Record actual root
texture/material state at pre-draw, associate the same record with post-draw,
and track native output texture generations. Reject untracked materials,
unready/reused native textures, missing sources, unmatched draw events, or
unflushed final records. Do not infer a composition event from an assignment,
request acceptance, inference completion, or offscreen reconstruction alone.
Pin a selected native texture until its draw boundary completes; any necessary
ownership fix must be disclosed as successor behavior, not backdated into V1.
Buffer logs in memory and write only after the measurement interval.
An empty startup texture is a separately reported blank draw with no source,
not classical or neural output. Repeated draws never inflate source success.

Reviewer-driven engineering revision 2 (before any capture): all qualified
output selection uses a versioned single-writer method. Pre/post snapshots
validate source, texture, material, visibility and native generation; the main
replay resumes on the audit's validated draw-completed signal. Source advance
is prohibited until its native input capture fence completes (not inference).
Native state transitions bind slot/source/token exactly. The renderer detaches
to fallback before releasing an output token. These capture-hold/detach changes
affect scheduling and are disclosed successor semantics, not instrumentation
overhead alone. Logging on/off includes them identically. Regular error exits
preserve a failed buffered prefix and verify file writes; write failure dumps
the prefix to stderr. Hard kill/power loss may lose in-memory events and must
be classified as failed/incomplete, never a successful zero-outcome run.

Revision-2 qualification includes production selection/wait hooks with known
root pixels, nine frames through three reusable slots, overwritten and repeated
draws, source/token mismatch, change-and-restore, release while selected, failure
prefix/write error, plus source-coded RGB capture through the real native bridge
at both resolutions with an intentionally delayed consumer. No readback is used
in the paper-performance campaign.

Test synthetic known-source classical and neural textures, overwritten-before-
draw selections, repeated draws, invalid generation ownership, and source-age
accounting. Qualify against root viewport pixel readback on synthetic colors;
readback is excluded from performance capture. Debug functional engineering
failures here, retaining logs. No performance-driven clock, model, scene,
threshold, or scheduler tuning. Independently review source and protocol before
freezing measurements. Keep all qualification failures separate from captures.

## Fixed physical schedule

One session per board; existing width-24 INT8 graph/model per device, unchanged
weights/calibration, 30 FPS, 100-ms acceptance and separate 33.33-ms eligibility.
Use corridor_neon (preselected existing scene), both 320x180->640x360 and
640x360->1280x720, and bicubic, always-neural, frozen renderer/deadline controls.
Each cell: the existing per-slot direct-bridge warmup, then 20 render warmup
frames and 300 measured source frames, three slots. For each resolution/control, run the identical
qualified successor with audit logging on/off in alternating order. This is
12 cells / 3,600 source frames per board, not repeated independent sessions.
Record actual ordering, source/binary/model/runtime hashes and exact arguments.
Log-on/off comparisons quantify buffered-recording overhead descriptively, not
all observer/ownership-check overhead or optimization; both modes keep the
same ownership checks and draw-boundary wait.
Report draw counts separately from source counts, including repeated draws,
accepted-but-not-drawn sources, terminal drops, and age distributions.

Before every cell require temperature <=55 C (up to five-minute cooling wait).
Stop a cell at >=80 C, renderer error, invalid source/texture ownership,
noncontiguous/missing telemetry, or 180-second timeout. Retain every cell and
failure. No replacement samples, retries, scene selection, or budget changes
after capture. A new engineering successor requires a distinct identity if a
defect is discovered after measurements start.

## Freeze and handoff

Before paper-facing runs require numerical fixture/source checks, synthetic
draw-provenance qualification, independent approval, and a hash-bound freeze.
No further NPU training/compilation if the accepted board models remain valid.
Copy completed logs to the laptop and verify every hash before declaring the
board finished. Stop only our experiment/display processes, then ask the author
to switch boards; do not infer access to the Radxa from Orange Pi availability.
Update the paper only after independent verification of the final outcome.

Official signal semantics checked on 2026-09-14:
https://docs.godotengine.org/en/4.6/classes/class_renderingserver.html#signals
