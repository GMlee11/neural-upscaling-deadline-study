"""Disjoint engineering qualification / frozen composition capture. No retries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path('/home/paper3/experiments/paper1-composition-audit-v1')
OLD = Path('/home/paper3/experiments/paper1-rk3566-v1/engineering')
PROJECT = BASE / 'engineering/repo/demo/godot_upscaling_benchmark'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def schedule():
    rows = []
    for i, (width, control) in enumerate([(320, 'bicubic'), (320, 'always'),
            (320, 'scheduler'), (640, 'scheduler'), (640, 'always'), (640, 'bicubic')]):
        for logging in ([True, False] if i % 2 == 0 else [False, True]):
            rows.append(dict(width=width, control=control, logging=logging))
    return rows


def command(row, out, frames):
    width = row['width']
    argv = [str(OLD / 'godot/Godot_v4.6.3-stable_linux.arm64'), '--windowed',
        '--resolution', '1280x720', '--rendering-method', 'gl_compatibility',
        '--rendering-driver', 'opengl3_es', '--audio-driver', 'Dummy',
        '--path', str(PROJECT), '--', '--benchmark', f'--frames={frames}',
        '--warmup-frames=20', '--fps=30', '--maximum-neural-age-frames=3',
        '--neural-refresh-period-frames=1', '--backend=heterogeneous_progressive',
        '--mode=' + ('mode_180p_to_360p' if width == 320 else 'mode_360p_to_720p'),
        '--output-dir=' + str(out), '--run-id=' + out.name, '--transport=direct_dmabuf',
        '--pipeline-depth=3', '--native-bridge-model=' + str(OLD / f'models/{width}x{width*9//16}/model.rknn'),
        '--native-bridge-method=stage_abc', '--native-bridge-slots-per-core=3',
        '--native-bridge-core-profile=rk3566_single_default', '--scene-variant=corridor_neon',
        '--transfer-reference=false', '--native-readback=false', '--capture-reference=false',
        '--snapshot-stride=300', '--direct-validation-readback=false',
        '--composition-contract=true', '--composition-audit-logging=' + str(row['logging']).lower()]
    if row['control'] == 'bicubic':
        argv.append('--forced-classical-method=bicubic')
    if row['control'] == 'scheduler':
        argv.append('--neural-refresh-policy=' + str(OLD / 'repo/results/models/rk3576_neural_refresh_paper1_v1.json'))
    return argv


def validate(out, frames, logging):
    frame_rows = [json.loads(s) for s in (out / 'godot_frames.jsonl').read_text().splitlines()]
    assert [r['frame_id'] for r in frame_rows] == list(range(frames)), 'source telemetry incomplete'
    events = [json.loads(s) for s in (out / 'composition.jsonl').read_text().splitlines()]
    header = events[0]
    assert header['source_count'] == frames and not header['errors'], header
    assert header['draw_count'] > 0 and header['logging_enabled'] == logging
    if logging:
        draws = [r for r in events if r['event'] == 'draw']
        sources = {r['source_id']: r['capture_usec'] for r in events if r['event'] == 'source'}
        terminals = [r for r in events if r['event'] == 'terminal']
        assert len(sources) == frames and len(terminals) == frames
        assert len([r for r in events if r['event'] == 'source']) == frames
        assert sorted(sources) == list(range(frames))
        assert [r['source_id'] for r in terminals] == list(range(frames))
        by_source = {r['frame_id']: r for r in frame_rows}
        for terminal in terminals:
            assert terminal['response_eligible'] == by_source[terminal['source_id']]['strict_same_frame_neural']
        assert [r['draw_id'] for r in draws] == list(range(header['draw_count']))
        for draw in draws:
            if draw['selected_path'] == 'blank':
                assert all(draw[k] == -1 for k in ('base_source_id', 'neural_source_id', 'texture_rid', 'source_capture_usec', 'age_at_post_ms', 'age_at_pre_ms'))
                assert not draw['within_one_frame_at_post']
                continue
            assert draw['source_capture_usec'] == sources[draw['base_source_id']]
            assert draw['source_capture_usec'] <= draw['pre_draw_usec'] <= draw['post_draw_usec']
            assert draw['selected_path'] in ('classical', 'neural')
            assert (draw['neural_source_id'] == draw['base_source_id']) == (draw['selected_path'] == 'neural')
            assert abs(draw['age_at_post_ms'] - (draw['post_draw_usec'] - draw['source_capture_usec']) / 1000) < 0.001
        if header['schema'] >= 2:
            captured = [r for r in events if r['event'] == 'captured']
            released = [r for r in events if r['event'] == 'release']
            captures = {r['native_token']: r for r in captured}
            releases = {r['native_token']: r for r in released}
            assert len(captures) == len(captured) == len(releases) == len(released)
            assert captures.keys() == releases.keys()
            for token, capture in captures.items():
                release = releases[token]
                assert capture['source_id'] == release['source_id']
                selected = [r for r in draws if r['native_token'] == token]
                assert release['last_draw'] == max((r['draw_id'] for r in selected), default=-1)
                for draw in selected:
                    assert draw['neural_source_id'] == capture['source_id']
                    assert capture['recorded_usec'] <= draw['pre_draw_usec'] <= draw['post_draw_usec'] <= release['recorded_usec']
    return {'source_frames': frames, 'draw_count': header['draw_count'], 'valid': True}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--phase', choices=['engineering', 'capture'], required=True)
    ap.add_argument('--identity', required=True)
    args = ap.parse_args()
    assert os.uname().nodename == 'paper3-opi3b'
    assert args.identity.replace('-', '').replace('_', '').isalnum()
    if args.phase == 'capture':
        freeze = json.loads((BASE / 'freeze.json').read_text())
        assert freeze['protocol'] == 'paper1_composition_audit_v1'
        assert freeze['independent_approval'] is True
        review = BASE / 'independent-review.md'
        assert sha(review) == freeze['review_sha256']
        assert 'Decision: CONDITIONAL GO' in review.read_text()
        assert 'No remaining RK3566 source blocker was identified.' in review.read_text()
        assert freeze['review_disposition'] == 'CONDITIONAL GO: final identity freeze, RK3566 only'
        assert args.identity == freeze['capture_identity'] == 'capture-v1'
        assert freeze['schedule'] == schedule()
        assert freeze['packages'] == subprocess.check_output(['dpkg-query','-W'], text=True)
        assert freeze['kernel'] == subprocess.check_output(['uname','-a'], text=True).strip()
        assert freeze['cpu_governor'] == Path('/sys/devices/system/cpu/cpufreq/policy0/scaling_governor').read_text().strip()
        assert freeze['gpu_npu_governors'] == {str(p):p.read_text().strip() for p in Path('/sys/class/devfreq').glob('*/governor')}
        required = [BASE / 'run_composition_audit_v1.py', PROJECT / 'main.gd',
                    PROJECT / 'composition_audit.gd', OLD / 'models/320x180/model.rknn',
                    OLD / 'models/640x360/model.rknn', OLD / 'godot/Godot_v4.6.3-stable_linux.arm64',
                    PROJECT / 'native_bridge/bin/librk3576_native_bridge.so', OLD / 'sdk/lib/librknnrt.so']
        assert all(str(p) in freeze['files'] for p in required)
        for path, digest in freeze['files'].items():
            assert sha(Path(path)) == digest, path
    out = BASE / args.phase / args.identity
    out.mkdir(parents=True, exist_ok=False)
    rows = schedule()
    frames = 300 if args.phase == 'capture' else 8
    env = os.environ.copy()
    env.update(DISPLAY=':2', XAUTHORITY=str(BASE / 'engineering/display/Xauthority'),
        LD_LIBRARY_PATH=str(OLD / 'sdk/lib') + ':' + str(OLD / 'sdk/usr/lib/aarch64-linux-gnu'), OMP_NUM_THREADS='2')
    state = dict(phase=args.phase, identity=args.identity, status='RUNNING', rows=[])
    try:
        for index, row in enumerate(rows):
            target = out / f'{index:02d}_{row["width"]}_{row["control"]}_{row["logging"]}'
            target.mkdir()
            argv = command(row, target, frames)
            (target / 'command.json').write_text(json.dumps(argv, indent=2) + '\n')
            temp = lambda: int(Path('/sys/class/thermal/thermal_zone0/temp').read_text()) / 1000
            until = time.monotonic() + 300
            while temp() > 55:
                if time.monotonic() > until:
                    raise RuntimeError('cooling limit')
                time.sleep(1)
            record = dict(row, index=index, status='STARTED')
            state['rows'].append(record)
            with (target/'stdout.log').open('x') as stdout, (target/'stderr.log').open('x') as stderr, (target/'system.jsonl').open('x') as telemetry:
                start = time.monotonic()
                proc = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    while proc.poll() is None:
                        temperature = temp()
                        telemetry.write(json.dumps(dict(monotonic=time.monotonic(), temperature_c=temperature)) + '\n')
                        telemetry.flush()
                        if temperature >= 80 or time.monotonic() - start > 180:
                            raise RuntimeError('thermal or timeout stop')
                        time.sleep(.5)
                    if proc.returncode:
                        raise RuntimeError(f'renderer exit {proc.returncode}')
                finally:
                    if proc.poll() is None:
                        proc.terminate()
                        try:
                            proc.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            proc.wait()
            assert 'ERROR:' not in (target / 'stderr.log').read_text(), 'renderer error'
            record.update(validate(target, frames, row['logging']), status='COMPLETE')
            print(f'COMPLETE {index+1}/{len(rows)} {target.name}', flush=True)
            (out / 'progress.json').write_text(json.dumps(state, indent=2) + '\n')
        state['status'] = 'COMPLETE'
    except Exception as error:
        state.update(status='FAILED', error=repr(error))
        raise
    finally:
        if args.phase == 'capture':
            mismatches = [path for path,digest in freeze['files'].items() if sha(Path(path)) != digest]
            if mismatches:
                state.update(status='FAILED', source_changed=mismatches)
        (out / 'terminal.json').write_text(json.dumps(state, indent=2) + '\n')
        manifest = {str(p.relative_to(out)): sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
        (out / 'sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    main()
