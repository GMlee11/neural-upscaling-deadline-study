# Independent Paper 1 composition-audit revision-2 review

Date: 2026-09-14

Decision: CONDITIONAL GO

Scope: GO to final identity-freeze creation for the qualified RK3566/Orange Pi 3B successor. No remaining RK3566 source blocker was identified. This is not blanket approval of the later RK3576 path and does not itself execute or start capture. Complete and verify the final manifest before the prescribed single RK3566 capture session. No additional scientific experiment is requested.

## Reviewed state and method

Main checkout HEAD was `e4be268a87faafab94d62bed97e8f233e6166c27` (tree `10ae4b69b8a50c73ac65adaf07a53bdc49dd0a23`), with explicitly permitted uncommitted engineering changes. The hashes below identify the reviewed bytes, not an assertion that HEAD contains them. Read-only source and saved-evidence inspection was performed; no renderer, generator, experiment, board connection, or inference was run. Only this report was created, as expressly authorized.

The proposed boundary is root-output selection during Godot's viewport-update interval. It is not GPU completion, scanout, full-panel provenance, or proof of perceptual usefulness. Godot's global pre/post signals alone are insufficient; the qualified source ordering, selected-resource checks and ownership rules are essential.

## Verified closures and evidence

- Qualified selection paths use `audit.select()`, with versioned pre/post state comparison. The production direct benchmark excludes the other backend/control paths; interactive mutation paths return in benchmark mode. The audit-owned completion signal is emitted after the pending state is cleared and validation performed. Integrity errors remain recorded and schedule failure finalization, so their events must not be treated as accepted scientific draws.
- Exact source/slot/token transitions reject stale identities and release while selected. Production detaches to fallback before audited release and then consumes the native token. The RK3566 native bridge propagates runtime release failures to the recorder's failure return.
- Source advance is blocked while native capture is outstanding, without waiting for inference. The fast-completion branch handles capture completion before writing. The source-coded native fixture exercises retained captures while the live source has advanced.
- Ordinary exit finalization preserves failed prefixes. Write length, error and readback checks prevent successful finalization on write failure; stderr supplies a separately labeled fallback. Hard kill/power-loss loss of buffered events is explicitly an incomplete/failed run, not a successful zero result.
- Engineering archive SHA-256 matches `2ae71fcf14e0c48f96f0c4747d78104303f943c9525e62abe7a40acf91c706c7`. All 236 manifest entries match archive bytes and extracted files; the archive contains those entries plus the manifest.
- `synthetic-v6/valid.jsonl`: 9 sources, 46 draws (27 classical, 18 neural, 1 blank), 9 captures, 9 releases, no errors. Neural source identities cover 0 through 8. Saved log contains the final PASS marker and all nine expected fault rejections. The fixture tests production selection/wait hooks; its injected error callback is overridden for inspection, rather than exercising process exit for every negative case.
- `integration-v4`: all 12 cells COMPLETE, 8 source frames each, with empty audit error lists, including logging on/off.
- `native-source-v1`: each resolution records sources 0 through 8 exactly once, all maximum input errors zero, with delayed consumers and live-source advancement visible in the records. Both runs contain benchmark-completion markers.
- The three source hashes in `engineering-qualified-v2.json` match current `main.gd`, `composition_audit.gd`, and `qualify_composition_audit.gd`. The recorded unchanged computational identities include native binary `37959be9d26b29c7e63bdce88db4babbaa13e7d65c5a93ed502f1dace344cf95` and the previously accepted 16-case numerical qualification. This review verifies the saved records, not the physical board anew.

## Remaining condition: RK3576, not the present RK3566 freeze

The later RK3576 path is not covered by this GO. In `native_bridge/src/rk3576_native_bridge.cpp`, the non-`PAPER1_TARGET_RK3566` release branch marks `slot_released` before calling the runtime and ignores its return. `consume_direct_frame()` refreshes release/error state only in the RK3566 build. In `main.gd::_record_benchmark_frame`, a failed native consume returns false only for `rk3566_single_default`.

Concrete counterexample: a final-frame runtime release error on RK3576 can leave the audit's generation recorded as released and permit apparently normal completion. Before the RK3576 freeze, propagate actual release success/failure through the opt-in successor bridge and recorder, and qualify a final-frame release failure. Preserve historical non-audit behavior and sealed evidence. This bounded requirement does not block the currently qualified RK3566 source.

## Final freeze requirements, not additional source defects

Bind the exact reviewed deployment, actual shader/project assets, policy, runner, native binary, models, runtime, protocol, qualification records, review and fixed schedule before capture. Resolve Windows/Linux byte identities explicitly. Keep logging-on/off ownership and capture waits identical. The existing capture-hold/detach changes alter scheduling, so results describe this disclosed successor, not retroactive validation of the original campaigns. RK3576 still requires its own board-specific gate after the authorized swap.

## Examined file SHA-256 identities

| File (repository-relative) | SHA-256 |
|---|---|
| docs/paper1_composition_audit_v1.md | 86727b52529cbdd36b7a252aa1c6712b4f6cc73ddb6adffc3f201c5b9f6e6ea0 |
| demo/godot_upscaling_benchmark/main.gd | e8dcf25a9fd44e89112e46b190a77b12275e5f970cbb583dc5959ce603bea630 |
| demo/godot_upscaling_benchmark/composition_audit.gd | b22b2b738e09c22c9f4677d07ef1fccd124f2633c62789f899d9d6d71b168e51 |
| demo/godot_upscaling_benchmark/qualify_composition_audit.gd | 9dd2eaf25b77a1994d787be7c478fc37cadea6042471e1135b47cd30bd90083e |
| demo/godot_upscaling_benchmark/qualify_composition_capture.gd | 3acae7dd2eb4cbfd86e8a39f6c6cd6ee9c7187fe20af41251f3fe58b08941845 |
| demo/godot_upscaling_benchmark/qualify_composition_capture.tscn | 5a64d4c028d10fbdc310fbc5e6acad31b6e748bf9c337cb82ba680a57845061f |
| demo/godot_upscaling_benchmark/native_bridge/src/rk3576_native_bridge.cpp | c0906931e505cdb62bf4bcbf82a906871996296b09573e917175dce4b0b9a5e0 |
| scripts/rk3566/run_composition_audit_v1.py | fccd0bd111c82c31a5570082f2e2820ac904c0da095a471c849e1d43eb209a2b |
| scripts/rk3566/seal_composition_engineering_v1.py | d9fb2697c0c813336de47299117862e9f824e523ce6a1ef78db700ffc5fe78f7 |
| results/rk3566/paper1_composition_audit_v1/engineering-evidence-v2.tar.gz | 2ae71fcf14e0c48f96f0c4747d78104303f943c9525e62abe7a40acf91c706c7 |

