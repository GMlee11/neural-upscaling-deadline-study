"""Bind reviewed, qualified deployment; never run capture or overwrite a freeze."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
from run_composition_audit_v1 import BASE, OLD, PROJECT, sha, schedule

ap = argparse.ArgumentParser()
ap.add_argument('--source-commit',required=True)
ap.add_argument('--review-turn',required=True)
args = ap.parse_args()
assert not (BASE/'capture').exists()
review = BASE/'independent-review.md'
text = review.read_text()
assert 'Decision: CONDITIONAL GO' in text
assert 'Scope: GO to final identity-freeze creation for the qualified RK3566/Orange Pi 3B successor. No remaining RK3566 source blocker was identified.' in text
qualification = json.loads((BASE/'engineering/engineering-qualified-v2.json').read_text())
for path,digest in qualification['source_files'].items():
    assert sha(PROJECT/path) == digest, path
for path,digest in qualification['unchanged_computational_assets'].items():
    assert sha(OLD.parent/path) == digest, path
files = set()
for p in PROJECT.rglob('*'):
    if p.is_file() and p.suffix not in ('.o','.os','.a','.pyc') and '__pycache__' not in p.parts and 'shader_cache' not in p.parts and p.name not in ('.sconsign.dblite','uid_cache.bin'):
        files.add(p)
for path in qualification['unchanged_computational_assets']:
    files.add(OLD.parent/path)
files.update([BASE/'run_composition_audit_v1.py', BASE/'freeze_composition_audit_v1.py',
              BASE/'protocol.md', review, BASE/'engineering/engineering-qualified-v2.json',
              BASE/'engineering/engineering-evidence-v2.sha256.json',
              OLD/'repo/results/models/rk3576_neural_refresh_paper1_v1.json'])
record = dict(protocol='paper1_composition_audit_v1',schema=2,
    capture_identity='capture-v1',independent_approval=True,review_turn=args.review_turn,
    review_disposition='CONDITIONAL GO: final identity freeze, RK3566 only',
    review_sha256=sha(review),source_commit=args.source_commit,
    frozen_at_utc=datetime.now(timezone.utc).isoformat(),schedule=schedule(),
    packages=subprocess.check_output(['dpkg-query','-W'],text=True),
    kernel=subprocess.check_output(['uname','-a'],text=True).strip(),
    cpu_governor=Path('/sys/devices/system/cpu/cpufreq/policy0/scaling_governor').read_text().strip(),
    gpu_npu_governors={str(p):p.read_text().strip() for p in Path('/sys/class/devfreq').glob('*/governor')},
    files={str(p):sha(p) for p in sorted(files)})
with (BASE/'freeze.json').open('x') as out:
    json.dump(record,out,indent=2)
print('FROZEN',sha(BASE/'freeze.json'),len(files))
