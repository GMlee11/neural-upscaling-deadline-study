"""Launch the single frozen capture, surviving an SSH transport interruption."""
import json
import os
from pathlib import Path
import subprocess

base = Path('/home/paper3/experiments/paper1-180p-output-v1')
assert (base / 'freeze.json').is_file()
assert not (base / 'capture-v1').exists()
with (base / 'capture-launch.log').open('x') as stream:
    process = subprocess.Popen(
        ['/usr/bin/python3', '-B', str(base / 'run_rk3566.py'), 'capture'],
        cwd=str(base), stdin=subprocess.DEVNULL, stdout=stream,
        stderr=subprocess.STDOUT, start_new_session=True)
with (base / 'capture-launch.pid').open('x') as stream:
    stream.write(str(process.pid) + '\n')
print(json.dumps({'pid': process.pid, 'capture': str(base / 'capture-v1')}))
