"""Board-local setup: immutable predecessor read, new project copy only."""
from pathlib import Path
import hashlib
import json
import shutil

BASE=Path(__file__).resolve().parent
PRIOR=Path('/home/paper3/experiments/paper1-corrected-runtime-v1')
assert BASE==Path('/home/paper3/experiments/paper1-180p-output-v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=PRIOR/'freeze.json'
assert sha(freeze)=='97661ab591324a3d6a276835bee985ad594725482ecd5bb1c836d8f65fd5b547'
bound=json.loads(freeze.read_text())['files']
for name,digest in bound.items():
    assert sha(Path(name))==digest,name
for name,digest in json.loads((BASE/'package-sha256.json').read_text()).items():
    assert sha(BASE/name)==digest,name
shutil.copytree(PRIOR/'project',BASE/'project',ignore=shutil.ignore_patterns('.godot'))
(BASE/'project/.godot').mkdir()
shutil.copyfile(PRIOR/'project/.godot/extension_list.cfg',BASE/'project/.godot/extension_list.cfg')
shutil.copyfile(BASE/'main.gd',BASE/'project/main.gd')
(BASE/'engineering/display').mkdir(parents=True)
print('NEW_WORKSPACE_READY; old freeze and package hashes verified')
