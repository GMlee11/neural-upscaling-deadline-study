"""Start an authenticated user-owned X server; never export authentication."""
import os
from pathlib import Path
import secrets
import subprocess
import time

base=Path('/home/paper3/experiments/paper1-180p-output-v1')
directory=base/'engineering/display'
assert not Path('/tmp/.X11-unix/X2').exists(), 'display already exists; inspect first'
auth=directory/'Xauthority'
with auth.open('x'):
    pass
auth.chmod(0o600)
subprocess.run(['xauth','-f',str(auth),'add',':2','MIT-MAGIC-COOKIE-1',secrets.token_hex(16)],check=True)
argv=['/usr/lib/xorg/Xorg',':2','-auth',str(auth),'-nolisten','tcp','-noreset',
      '-seat','seat-paper1','-novtswitch','-sharevts','-logfile',str(directory/'Xorg.log')]
with (directory/'launch.log').open('x') as log:
    process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
for _ in range(30):
    if process.poll() is not None:
        raise RuntimeError((directory/'launch.log').read_text())
    if Path('/tmp/.X11-unix/X2').exists():
        break
    time.sleep(.5)
env=dict(os.environ,DISPLAY=':2',XAUTHORITY=str(auth))
result=subprocess.run(['glxinfo','-B'],env=env,capture_output=True,text=True,check=True)
with (directory/'glxinfo.txt').open('x') as f:
    f.write(result.stdout)
assert 'Mali' in result.stdout and 'llvmpipe' not in result.stdout
print(result.stdout)
print('DISPLAY_PID',process.pid)
