"""Credential-free snapshot of this successor only; no historical mutations."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile

parser=argparse.ArgumentParser()
parser.add_argument('phase',choices=['qualification','capture'])
args=parser.parse_args()
base=Path('/home/paper3/experiments/paper1-180p-output-v1')
if args.phase=='qualification':
    assert (base/'qualification-v2.json').is_file()
else:
    assert (base/'capture-v1/terminal.json').is_file()
archive=base/(args.phase+'-evidence-v1.tar.gz')
assert not archive.exists()
selected=[]
for p in sorted(base.rglob('*')):
    if not p.is_file() or p.is_symlink():
        continue
    rel=p.relative_to(base)
    if any(part in ('__pycache__','.git') for part in rel.parts):
        continue
    if '.godot' in rel.parts and p.name!='extension_list.cfg':
        continue
    if 'display' in rel.parts and p.name!='glxinfo.txt':
        continue
    if p.name.endswith('.tar.gz') or p.name.endswith('.pid'):
        continue
    if p.name.startswith('archive-'):
        continue
    if args.phase=='qualification' and 'capture-v1' in rel.parts:
        continue
    selected.append((p,rel.as_posix()))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={name:digest(p) for p,name in selected}
with tarfile.open(archive,'x:gz') as output:
    for p,name in selected:
        output.add(p,arcname=name,recursive=False)
assert all(digest(p)==manifest[name] for p,name in selected),'snapshot changed during archival'
record=dict(phase=args.phase,sha256=digest(archive),bytes=archive.stat().st_size,files=manifest)
with (base/('archive-'+args.phase+'.json')).open('x') as output:
    json.dump(record,output,indent=2)
print(json.dumps({k:v for k,v in record.items() if k!='files'}))
