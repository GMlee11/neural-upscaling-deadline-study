"""Install a source-and-coordinate-coded packing fixture, engineering only."""
from pathlib import Path
import shutil
BASE=Path('/home/paper3/experiments/paper1-180p-output-v1')
path=BASE/'project/qualify_composition_capture.gd'
original=BASE/'engineering/alignment-build-v1/qualify_composition_capture.original.gd'
if not original.exists():
    shutil.copyfile(path,original)
text=original.read_text()
text=text.replace('var checked_sources: Dictionary = {}','''var checked_sources: Dictionary = {}

func _parse_arguments(arguments: PackedStringArray) -> void:
\tvar filtered := PackedStringArray()
\tfor argument in arguments:
\t\tif argument != "--spatial-input-fixture=true":
\t\t\tfiltered.append(argument)
\tsuper._parse_arguments(filtered)''')
text=text.replace('var source_color_rect: ColorRect','var source_color_rect: TextureRect')
text=text.replace('source_color_rect = ColorRect.new()','source_color_rect = TextureRect.new()')
old='\tsource_color_rect.color = Color8(32 + (frame_id % 9) * 20, 96, 160)'
assert text.count(old)==1
text=text.replace(old,'''\tvar image := Image.create(lr_viewport.size.x, lr_viewport.size.y, false, Image.FORMAT_RGB8)
\tfor y in range(lr_viewport.size.y):
\t\tfor x in range(lr_viewport.size.x):
\t\t\tvar rgb := expected_pixel(frame_id,x,y)
\t\t\timage.set_pixel(x,y,Color8(rgb[0],rgb[1],rgb[2]))
\tsource_color_rect.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
\tsource_color_rect.texture = ImageTexture.create_from_image(image)

func expected_pixel(source: int, x: int, y: int) -> PackedByteArray:
\tif OS.get_cmdline_user_args().has("--spatial-input-fixture=true"):
\t\treturn PackedByteArray([32+(source%9)*20,32+(x*7+y*3)%192,16+(x*3+y*11)%192])
\treturn PackedByteArray([32+(source%9)*20,96,160])''')
old='\t\tmax_error = maxi(max_error, absi(int(data[index]) - int(expected[index % 3])))'
assert text.count(old)==1
text=text.replace(old,'''\t\tvar pixel := int(index / 3)
\t\texpected = expected_pixel(frame_id,pixel % lr_viewport.size.x,int(pixel / lr_viewport.size.x))
\t\tmax_error = maxi(max_error, absi(int(data[index]) - int(expected[index % 3])))''')
path.write_text(text)
print('SPATIAL_FIXTURE_INSTALLED')
