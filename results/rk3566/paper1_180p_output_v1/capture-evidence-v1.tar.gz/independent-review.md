# RK3566 180p-output qualification review

Decision: GO for RK3566 180p-output freeze and capture

2026-09-24. Recorded from the independent publication_review task's final
read-only AI review. Reviewer did not access the board or collect samples.

## Approved hashes

- Protocol: `62e8db5308836c06c2ef5e24c367957926ca4a396413299c7e7337b02df74560`
- Qualification archive: `99c33f734df3dc57cc910cb4c833d3e299b2c27181a145122cdc46d4b3e26533`
- qualification-v2.json: `dd05e87757c702f1e9c7211d8d3ff924a9b85b403e1627a5a1fbb71f4330e5ef`
- run_rk3566.py: `6e0f5bdf10371b890f65b4a6b733ce8fadd46bc01d3664e18b2c004527c9e667`
- Smoke start: `e3894e627a437412b6001171e8c943e5340a66fb7ad09b5a993c83e9caee6e13`
- Smoke terminal: `f48717068af2109a1a83c06f4c5dda37b85160b137d9f9b2489c4c0ea13890e7`
- Native binary: `7c90d8f9c4210f3589cd31f2d4395548e9d3efa1ec616d390e60e694152cf019`
- RK3566 model: `99ba4194c927ad6e3a2227616a4fb0ac3d99c3acde9c0edcd71034ca1a0acd66`

## Verified scope

All 714 unique regular archive members match the manifest and extracted bytes;
no escaping paths/links. All 241 local qualification bindings and 269 evidence
hashes match. The remaining 123 external board-file bindings were recorded,
not reread live by the reviewer; the runner checks them before execution.
All 71 observed mapped paths were prebound before accepted smoke-v2.

Final functional-v3 numerical recomputation matches all nine cases: input/source
correctness, residual byte exactness, composition/root tolerances and maximum
root error one level. Previously reviewed spatial-v2 and alignment-build bytes
are unchanged and match the final source/native/model/fixture bindings.

All 20 scene/control smoke cells pass inherited composition and corrected
presenter/control validators. Scheduler replay covers 20 submissions and 20
bypasses. Archived graphics evidence is accelerated Mali-G52/Panfrost, not a
software renderer. Maximum accepted smoke temperature is 50.0 C.

The reviewer reconstructed all 40 scientific commands: 300 sources, 160x90
input, 320x180 reconstruction, 1280x720 root, 30-Hz target, pipeline/slot depth
three, maximum neural age three frames. No qualification scene, spatial fixture
or 900-frame allowance enters capture. Packaged and registered protocols match.

## Conditions

One campaign only: five existing scenes, four controls, two prescribed-order
repetitions, 12,000 sources. Freeze/reverify all approved identities first.
Primary timely selection is source-matched post-draw within 33.33 ms, distinct
from the inherited 100-ms runtime acceptance allowance. Retain engineering
failures and the new aligned-view compatibility adapter. No retuning, replacement
cells, retries, resolution expansion or pooling with historical campaigns.
Any partial/failed campaign remains an outcome. A changed binding invalidates GO.

No remaining qualification blocker. This is measurement readiness, not a
performance result or manuscript approval. Complete standalone compiler console
logs were not saved; the existing provenance gap remains explicitly disclosed.
