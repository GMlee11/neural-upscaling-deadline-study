#include "rk3576_native_bridge.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cerrno>
#include <sstream>
#include <string>
#include <vector>

#include <poll.h>
#include <unistd.h>

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>
#include <drm_fourcc.h>
#include <godot_cpp/classes/rendering_server.hpp>
#include <godot_cpp/core/class_db.hpp>

#include "rk3576_dmabuf_runtime.h"

namespace godot {

// State for one frame crossing the GPU -> RGA -> NPU -> GPU path. A token owns
// its runtime ring slot until the fused GPU draw completes.
struct RK3576NativeBridge::DirectFrameState {
  mutable std::mutex mutex;
  std::uint64_t token = 0;
  std::size_t worker = 0;
  std::string topology_mode;
  std::uint32_t slot = 0;
  std::uint64_t runtime_sequence = 0;
  bool capture_submitted = false;
  bool composition_submitted = false;
  bool capture_complete = false;
  bool inference_complete = false;
  bool composition_complete = false;
  bool slot_released = false;
  int capture_fence_fd = -1;
  int composition_fence_fd = -1;
  std::chrono::steady_clock::time_point capture_started_at{};
  std::chrono::steady_clock::time_point composition_started_at{};
  std::string error;
  double gpu_capture_ms = 0.0;
  double gpu_compose_ms = 0.0;
  Rk3576DmaBufMetrics metrics{};
};

// EGL images and GLES textures are permanent views of one runtime ring slot.
// They are created lazily on Godot's render thread and reused across frames.
struct RK3576NativeBridge::RenderSlotResources {
  EGLImageKHR capture_image = EGL_NO_IMAGE_KHR;
  EGLImageKHR input_image = EGL_NO_IMAGE_KHR;
  EGLImageKHR residual_image = EGL_NO_IMAGE_KHR;
  GLuint capture_texture = 0;
  GLuint input_texture = 0;
  GLuint residual_texture = 0;
};

namespace {

using Clock = std::chrono::steady_clock;

// Convert a monotonic timestamp into the millisecond telemetry used by the
// deterministic Godot report.
double elapsed_ms(const Clock::time_point& start) {
  return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

// Copy a Godot UTF-8 string into storage that can be passed to the C runtime.
std::string to_utf8(const String& value) {
  const CharString encoded = value.utf8();
  return std::string(encoded.get_data(), static_cast<std::size_t>(encoded.length()));
}

// Resolve user-facing experiment names into the exact RKNN core masks. A
// multi-core mask owns one graph/context; it is intentionally different from
// two independent single-core contexts processing different frames.
bool resolve_core_profile(
    const std::string& profile,
    std::array<int, 3>* masks,
    std::size_t* worker_count) {
#ifdef PAPER1_TARGET_RK3566
  if (profile != "rk3566_single_default") {
    return false;
  }
  *masks = {0, 0, 0};
  *worker_count = 1;
  return true;
#else
  if (profile == "dual_independent_01") {
    *masks = {1, 2, 0};
    *worker_count = 2;
    return true;
  }
  if (profile == "single_core_0") {
    *masks = {1, 0, 0};
  } else if (profile == "single_core_1") {
    *masks = {2, 0, 0};
  } else if (profile == "single_dualcore_01") {
    *masks = {3, 0, 0};
  } else if (profile == "preloaded_split_fused_012") {
    *masks = {1, 2, 3};
    *worker_count = 3;
    return true;
  } else {
    return false;
  }
  *worker_count = 1;
  return true;
#endif
}

// Give telemetry a stable label based on physical ownership rather than the
// context's array index. Worker 0 can represent either core 0 or both cores in
// the legacy fixed profiles.
String core_mask_label(int core_mask) {
#ifdef PAPER1_TARGET_RK3566
  if (core_mask == 0) {
    return "rk3566_single_default";
  }
#endif
  if (core_mask == 1) {
    return "core_0";
  }
  if (core_mask == 2) {
    return "core_1";
  }
  if (core_mask == 3) {
    return "cores_0_1";
  }
  return "core_unassigned";
}

// Convert an EGL or GLES-owned nullable byte string into ordinary storage.
std::string copy_driver_string(const char* value) {
  return value == nullptr ? std::string() : std::string(value);
}

// Drain old GLES errors so one bridge operation reports only errors it caused.
void clear_gl_errors() {
  while (glGetError() != GL_NO_ERROR) {
  }
}

// EGL/GLES extension functions are resolved from the current render context.
PFNEGLCREATEIMAGEKHRPROC egl_create_image_function() {
  return reinterpret_cast<PFNEGLCREATEIMAGEKHRPROC>(
      eglGetProcAddress("eglCreateImageKHR"));
}

PFNGLEGLIMAGETARGETTEXTURE2DOESPROC gl_image_target_function() {
  return reinterpret_cast<PFNGLEGLIMAGETARGETTEXTURE2DOESPROC>(
      eglGetProcAddress("glEGLImageTargetTexture2DOES"));
}

// Export the current GLES command position as a Linux sync-file descriptor.
// The render thread can continue immediately; an ordinary worker later polls
// the descriptor before allowing the DMA-BUF's next device owner to proceed.
int export_native_fence(std::string* error) {
  auto create_sync = reinterpret_cast<PFNEGLCREATESYNCKHRPROC>(
      eglGetProcAddress("eglCreateSyncKHR"));
  auto duplicate_fence =
      reinterpret_cast<PFNEGLDUPNATIVEFENCEFDANDROIDPROC>(
          eglGetProcAddress("eglDupNativeFenceFDANDROID"));
  auto destroy_sync = reinterpret_cast<PFNEGLDESTROYSYNCKHRPROC>(
      eglGetProcAddress("eglDestroySyncKHR"));
  const EGLDisplay display = eglGetCurrentDisplay();
  if (create_sync == nullptr || duplicate_fence == nullptr ||
      destroy_sync == nullptr || display == EGL_NO_DISPLAY) {
    // Correctness takes priority on drivers without native-fence export. This
    // fallback is measurable because the GPU callback duration includes it.
    glFinish();
    return -1;
  }
  const EGLint attributes[] = {EGL_NONE};
  const EGLSyncKHR sync = create_sync(
      display,
      EGL_SYNC_NATIVE_FENCE_ANDROID,
      attributes);
  if (sync == EGL_NO_SYNC_KHR) {
    glFinish();
    return -1;
  }
  glFlush();
  const int fence_fd = duplicate_fence(display, sync);
  destroy_sync(display, sync);
  if (fence_fd == EGL_NO_NATIVE_FENCE_FD_ANDROID) {
    glFinish();
    return -1;
  }
  return fence_fd;
}

// Poll one exported sync file without blocking the caller. A signaled fence is
// closed exactly once; failures become frame errors instead of silent races.
void poll_native_fence(
    int* fence_fd,
    bool* complete,
    std::string* error) {
  if (*complete || *fence_fd < 0 || !error->empty()) {
    return;
  }
  pollfd descriptor{};
  descriptor.fd = *fence_fd;
  descriptor.events = POLLIN;
  const int status = poll(&descriptor, 1, 0);
  if (status == 0 || (status < 0 && errno == EINTR)) {
    return;
  }
  if (status < 0 ||
      (descriptor.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
    std::ostringstream message;
    message << "native GPU fence poll failed";
    if (status < 0) {
      message << ": errno=" << errno;
    } else {
      message << ": revents=0x" << std::hex << descriptor.revents;
    }
    *error = message.str();
  } else if ((descriptor.revents & POLLIN) != 0) {
    *complete = true;
  }
  if (*complete || !error->empty()) {
    ::close(*fence_fd);
    *fence_fd = -1;
  }
}

// Compile one shader and preserve the driver log when compilation fails.
GLuint compile_shader(
    GLenum shader_type,
    const char* source,
    std::string* error) {
  const GLuint shader = glCreateShader(shader_type);
  glShaderSource(shader, 1, &source, nullptr);
  glCompileShader(shader);
  GLint compiled = GL_FALSE;
  glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
  if (compiled == GL_TRUE) {
    return shader;
  }
  GLint log_length = 0;
  glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &log_length);
  std::string log(static_cast<std::size_t>(std::max(log_length, 1)), '\0');
  glGetShaderInfoLog(shader, log_length, nullptr, log.data());
  glDeleteShader(shader);
  *error = "GLES shader compilation failed: " + log;
  return 0;
}

constexpr const char* kCompositionVertexShader = R"GLSL(
#version 300 es
precision highp float;
const vec2 POSITIONS[3] = vec2[3](
    vec2(-1.0, -1.0),
    vec2(3.0, -1.0),
    vec2(-1.0, 3.0)
);
void main() {
  gl_Position = vec4(POSITIONS[gl_VertexID], 0.0, 1.0);
}
)GLSL";

// Flatten each RGB pixel into three adjacent R8 bytes and encode the exact
// affine INT8 value consumed by RKNN. EGL maps DMA-BUF row zero to the lower
// texture row, so source Y is inverted to keep row zero logically topmost.
constexpr const char* kInputPackingFragmentShader = R"GLSL(
#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_source;
uniform int u_width;
uniform int u_height;
uniform int u_packed_width;
uniform float u_input_scale;
uniform int u_input_zero_point;
layout(location = 0) out vec4 output_color;

void main() {
  // The image view may group two rows; the tensor remains packed NHWC.
  int byte_index = int(gl_FragCoord.y) * u_packed_width + int(gl_FragCoord.x);
  int pixel_index = byte_index / 3;
  int pixel_x = pixel_index % u_width;
  int channel = byte_index % 3;
  int model_y = pixel_index / u_width;
  int source_y =
)GLSL"
#ifdef PAPER1_TARGET_RK3566
"model_y;\n"
#else
"u_height - 1 - model_y;\n"
#endif
R"GLSL(
  vec3 source_rgb = texelFetch(
      u_source,
      ivec2(clamp(pixel_x, 0, u_width - 1), source_y),
      0).rgb;
  float source_value =
      channel == 0 ? source_rgb.r : (channel == 1 ? source_rgb.g : source_rgb.b);
  int quantized_value = clamp(
      int(round(source_value / u_input_scale)) + u_input_zero_point,
      -128,
      127);
  int raw_byte = quantized_value < 0
      ? quantized_value + 256
      : quantized_value;
  output_color = vec4(float(raw_byte) / 255.0, 0.0, 0.0, 1.0);
}
)GLSL";

// Rows in the DMA-BUF are top-to-bottom while GLES framebuffer coordinates
// are bottom-to-top. The explicit logical Y conversion keeps model indexing,
// PixelShuffle parity, and output orientation deterministic.
constexpr const char* kCompositionFragmentShader = R"GLSL(
#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_lr;
uniform sampler2D u_residual;
uniform int u_lr_width;
uniform int u_lr_height;
uniform float u_residual_scale;
uniform int u_residual_zero_point;
layout(location = 0) out vec4 output_color;
const float CUBIC_A = -0.75;

float cubic_weight(float distance_value) {
  float x = abs(distance_value);
  if (x <= 1.0) {
    return (((CUBIC_A + 2.0) * x - (CUBIC_A + 3.0)) * x * x + 1.0);
  }
  if (x < 2.0) {
    return (((CUBIC_A * x - 5.0 * CUBIC_A) * x
        + 8.0 * CUBIC_A) * x - 4.0 * CUBIC_A);
  }
  return 0.0;
}

int signed_int8_from_unorm(float encoded) {
  int raw_value = int(round(encoded * 255.0));
  return raw_value < 128 ? raw_value : raw_value - 256;
}

void main() {
  int framebuffer_x = int(gl_FragCoord.x);
  int framebuffer_y = int(gl_FragCoord.y);
  // Godot's GLES ImageTexture read/presentation convention already maps the
  // framebuffer's lower row to logical row zero. Reversing this coordinate a
  // second time produced a vertically mirrored neural result.
  int logical_output_y = framebuffer_y;
  ivec2 logical_output = ivec2(framebuffer_x, logical_output_y);

  vec2 source_position =
      (vec2(logical_output) + vec2(0.5)) * 0.5 - vec2(0.5);
  ivec2 base_pixel = ivec2(floor(source_position));
  vec2 fraction = source_position - floor(source_position);
  vec3 accumulated = vec3(0.0);
  float total_weight = 0.0;
  for (int offset_y = -1; offset_y <= 2; ++offset_y) {
    for (int offset_x = -1; offset_x <= 2; ++offset_x) {
      float weight =
          cubic_weight(float(offset_x) - fraction.x)
          * cubic_weight(float(offset_y) - fraction.y);
      ivec2 sample_pixel = clamp(
          base_pixel + ivec2(offset_x, offset_y),
          ivec2(0),
          ivec2(u_lr_width - 1, u_lr_height - 1));
      accumulated += texelFetch(u_lr, sample_pixel, 0).rgb * weight;
      total_weight += weight;
    }
  }
  vec3 base_rgb = accumulated / max(total_weight, 0.000001);

  ivec2 low_pixel = logical_output >> 1;
  int shuffle_index =
      ((logical_output.y & 1) << 1) | (logical_output.x & 1);
  vec3 correction = vec3(0.0);
  for (int color_channel = 0; color_channel < 3; ++color_channel) {
    int residual_channel = color_channel * 4 + shuffle_index;
    int residual_offset =
        (residual_channel * u_lr_height + low_pixel.y) * u_lr_width
        + low_pixel.x;
    int atlas_texel = residual_offset >> 2;
    int byte_channel = residual_offset & 3;
    ivec2 atlas_pixel = ivec2(
        atlas_texel % u_lr_width,
        atlas_texel / u_lr_width);
    vec4 packed_residual = texelFetch(
        u_residual, atlas_pixel, 0);
    float encoded = byte_channel == 0
        ? packed_residual.r
        : (byte_channel == 1
            ? packed_residual.g
            : (byte_channel == 2
                ? packed_residual.b
                : packed_residual.a));
    int quantized_value = signed_int8_from_unorm(
        encoded);
    correction[color_channel] =
        float(quantized_value - u_residual_zero_point) * u_residual_scale;
  }
  output_color = vec4(
      clamp(base_rgb + correction, vec3(0.0), vec3(1.0)),
      1.0);
}
)GLSL";

}  // namespace

// Keep construction out of the header so translation units registering the
// class do not need the private render-slot type to be complete.
RK3576NativeBridge::RK3576NativeBridge() = default;

// Destruction is intentionally equivalent to an explicit close so editor
// reloads and failed benchmark exits cannot retain RKNN contexts.
RK3576NativeBridge::~RK3576NativeBridge() {
  close();
}

// Bind only transport-neutral dictionaries and byte arrays. No RKNN or Linux
// implementation types cross into GDScript.
void RK3576NativeBridge::_bind_methods() {
  ClassDB::bind_method(
      D_METHOD(
          "configure",
          "model_path",
          "input_width",
          "input_height",
          "slot_count",
          "core_profile"),
      &RK3576NativeBridge::configure);
  ClassDB::bind_method(
      D_METHOD("upscale_residual", "input_rgb"),
      &RK3576NativeBridge::upscale_residual);
  ClassDB::bind_method(D_METHOD("status"), &RK3576NativeBridge::status);
  ClassDB::bind_method(
      D_METHOD("reset_render_probe"),
      &RK3576NativeBridge::reset_render_probe);
  ClassDB::bind_method(
      D_METHOD("probe_render_context"),
      &RK3576NativeBridge::probe_render_context);
  ClassDB::bind_method(
      D_METHOD("reserve_direct_frame", "topology_hint"),
      &RK3576NativeBridge::reserve_direct_frame);
  ClassDB::bind_method(
      D_METHOD(
          "capture_direct_frame",
          "frame_token",
          "source_texture_handle"),
      &RK3576NativeBridge::capture_direct_frame);
  ClassDB::bind_method(
      D_METHOD("upscale_direct_frame", "frame_token"),
      &RK3576NativeBridge::upscale_direct_frame);
  ClassDB::bind_method(
      D_METHOD("read_direct_validation", "frame_token"),
      &RK3576NativeBridge::read_direct_validation);
  ClassDB::bind_method(
      D_METHOD(
          "compose_direct_frame",
          "frame_token",
          "output_texture_handle"),
      &RK3576NativeBridge::compose_direct_frame);
  ClassDB::bind_method(
      D_METHOD("direct_frame_status", "frame_token"),
      &RK3576NativeBridge::direct_frame_status);
  ClassDB::bind_method(
      D_METHOD("consume_direct_frame", "frame_token"),
      &RK3576NativeBridge::consume_direct_frame);
  ClassDB::bind_method(D_METHOD("close"), &RK3576NativeBridge::close);
}

// Configure one controlled RKNN core profile so topology comparisons do not
// silently conflate multi-frame throughput with single-frame service latency.
Dictionary RK3576NativeBridge::configure(
    const String& model_path,
    int input_width,
    int input_height,
    int slot_count,
    const String& core_profile) {
  close();
  Dictionary result;
  if (input_width <= 0 || input_height <= 0) {
    return error_result("native bridge dimensions must be positive");
  }
  if (slot_count < 1 || slot_count > 8) {
    return error_result("native bridge slot count must be between 1 and 8");
  }
  const std::string requested_profile = to_utf8(core_profile);
  std::array<int, 3> requested_masks{{0, 0, 0}};
  std::size_t requested_worker_count = 0;
  if (!resolve_core_profile(
          requested_profile, &requested_masks, &requested_worker_count)) {
    return error_result("unsupported RK3576 NPU core profile");
  }

  std::lock_guard<std::mutex> lifecycle_lock(lifecycle_mutex_);
  model_path_ = to_utf8(model_path);
  input_width_ = input_width;
  input_height_ = input_height;
  output_bytes_ = input_width * input_height * 12;
  slot_count_ = slot_count;
  core_profile_ = requested_profile;
  core_masks_ = requested_masks;
  active_worker_count_ = requested_worker_count;
  char error_buffer[1024]{};
  for (std::size_t index = 0; index < active_worker_count_; ++index) {
    runtimes_[index] = rk3576_dmabuf_runtime_create(
        model_path_.c_str(),
        input_width_,
        input_height_,
        core_masks_[index],
        slot_count_,
        error_buffer,
        sizeof(error_buffer));
    if (runtimes_[index] == nullptr) {
      const std::string message =
          error_buffer[0] == '\0' ? "unknown RKNN initialization error"
                                 : error_buffer;
      for (void*& runtime : runtimes_) {
        rk3576_dmabuf_runtime_destroy(runtime);
        runtime = nullptr;
      }
      input_width_ = 0;
      input_height_ = 0;
      output_bytes_ = 0;
      slot_count_ = 0;
      active_worker_count_ = 0;
      core_masks_ = {0, 0, 0};
      core_profile_.clear();
      return error_result(message);
    }
  }
  next_worker_.store(0);
  result["ok"] = true;
  result["input_width"] = input_width_;
  result["input_height"] = input_height_;
  result["slot_count_per_core"] = slot_count_;
  result["worker_count"] = static_cast<int>(active_worker_count_);
  result["core_profile"] = String(core_profile_.c_str());
  result["worker_0_core_mask"] = core_masks_[0];
  result["worker_1_core_mask"] = core_masks_[1];
  result["worker_2_core_mask"] = core_masks_[2];
  result["output_scale"] =
      rk3576_dmabuf_runtime_output_scale(runtimes_[0]);
  result["output_zero_point"] =
      rk3576_dmabuf_runtime_output_zero_point(runtimes_[0]);
  return result;
}

// Select one NPU context round-robin, serialize only that context, and return
// the texture-ready residual with every native timing component.
Dictionary RK3576NativeBridge::upscale_residual(
    const PackedByteArray& input_rgb) {
  const auto call_start = Clock::now();
  if (active_worker_count_ == 0) {
    return error_result("native bridge is not configured");
  }
  const std::size_t worker =
      static_cast<std::size_t>(
          next_worker_.fetch_add(1) % active_worker_count_);
  std::lock_guard<std::mutex> worker_lock(runtime_mutexes_[worker]);
  void* runtime = runtimes_[worker];
  if (runtime == nullptr) {
    return error_result("native bridge is not configured");
  }
  const int expected_input_bytes = input_width_ * input_height_ * 3;
  if (input_rgb.size() != expected_input_bytes) {
    return error_result("native bridge input byte count does not match geometry");
  }

  PackedByteArray output;
  output.resize(output_bytes_);
  Rk3576DmaBufMetrics metrics{};
  const int status_code = rk3576_dmabuf_runtime_upscale_residual(
      runtime,
      input_rgb.ptr(),
      static_cast<std::size_t>(input_rgb.size()),
      output.ptrw(),
      static_cast<std::size_t>(output.size()),
      &metrics);
  if (status_code != 0) {
    return error_result(rk3576_dmabuf_runtime_last_error(runtime));
  }

  Dictionary result;
  result["ok"] = true;
  result["payload"] = output;
  result["worker_id"] = core_mask_label(core_masks_[worker]);
  result["core_mask"] = core_masks_[worker];
  result["input_copy_ms"] = metrics.input_copy_ms;
  result["npu_inference_ms"] = metrics.npu_inference_ms;
  result["residual_pack_ms"] = metrics.residual_pack_ms;
  result["output_copy_ms"] = metrics.output_copy_ms;
  result["native_total_ms"] = metrics.total_ms;
  result["bridge_total_ms"] = elapsed_ms(call_start);
  result["slot_index"] = static_cast<std::int64_t>(metrics.slot_index);
  result["sequence_id"] = static_cast<std::int64_t>(metrics.sequence_id);
  result["output_scale"] = rk3576_dmabuf_runtime_output_scale(runtime);
  result["output_zero_point"] =
      rk3576_dmabuf_runtime_output_zero_point(runtime);
  return result;
}

// Return a lightweight health snapshot used during deterministic startup.
Dictionary RK3576NativeBridge::status() const {
  Dictionary result;
  bool configured = active_worker_count_ > 0;
  for (std::size_t index = 0; index < active_worker_count_; ++index) {
    configured = configured && runtimes_[index] != nullptr;
  }
  result["configured"] = configured;
  result["input_width"] = input_width_;
  result["input_height"] = input_height_;
  result["slot_count_per_core"] = slot_count_;
  result["worker_count"] = static_cast<int>(active_worker_count_);
  result["core_profile"] = String(core_profile_.c_str());
  result["worker_0_core_mask"] = core_masks_[0];
  result["worker_1_core_mask"] = core_masks_[1];
  result["worker_2_core_mask"] = core_masks_[2];
  result["model_path"] = String(model_path_.c_str());
  {
    std::lock_guard<std::mutex> probe_lock(render_probe_mutex_);
    result["render_probe_complete"] = render_probe_complete_.load();
    result["render_probe_compatible"] = render_probe_compatible_;
    result["egl_vendor"] = String(egl_vendor_.c_str());
    result["gl_renderer"] = String(gl_renderer_.c_str());
    result["gl_version"] = String(gl_version_.c_str());
    result["render_probe_error"] = String(render_probe_error_.c_str());
  }
  return result;
}

// Reset every probe field atomically enough for a render-thread callback and
// main-thread status polling to exchange a single immutable result.
void RK3576NativeBridge::reset_render_probe() {
  std::lock_guard<std::mutex> probe_lock(render_probe_mutex_);
  render_probe_complete_.store(false);
  render_probe_compatible_ = false;
  egl_vendor_.clear();
  gl_renderer_.clear();
  gl_version_.clear();
  render_probe_error_.clear();
}

// Confirm that Godot's compatibility renderer is using EGL/GLES on this exact
// board. Extension support from a standalone `eglinfo` process is insufficient:
// direct texture sharing requires these interfaces in Godot's current context.
void RK3576NativeBridge::probe_render_context() {
  std::lock_guard<std::mutex> probe_lock(render_probe_mutex_);
  const EGLDisplay display = eglGetCurrentDisplay();
  const EGLContext context = eglGetCurrentContext();
  if (display == EGL_NO_DISPLAY || context == EGL_NO_CONTEXT) {
    render_probe_error_ =
        "Godot render thread does not expose a current EGL context";
    render_probe_complete_.store(true);
    return;
  }

  egl_vendor_ = copy_driver_string(eglQueryString(display, EGL_VENDOR));
  gl_renderer_ = copy_driver_string(
      reinterpret_cast<const char*>(glGetString(GL_RENDERER)));
  gl_version_ = copy_driver_string(
      reinterpret_cast<const char*>(glGetString(GL_VERSION)));
  const std::string egl_extensions =
      copy_driver_string(eglQueryString(display, EGL_EXTENSIONS));
  const bool has_import =
      egl_extensions.find("EGL_EXT_image_dma_buf_import") != std::string::npos;
  const bool has_modifiers =
      egl_extensions.find("EGL_EXT_image_dma_buf_import_modifiers") !=
      std::string::npos;
  if (!has_import) {
    render_probe_error_ =
        "Godot EGL display lacks EGL_EXT_image_dma_buf_import";
  } else if (!has_modifiers) {
    render_probe_error_ =
        "Godot EGL display lacks DMA-BUF modifier import support";
  } else if (gl_renderer_.empty()) {
    render_probe_error_ = "Godot GLES renderer string is unavailable";
  } else {
    render_probe_compatible_ = true;
  }
  render_probe_complete_.store(true);
}

// Return one token-owned frame state without holding the map lock while the
// render or NPU operation runs.
std::shared_ptr<RK3576NativeBridge::DirectFrameState>
RK3576NativeBridge::find_direct_frame(std::uint64_t token) const {
  std::lock_guard<std::mutex> lock(direct_frames_mutex_);
  const auto found = direct_frames_.find(token);
  return found == direct_frames_.end() ? nullptr : found->second;
}

// Reserve one direct slot from either a fixed profile or the preloaded
// split/fused context bank. The adaptive bank never overlaps a dual-core graph
// with either single-core graph, and it never queues a second frame behind one
// context. Returning busy lets Godot present its already-rendered fallback.
Dictionary RK3576NativeBridge::reserve_direct_frame(
    const String& topology_hint) {
  if (!render_probe_compatible_) {
    return error_result("direct path requires a compatible render probe");
  }
  if (active_worker_count_ == 0) {
    return error_result("direct path is not configured");
  }
  const bool adaptive_bank =
      core_profile_ == "preloaded_split_fused_012";
  const std::string requested_topology = to_utf8(topology_hint);
  std::vector<std::size_t> candidates;
  std::string selected_topology;
  if (adaptive_bank) {
    if (requested_topology == "split") {
      const std::size_t first_worker = static_cast<std::size_t>(
          next_direct_worker_.fetch_add(1) % 2);
      candidates = {first_worker, 1 - first_worker};
      selected_topology = "split";
    } else if (requested_topology == "fused") {
      candidates = {2};
      selected_topology = "fused";
    } else {
      return error_result(
          "preloaded split/fused profile requires split or fused hint");
    }
  } else {
    const std::size_t first_worker = static_cast<std::size_t>(
        next_direct_worker_.fetch_add(1) % active_worker_count_);
    for (std::size_t attempt = 0; attempt < active_worker_count_; ++attempt) {
      candidates.push_back(
          (first_worker + attempt) % active_worker_count_);
    }
    selected_topology =
        core_masks_[candidates.front()] == 3 ? "fused" : "split";
  }

  std::array<bool, 3> worker_active{{false, false, false}};
  if (adaptive_bank) {
    std::lock_guard<std::mutex> lock(direct_frames_mutex_);
    for (const auto& [token, frame] : direct_frames_) {
      static_cast<void>(token);
      if (frame->worker < worker_active.size()) {
        worker_active[frame->worker] = true;
      }
    }
    const bool split_active = worker_active[0] || worker_active[1];
    const bool fused_active = worker_active[2];
    const bool topology_conflict =
        (selected_topology == "split" && fused_active) ||
        (selected_topology == "fused" && split_active);
    if (topology_conflict) {
      Dictionary result = error_result(
          "requested NPU topology conflicts with an in-flight topology");
      result["busy"] = true;
      result["busy_reason"] = "topology_conflict";
      result["topology_mode"] = String(selected_topology.c_str());
      return result;
    }
  }

  for (const std::size_t worker : candidates) {
    // Adaptive execution admits at most one frame per physical context.
    // Static controls preserve historical slot-level queue behavior.
    if (adaptive_bank && worker_active[worker]) {
      continue;
    }
    void* runtime = runtimes_[worker];
    if (runtime == nullptr) {
      continue;
    }
    std::uint32_t slot = 0;
    std::uint64_t runtime_sequence = 0;
    const int acquire_status = rk3576_dmabuf_runtime_acquire_direct_slot(
        runtime, &slot, &runtime_sequence);
    if (acquire_status == 1) {
      continue;
    }
    if (acquire_status != 0) {
      return error_result(rk3576_dmabuf_runtime_last_error(runtime));
    }

    auto frame = std::make_shared<DirectFrameState>();
    frame->token = next_direct_token_.fetch_add(1);
    frame->worker = worker;
    frame->topology_mode = selected_topology;
    frame->slot = slot;
    frame->runtime_sequence = runtime_sequence;
    {
      std::lock_guard<std::mutex> lock(direct_frames_mutex_);
      direct_frames_[frame->token] = frame;
    }
    Dictionary result;
    result["ok"] = true;
    result["frame_token"] = static_cast<std::int64_t>(frame->token);
    result["worker_id"] = core_mask_label(core_masks_[worker]);
    result["core_mask"] = core_masks_[worker];
    result["topology_mode"] = String(selected_topology.c_str());
    result["queue_admission"] =
        adaptive_bank ? "one_frame_per_context" : "slot_bounded";
    result["worker_index"] = static_cast<int>(worker);
    result["slot_index"] = static_cast<int>(slot);
    result["output_texture_index"] =
        static_cast<int>(worker * static_cast<std::size_t>(slot_count_) + slot);
    result["sequence_id"] = static_cast<std::int64_t>(runtime_sequence);
    return result;
  }
  Dictionary result = error_result("all eligible direct DMA-BUF contexts are busy");
  result["busy"] = true;
  result["busy_reason"] =
      adaptive_bank ? "eligible_context_busy" : "all_slots_busy";
  result["topology_mode"] = String(selected_topology.c_str());
  return result;
}

// Create permanent EGLImage/texture views for one runtime slot. The system DMA
// heap produces linear buffers, so a single plane with an explicit pitch is
// sufficient for both the RGBA capture and R8 residual atlas.
bool RK3576NativeBridge::ensure_render_slot(
    const std::shared_ptr<DirectFrameState>& frame,
    std::string* error) {
  if (frame->worker >= render_slots_.size() ||
      frame->slot >= render_slots_[frame->worker].size()) {
    *error = "direct render slot index is out of range";
    return false;
  }
  auto& resource = render_slots_[frame->worker][frame->slot];
  if (resource != nullptr) {
    return true;
  }
  const EGLDisplay display = eglGetCurrentDisplay();
  if (display == EGL_NO_DISPLAY || eglGetCurrentContext() == EGL_NO_CONTEXT) {
    *error = "direct render operation has no current EGL context";
    return false;
  }
  const auto create_image = egl_create_image_function();
  const auto image_target = gl_image_target_function();
  if (create_image == nullptr || image_target == nullptr) {
    *error = "required EGLImage import functions are unavailable";
    return false;
  }
  void* runtime = runtimes_[frame->worker];
  const int capture_fd = rk3576_dmabuf_runtime_direct_capture_fd(
      runtime, frame->slot);
  const int input_fd = rk3576_dmabuf_runtime_direct_input_fd(
      runtime, frame->slot);
  const int residual_fd = rk3576_dmabuf_runtime_direct_residual_fd(
      runtime, frame->slot);
  if (capture_fd < 0 || input_fd < 0 || residual_fd < 0) {
    *error = rk3576_dmabuf_runtime_last_error(runtime);
    return false;
  }

  auto created = std::make_unique<RenderSlotResources>();
  const EGLint capture_attributes[] = {
      EGL_WIDTH,
      input_width_,
      EGL_HEIGHT,
      input_height_,
      EGL_LINUX_DRM_FOURCC_EXT,
      static_cast<EGLint>(DRM_FORMAT_ABGR8888),
      EGL_DMA_BUF_PLANE0_FD_EXT,
      capture_fd,
      EGL_DMA_BUF_PLANE0_OFFSET_EXT,
      0,
      EGL_DMA_BUF_PLANE0_PITCH_EXT,
      input_width_ * 4,
      EGL_NONE};
  created->capture_image = create_image(
      display,
      EGL_NO_CONTEXT,
      EGL_LINUX_DMA_BUF_EXT,
      nullptr,
      capture_attributes);
  if (created->capture_image == EGL_NO_IMAGE_KHR) {
    std::ostringstream message;
    message << "EGL capture DMA-BUF import failed with 0x" << std::hex
            << eglGetError();
    *error = message.str();
    return false;
  }

  // Flatten packed NHWC bytes as one R8 row three times wider than the image.
  // This preserves the exact byte order RKNN expects while remaining a GLES
  // color-renderable texture.
  const EGLint input_attributes[] = {
      EGL_WIDTH,
      (input_width_ == 160 && input_height_ == 90 ? 960 : input_width_ * 3),
      EGL_HEIGHT,
      (input_width_ == 160 && input_height_ == 90 ? 45 : input_height_),
      EGL_LINUX_DRM_FOURCC_EXT,
      static_cast<EGLint>(DRM_FORMAT_R8),
      EGL_DMA_BUF_PLANE0_FD_EXT,
      input_fd,
      EGL_DMA_BUF_PLANE0_OFFSET_EXT,
      0,
      EGL_DMA_BUF_PLANE0_PITCH_EXT,
      (input_width_ == 160 && input_height_ == 90 ? 960 : input_width_ * 3),
      EGL_NONE};
  created->input_image = create_image(
      display,
      EGL_NO_CONTEXT,
      EGL_LINUX_DMA_BUF_EXT,
      nullptr,
      input_attributes);
  if (created->input_image == EGL_NO_IMAGE_KHR) {
    std::ostringstream message;
    message << "EGL input DMA-BUF import failed with 0x" << std::hex
            << eglGetError();
    *error = message.str();
    return false;
  }

  // View the exact raw NCHW bytes four at a time through ABGR8888. Panfrost's
  // R8 external-image path retains stale cache contents after an NPU write,
  // while this ordinary four-byte format is coherent after the RGA publish.
  const EGLint residual_attributes[] = {
      EGL_WIDTH,
      input_width_,
      EGL_HEIGHT,
      input_height_ * 3,
      EGL_LINUX_DRM_FOURCC_EXT,
      static_cast<EGLint>(DRM_FORMAT_ABGR8888),
      EGL_DMA_BUF_PLANE0_FD_EXT,
      residual_fd,
      EGL_DMA_BUF_PLANE0_OFFSET_EXT,
      0,
      EGL_DMA_BUF_PLANE0_PITCH_EXT,
      input_width_ * 4,
      EGL_NONE};
  created->residual_image = create_image(
      display,
      EGL_NO_CONTEXT,
      EGL_LINUX_DMA_BUF_EXT,
      nullptr,
      residual_attributes);
  if (created->residual_image == EGL_NO_IMAGE_KHR) {
    std::ostringstream message;
    message << "EGL residual DMA-BUF import failed with 0x" << std::hex
            << eglGetError();
    *error = message.str();
    return false;
  }

  clear_gl_errors();
  glGenTextures(1, &created->capture_texture);
  glBindTexture(GL_TEXTURE_2D, created->capture_texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  image_target(
      GL_TEXTURE_2D,
      reinterpret_cast<GLeglImageOES>(created->capture_image));
  glGenTextures(1, &created->input_texture);
  glBindTexture(GL_TEXTURE_2D, created->input_texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  image_target(
      GL_TEXTURE_2D,
      reinterpret_cast<GLeglImageOES>(created->input_image));
  glGenTextures(1, &created->residual_texture);
  glBindTexture(GL_TEXTURE_2D, created->residual_texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  image_target(
      GL_TEXTURE_2D,
      reinterpret_cast<GLeglImageOES>(created->residual_image));
  const GLenum gl_error = glGetError();
  glBindTexture(GL_TEXTURE_2D, 0);
  if (gl_error != GL_NO_ERROR) {
    std::ostringstream message;
    message << "GLES DMA-BUF texture import failed with 0x" << std::hex
            << gl_error;
    *error = message.str();
    return false;
  }
  resource = std::move(created);
  return true;
}

// Copy the current Godot SubViewport texture into the reserved DMA-BUF. The
// vertical destination flip converts GLES's framebuffer origin into the
// top-to-bottom row convention consumed by RGA and the neural model.
void RK3576NativeBridge::capture_direct_frame(
    std::int64_t frame_token,
    const RID& source_viewport) {
  const auto frame = find_direct_frame(
      static_cast<std::uint64_t>(frame_token));
  if (frame == nullptr) {
    return;
  }
  const auto start = Clock::now();
  std::string error;
  int capture_fence_fd = -1;
  // ViewportTexture exposes a proxy RID whose own GLES name is zero. Resolve
  // the viewport's concrete render-target RID before asking for its GL name.
  RenderingServer* rendering_server = RenderingServer::get_singleton();
  const RID source_texture =
      rendering_server->viewport_get_texture(source_viewport);
  const std::uint64_t source_texture_handle =
      rendering_server->texture_get_native_handle(
          source_texture,
          false);
  if (source_texture_handle == 0 ||
      !ensure_render_slot(frame, &error) ||
      !ensure_input_program(&error)) {
    {
      std::lock_guard<std::mutex> lock(frame->mutex);
      frame->error = source_texture_handle == 0
          ? "Godot source texture handle is invalid"
          : error;
    }
    release_direct_slot(frame);
    return;
  }
  RenderSlotResources& resource =
      *render_slots_[frame->worker][frame->slot];

  GLint previous_read_fbo = 0;
  GLint previous_draw_fbo = 0;
  GLint previous_viewport[4]{};
  GLint previous_program = 0;
  GLint previous_vao = 0;
  GLint previous_active_texture = 0;
  GLint previous_texture_0 = 0;
  const GLboolean blend_enabled = glIsEnabled(GL_BLEND);
  const GLboolean depth_enabled = glIsEnabled(GL_DEPTH_TEST);
  const GLboolean scissor_enabled = glIsEnabled(GL_SCISSOR_TEST);
  const GLboolean cull_enabled = glIsEnabled(GL_CULL_FACE);
  glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &previous_read_fbo);
  glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &previous_draw_fbo);
  glGetIntegerv(GL_VIEWPORT, previous_viewport);
  glGetIntegerv(GL_CURRENT_PROGRAM, &previous_program);
  glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &previous_vao);
  glGetIntegerv(GL_ACTIVE_TEXTURE, &previous_active_texture);
  glActiveTexture(GL_TEXTURE0);
  glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_texture_0);
  if (capture_read_fbo_ == 0) {
    glGenFramebuffers(1, &capture_read_fbo_);
  }
  if (capture_draw_fbo_ == 0) {
    glGenFramebuffers(1, &capture_draw_fbo_);
  }
  clear_gl_errors();
  glBindFramebuffer(GL_READ_FRAMEBUFFER, capture_read_fbo_);
  glFramebufferTexture2D(
      GL_READ_FRAMEBUFFER,
      GL_COLOR_ATTACHMENT0,
      GL_TEXTURE_2D,
      static_cast<GLuint>(source_texture_handle),
      0);
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, capture_draw_fbo_);
  glFramebufferTexture2D(
      GL_DRAW_FRAMEBUFFER,
      GL_COLOR_ATTACHMENT0,
      GL_TEXTURE_2D,
      resource.capture_texture,
      0);
  const GLenum read_status = glCheckFramebufferStatus(GL_READ_FRAMEBUFFER);
  const GLenum draw_status = glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER);
  if (read_status == GL_FRAMEBUFFER_COMPLETE &&
      draw_status == GL_FRAMEBUFFER_COMPLETE) {
    // Preserve one ordinary LR RGBA texture for the later bicubic residual
    // composition while also generating the NPU's quantized input tensor.
    glBlitFramebuffer(
        0,
        0,
        input_width_,
        input_height_,
#ifdef PAPER1_TARGET_RK3566
        // RK3566's qualified GLES viewport readback is already top-to-bottom.
        0,
        0,
        input_width_,
        input_height_,
#else
        0,
        input_height_,
        input_width_,
        0,
#endif
        GL_COLOR_BUFFER_BIT,
        GL_NEAREST);
    glFramebufferTexture2D(
        GL_DRAW_FRAMEBUFFER,
        GL_COLOR_ATTACHMENT0,
        GL_TEXTURE_2D,
        resource.input_texture,
        0);
    const GLenum input_status =
        glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER);
    if (input_status == GL_FRAMEBUFFER_COMPLETE) {
      const int packed_width = input_width_ == 160 && input_height_ == 90 ? 960 : input_width_ * 3;
      const int packed_height = input_width_ == 160 && input_height_ == 90 ? 45 : input_height_;
      glViewport(0, 0, packed_width, packed_height);
      glDisable(GL_BLEND);
      glDisable(GL_DEPTH_TEST);
      glDisable(GL_SCISSOR_TEST);
      glDisable(GL_CULL_FACE);
      glUseProgram(input_program_);
      glBindVertexArray(input_vao_);
      glActiveTexture(GL_TEXTURE0);
      glBindTexture(
          GL_TEXTURE_2D,
          static_cast<GLuint>(source_texture_handle));
      glUniform1i(
          glGetUniformLocation(input_program_, "u_source"), 0);
      glUniform1i(
          glGetUniformLocation(input_program_, "u_width"), input_width_);
      glUniform1i(
          glGetUniformLocation(input_program_, "u_height"), input_height_);
      glUniform1i(glGetUniformLocation(input_program_, "u_packed_width"), packed_width);
      glUniform1f(
          glGetUniformLocation(input_program_, "u_input_scale"),
          rk3576_dmabuf_runtime_input_scale(runtimes_[frame->worker]));
      glUniform1i(
          glGetUniformLocation(input_program_, "u_input_zero_point"),
          rk3576_dmabuf_runtime_input_zero_point(
              runtimes_[frame->worker]));
      glDrawArrays(GL_TRIANGLES, 0, 3);
      capture_fence_fd = export_native_fence(&error);
    } else {
      std::ostringstream message;
      message << "GLES input framebuffer incomplete: 0x" << std::hex
              << input_status;
      error = message.str();
    }
  } else {
    std::ostringstream message;
    message << "GLES capture framebuffer incomplete: read=0x" << std::hex
            << read_status << " draw=0x" << draw_status;
    error = message.str();
  }
  const GLenum operation_error = glGetError();
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, previous_texture_0);
  glActiveTexture(previous_active_texture);
  glBindVertexArray(previous_vao);
  glUseProgram(previous_program);
  if (blend_enabled) glEnable(GL_BLEND); else glDisable(GL_BLEND);
  if (depth_enabled) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
  if (scissor_enabled) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
  if (cull_enabled) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
  glViewport(
      previous_viewport[0],
      previous_viewport[1],
      previous_viewport[2],
      previous_viewport[3]);
  glBindFramebuffer(GL_READ_FRAMEBUFFER, previous_read_fbo);
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, previous_draw_fbo);
  if (error.empty() && operation_error != GL_NO_ERROR) {
    std::ostringstream message;
    message << "GLES direct capture failed with 0x" << std::hex
            << operation_error;
    error = message.str();
  }
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    if (error.empty()) {
      frame->capture_started_at = start;
      frame->capture_fence_fd = capture_fence_fd;
      frame->capture_submitted = true;
      frame->capture_complete = frame->capture_fence_fd < 0;
      if (frame->capture_complete) {
        frame->gpu_capture_ms = elapsed_ms(start);
      }
    } else {
      frame->error = error;
    }
  }
  if (!error.empty()) {
    release_direct_slot(frame);
  }
}

// Execute the NPU graph only after the render callback confirms its source
// DMA-BUF is complete. Each RKNN context remains serialized independently.
Dictionary RK3576NativeBridge::upscale_direct_frame(
    std::int64_t frame_token) {
  const auto call_start = Clock::now();
  const auto frame = find_direct_frame(
      static_cast<std::uint64_t>(frame_token));
  if (frame == nullptr) {
    return error_result("direct frame token is unknown");
  }
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    if (!frame->error.empty()) {
      return error_result(frame->error);
    }
    if (!frame->capture_complete) {
      return error_result("direct frame capture is incomplete");
    }
  }
  Rk3576DmaBufMetrics metrics{};
  int status_code = 0;
  {
    std::lock_guard<std::mutex> worker_lock(
        runtime_mutexes_[frame->worker]);
    status_code = rk3576_dmabuf_runtime_run_direct_slot(
        runtimes_[frame->worker], frame->slot, &metrics);
  }
  if (status_code != 0) {
    const std::string message =
        rk3576_dmabuf_runtime_last_error(runtimes_[frame->worker]);
    {
      std::lock_guard<std::mutex> lock(frame->mutex);
      frame->error = message;
    }
    release_direct_slot(frame);
    return error_result(message);
  }
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    frame->metrics = metrics;
    frame->inference_complete = true;
  }
  Dictionary result;
  result["ok"] = true;
  result["frame_token"] = frame_token;
  result["worker_id"] = core_mask_label(core_masks_[frame->worker]);
  result["core_mask"] = core_masks_[frame->worker];
  result["topology_mode"] = String(frame->topology_mode.c_str());
  result["slot_index"] = static_cast<int>(frame->slot);
  result["sequence_id"] = static_cast<std::int64_t>(metrics.sequence_id);
  result["rga_input_convert_ms"] = metrics.rga_resize_ms;
  result["npu_inference_ms"] = metrics.npu_inference_ms;
  result["native_total_ms"] = metrics.total_ms;
  result["bridge_total_ms"] = elapsed_ms(call_start);
  result["output_scale"] =
      rk3576_dmabuf_runtime_output_scale(runtimes_[frame->worker]);
  result["output_zero_point"] =
      rk3576_dmabuf_runtime_output_zero_point(runtimes_[frame->worker]);
  return result;
}

// Read exact tensors for a validation-only run. This deliberately allocates
// Godot byte arrays and therefore must never be enabled in timed evidence.
Dictionary RK3576NativeBridge::read_direct_validation(
    std::int64_t frame_token) {
  const auto frame = find_direct_frame(
      static_cast<std::uint64_t>(frame_token));
  if (frame == nullptr) {
    return error_result("direct frame token is unknown");
  }
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    if (!frame->error.empty()) {
      return error_result(frame->error);
    }
    if (!frame->inference_complete || frame->composition_complete) {
      return error_result(
          "direct validation must run after inference and before composition");
    }
  }
  PackedByteArray input_rgb;
  input_rgb.resize(input_width_ * input_height_ * 3);
  PackedByteArray residual_rgb;
  residual_rgb.resize(output_bytes_);
  int status_code = 0;
  {
    std::lock_guard<std::mutex> worker_lock(
        runtime_mutexes_[frame->worker]);
    status_code = rk3576_dmabuf_runtime_copy_direct_validation(
        runtimes_[frame->worker],
        frame->slot,
        input_rgb.ptrw(),
        static_cast<std::size_t>(input_rgb.size()),
        residual_rgb.ptrw(),
        static_cast<std::size_t>(residual_rgb.size()));
  }
  if (status_code != 0) {
    return error_result(
        rk3576_dmabuf_runtime_last_error(runtimes_[frame->worker]));
  }
  Dictionary result;
  result["ok"] = true;
  result["input_rgb"] = input_rgb;
  result["residual_rgb"] = residual_rgb;
#ifdef PAPER1_TARGET_RK3566
  PackedByteArray quantized_input;
  quantized_input.resize(input_width_ * input_height_ * 3);
  const int raw_status = rk3576_dmabuf_runtime_copy_quantized_input(
      runtimes_[frame->worker], frame->slot, quantized_input.ptrw(),
      static_cast<std::size_t>(quantized_input.size()));
  if (raw_status != 0) {
    return error_result("exact input tensor readback failed");
  }
  result["input_int8"] = quantized_input;
#endif
  return result;
}

// Compile and link the direct input-packing shader once in Godot's current
// GLES context. It writes model-owned affine INT8 bytes without ARM or RGA.
bool RK3576NativeBridge::ensure_input_program(std::string* error) {
  if (input_program_ != 0) {
    return true;
  }
  const GLuint vertex_shader = compile_shader(
      GL_VERTEX_SHADER, kCompositionVertexShader, error);
  if (vertex_shader == 0) {
    return false;
  }
  const GLuint fragment_shader = compile_shader(
      GL_FRAGMENT_SHADER, kInputPackingFragmentShader, error);
  if (fragment_shader == 0) {
    glDeleteShader(vertex_shader);
    return false;
  }
  const GLuint program = glCreateProgram();
  glAttachShader(program, vertex_shader);
  glAttachShader(program, fragment_shader);
  glLinkProgram(program);
  glDeleteShader(vertex_shader);
  glDeleteShader(fragment_shader);
  GLint linked = GL_FALSE;
  glGetProgramiv(program, GL_LINK_STATUS, &linked);
  if (linked != GL_TRUE) {
    GLint log_length = 0;
    glGetProgramiv(program, GL_INFO_LOG_LENGTH, &log_length);
    std::string log(static_cast<std::size_t>(std::max(log_length, 1)), '\0');
    glGetProgramInfoLog(program, log_length, nullptr, log.data());
    glDeleteProgram(program);
    *error = "GLES input program link failed: " + log;
    return false;
  }
  input_program_ = program;
  glGenVertexArrays(1, &input_vao_);
  return true;
}

// Compile and link the fused composition shader once in Godot's current GLES
// context. A full-screen triangle avoids vertex-buffer traffic.
bool RK3576NativeBridge::ensure_composition_program(std::string* error) {
  if (compose_program_ != 0) {
    return true;
  }
  const GLuint vertex_shader = compile_shader(
      GL_VERTEX_SHADER, kCompositionVertexShader, error);
  if (vertex_shader == 0) {
    return false;
  }
  const GLuint fragment_shader = compile_shader(
      GL_FRAGMENT_SHADER, kCompositionFragmentShader, error);
  if (fragment_shader == 0) {
    glDeleteShader(vertex_shader);
    return false;
  }
  const GLuint program = glCreateProgram();
  glAttachShader(program, vertex_shader);
  glAttachShader(program, fragment_shader);
  glLinkProgram(program);
  glDeleteShader(vertex_shader);
  glDeleteShader(fragment_shader);
  GLint linked = GL_FALSE;
  glGetProgramiv(program, GL_LINK_STATUS, &linked);
  if (linked != GL_TRUE) {
    GLint log_length = 0;
    glGetProgramiv(program, GL_INFO_LOG_LENGTH, &log_length);
    std::string log(static_cast<std::size_t>(std::max(log_length, 1)), '\0');
    glGetProgramInfoLog(program, log_length, nullptr, log.data());
    glDeleteProgram(program);
    *error = "GLES composition program link failed: " + log;
    return false;
  }
  compose_program_ = program;
  glGenVertexArrays(1, &compose_vao_);
  glGenFramebuffers(1, &compose_fbo_);
  return true;
}

// Render the complete reconstructed HR frame into a Godot-owned texture. The
// raw NCHW residual never becomes an ARM array or a Godot Image.
void RK3576NativeBridge::compose_direct_frame(
    std::int64_t frame_token,
    const RID& output_texture) {
  const auto frame = find_direct_frame(
      static_cast<std::uint64_t>(frame_token));
  if (frame == nullptr) {
    return;
  }
  const auto start = Clock::now();
  std::string error;
  int composition_fence_fd = -1;
  const std::uint64_t output_texture_handle =
      RenderingServer::get_singleton()->texture_get_native_handle(
          output_texture,
          false);
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    if (!frame->error.empty()) {
      return;
    }
    if (!frame->inference_complete) {
      frame->error = "direct inference is incomplete";
      error = frame->error;
    }
  }
  if (error.empty() &&
      (output_texture_handle == 0 ||
       !ensure_render_slot(frame, &error) ||
       !ensure_composition_program(&error))) {
    if (error.empty()) {
      error = "Godot output texture handle is invalid";
    }
  }
  if (!error.empty()) {
    {
      std::lock_guard<std::mutex> lock(frame->mutex);
      frame->error = error;
    }
    release_direct_slot(frame);
    return;
  }

  RenderSlotResources& resource =
      *render_slots_[frame->worker][frame->slot];
  GLint previous_draw_fbo = 0;
  GLint previous_viewport[4]{};
  GLint previous_program = 0;
  GLint previous_vao = 0;
  GLint previous_active_texture = 0;
  GLint previous_texture_0 = 0;
  GLint previous_texture_1 = 0;
  const GLboolean blend_enabled = glIsEnabled(GL_BLEND);
  const GLboolean depth_enabled = glIsEnabled(GL_DEPTH_TEST);
  const GLboolean scissor_enabled = glIsEnabled(GL_SCISSOR_TEST);
  const GLboolean cull_enabled = glIsEnabled(GL_CULL_FACE);
  glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, &previous_draw_fbo);
  glGetIntegerv(GL_VIEWPORT, previous_viewport);
  glGetIntegerv(GL_CURRENT_PROGRAM, &previous_program);
  glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &previous_vao);
  glGetIntegerv(GL_ACTIVE_TEXTURE, &previous_active_texture);
  glActiveTexture(GL_TEXTURE0);
  glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_texture_0);
  glActiveTexture(GL_TEXTURE1);
  glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_texture_1);

  clear_gl_errors();
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, compose_fbo_);
  glFramebufferTexture2D(
      GL_DRAW_FRAMEBUFFER,
      GL_COLOR_ATTACHMENT0,
      GL_TEXTURE_2D,
      static_cast<GLuint>(output_texture_handle),
      0);
  const GLenum framebuffer_status =
      glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER);
  if (framebuffer_status == GL_FRAMEBUFFER_COMPLETE) {
    glViewport(0, 0, input_width_ * 2, input_height_ * 2);
    glDisable(GL_BLEND);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_SCISSOR_TEST);
    glDisable(GL_CULL_FACE);
    glUseProgram(compose_program_);
    glBindVertexArray(compose_vao_);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, resource.capture_texture);
    glUniform1i(glGetUniformLocation(compose_program_, "u_lr"), 0);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, resource.residual_texture);
    // Re-import the published output after each NPU/RGA handoff. Panfrost
    // retains the zero-filled cache when one EGLImage sibling is held across
    // external writes; merely rebinding that same image is insufficient.
    const auto create_image = egl_create_image_function();
    const auto image_target = gl_image_target_function();
    const auto destroy_image =
        reinterpret_cast<PFNEGLDESTROYIMAGEKHRPROC>(
            eglGetProcAddress("eglDestroyImageKHR"));
    const EGLDisplay display = eglGetCurrentDisplay();
    const int residual_fd = rk3576_dmabuf_runtime_direct_residual_fd(
        runtimes_[frame->worker], frame->slot);
    if (create_image == nullptr || image_target == nullptr ||
        destroy_image == nullptr || display == EGL_NO_DISPLAY ||
        residual_fd < 0) {
      error = "GLES residual EGLImage refresh function is unavailable";
    } else {
      if (resource.residual_image != EGL_NO_IMAGE_KHR) {
        destroy_image(display, resource.residual_image);
      }
      const EGLint residual_attributes[] = {
          EGL_WIDTH,
          input_width_,
          EGL_HEIGHT,
          input_height_ * 3,
          EGL_LINUX_DRM_FOURCC_EXT,
          static_cast<EGLint>(DRM_FORMAT_ABGR8888),
          EGL_DMA_BUF_PLANE0_FD_EXT,
          residual_fd,
          EGL_DMA_BUF_PLANE0_OFFSET_EXT,
          0,
          EGL_DMA_BUF_PLANE0_PITCH_EXT,
          input_width_ * 4,
          EGL_NONE};
      resource.residual_image = create_image(
          display,
          EGL_NO_CONTEXT,
          EGL_LINUX_DMA_BUF_EXT,
          nullptr,
          residual_attributes);
      if (resource.residual_image == EGL_NO_IMAGE_KHR) {
        error = "GLES residual EGLImage re-import failed";
      }
    }
    if (error.empty()) {
      image_target(
          GL_TEXTURE_2D,
          reinterpret_cast<GLeglImageOES>(resource.residual_image));
    }
    glUniform1i(glGetUniformLocation(compose_program_, "u_residual"), 1);
    glUniform1i(
        glGetUniformLocation(compose_program_, "u_lr_width"), input_width_);
    glUniform1i(
        glGetUniformLocation(compose_program_, "u_lr_height"), input_height_);
    glUniform1f(
        glGetUniformLocation(compose_program_, "u_residual_scale"),
        rk3576_dmabuf_runtime_output_scale(runtimes_[frame->worker]));
    glUniform1i(
        glGetUniformLocation(compose_program_, "u_residual_zero_point"),
        rk3576_dmabuf_runtime_output_zero_point(runtimes_[frame->worker]));
    if (error.empty()) {
      glDrawArrays(GL_TRIANGLES, 0, 3);
      composition_fence_fd = export_native_fence(&error);
    }
  } else {
    std::ostringstream message;
    message << "GLES output framebuffer incomplete: 0x" << std::hex
            << framebuffer_status;
    error = message.str();
  }
  const GLenum operation_error = glGetError();

  glActiveTexture(GL_TEXTURE1);
  glBindTexture(GL_TEXTURE_2D, previous_texture_1);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, previous_texture_0);
  glActiveTexture(previous_active_texture);
  glBindVertexArray(previous_vao);
  glUseProgram(previous_program);
  if (blend_enabled) glEnable(GL_BLEND); else glDisable(GL_BLEND);
  if (depth_enabled) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
  if (scissor_enabled) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
  if (cull_enabled) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
  glViewport(
      previous_viewport[0],
      previous_viewport[1],
      previous_viewport[2],
      previous_viewport[3]);
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, previous_draw_fbo);
  if (error.empty() && operation_error != GL_NO_ERROR) {
    std::ostringstream message;
    message << "GLES direct composition failed with 0x" << std::hex
            << operation_error;
    error = message.str();
  }
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    if (error.empty()) {
      frame->composition_started_at = start;
      frame->composition_fence_fd = composition_fence_fd;
      frame->composition_submitted = true;
      frame->composition_complete = frame->composition_fence_fd < 0;
      if (frame->composition_complete) {
        frame->gpu_compose_ms = elapsed_ms(start);
      }
    } else {
      frame->error = error;
    }
  }
  // A successful output texture remains owned by this token until Godot has
  // presented it. Releasing here let a newer request overwrite the texture
  // before replay-ordered telemetry and validation consumed the older frame.
  if (!error.empty()) {
    release_direct_slot(frame);
  }
}

// Return a lock-protected state snapshot used by GDScript render-callback
// polling. No pixel payload crosses this interface.
Dictionary RK3576NativeBridge::direct_frame_status(
    std::int64_t frame_token) {
  const auto frame = find_direct_frame(
      static_cast<std::uint64_t>(frame_token));
  if (frame == nullptr) {
    return error_result("direct frame token is unknown");
  }
  Dictionary result;
  std::lock_guard<std::mutex> lock(frame->mutex);
  if (frame->capture_submitted && !frame->capture_complete) {
    poll_native_fence(
        &frame->capture_fence_fd,
        &frame->capture_complete,
        &frame->error);
    if (frame->capture_complete) {
      frame->gpu_capture_ms = elapsed_ms(frame->capture_started_at);
    }
  }
  if (frame->composition_submitted && !frame->composition_complete) {
    poll_native_fence(
        &frame->composition_fence_fd,
        &frame->composition_complete,
        &frame->error);
    if (frame->composition_complete) {
      frame->gpu_compose_ms = elapsed_ms(frame->composition_started_at);
    }
  }
  result["ok"] = frame->error.empty();
  result["frame_token"] = frame_token;
  result["capture_complete"] = frame->capture_complete;
  result["inference_complete"] = frame->inference_complete;
  result["composition_complete"] = frame->composition_complete;
  result["slot_released"] = frame->slot_released;
  result["error"] = String(frame->error.c_str());
  result["gpu_capture_ms"] = frame->gpu_capture_ms;
  result["gpu_compose_ms"] = frame->gpu_compose_ms;
  result["worker_id"] = core_mask_label(core_masks_[frame->worker]);
  result["core_mask"] = core_masks_[frame->worker];
  result["topology_mode"] = String(frame->topology_mode.c_str());
  result["slot_index"] = static_cast<int>(frame->slot);
  result["sequence_id"] =
      static_cast<std::int64_t>(frame->runtime_sequence);
  result["rga_input_convert_ms"] = frame->metrics.rga_resize_ms;
  result["residual_publish_ms"] = frame->metrics.residual_pack_ms;
  result["npu_inference_ms"] = frame->metrics.npu_inference_ms;
  result["native_total_ms"] = frame->metrics.total_ms;
  result["output_scale"] =
      rk3576_dmabuf_runtime_output_scale(runtimes_[frame->worker]);
  result["output_zero_point"] =
      rk3576_dmabuf_runtime_output_zero_point(runtimes_[frame->worker]);
  return result;
}

// Return final direct-path telemetry and remove the token after composition or
// failure. Calling this early leaves the token intact.
Dictionary RK3576NativeBridge::consume_direct_frame(
    std::int64_t frame_token) {
  const std::uint64_t token = static_cast<std::uint64_t>(frame_token);
  const auto frame = find_direct_frame(token);
  if (frame == nullptr) {
    return error_result("direct frame token is unknown");
  }
  Dictionary result = direct_frame_status(frame_token);
  bool consumable = false;
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    consumable = !frame->error.empty() || frame->composition_complete;
    result["worker_id"] = core_mask_label(core_masks_[frame->worker]);
    result["core_mask"] = core_masks_[frame->worker];
    result["topology_mode"] = String(frame->topology_mode.c_str());
    result["slot_index"] = static_cast<int>(frame->slot);
    result["sequence_id"] =
        static_cast<std::int64_t>(frame->runtime_sequence);
    result["rga_input_convert_ms"] = frame->metrics.rga_resize_ms;
    result["residual_publish_ms"] = frame->metrics.residual_pack_ms;
    result["npu_inference_ms"] = frame->metrics.npu_inference_ms;
    result["native_total_ms"] = frame->metrics.total_ms;
    result["output_scale"] =
        rk3576_dmabuf_runtime_output_scale(runtimes_[frame->worker]);
    result["output_zero_point"] =
        rk3576_dmabuf_runtime_output_zero_point(runtimes_[frame->worker]);
  }
  if (!consumable) {
    result["ok"] = false;
    result["error"] = "direct frame is not ready to consume";
    return result;
  }
  release_direct_slot(frame);
#ifdef PAPER1_TARGET_RK3566
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    result["ok"] = frame->error.empty() && frame->slot_released;
    result["error"] = String(frame->error.c_str());
    result["slot_released"] = frame->slot_released;
  }
#endif
  {
    std::lock_guard<std::mutex> lock(direct_frames_mutex_);
    direct_frames_.erase(token);
  }
  return result;
}

// Release one slot exactly once. This method is safe from render, worker, and
// cleanup threads because the frame mutex protects the ownership transition.
void RK3576NativeBridge::release_direct_slot(
    const std::shared_ptr<DirectFrameState>& frame) {
#ifdef PAPER1_TARGET_RK3566
  std::lock_guard<std::mutex> lock(frame->mutex);
  if (!frame->slot_released) {
    const int rc = (frame->worker < runtimes_.size() && runtimes_[frame->worker] != nullptr)
        ? rk3576_dmabuf_runtime_release_direct_slot(runtimes_[frame->worker], frame->slot) : -1;
    if (rc == 0) {
      frame->slot_released = true;
    } else {
      frame->error += "; runtime direct-slot release failed";
    }
  }
  if (frame->capture_fence_fd >= 0) {
    ::close(frame->capture_fence_fd);
    frame->capture_fence_fd = -1;
  }
  if (frame->composition_fence_fd >= 0) {
    ::close(frame->composition_fence_fd);
    frame->composition_fence_fd = -1;
  }
#else
  bool should_release = false;
  {
    std::lock_guard<std::mutex> lock(frame->mutex);
    if (!frame->slot_released) {
      frame->slot_released = true;
      should_release = true;
    }
    if (frame->capture_fence_fd >= 0) {
      ::close(frame->capture_fence_fd);
      frame->capture_fence_fd = -1;
    }
    if (frame->composition_fence_fd >= 0) {
      ::close(frame->composition_fence_fd);
      frame->composition_fence_fd = -1;
    }
  }
  if (should_release && frame->worker < runtimes_.size() &&
      runtimes_[frame->worker] != nullptr) {
    rk3576_dmabuf_runtime_release_direct_slot(
        runtimes_[frame->worker], frame->slot);
  }
#endif
}

// Tear down each context while holding both lifecycle and per-worker locks so
// no worker can access a runtime during cleanup.
void RK3576NativeBridge::close() {
  std::vector<std::shared_ptr<DirectFrameState>> active_frames;
  {
    std::lock_guard<std::mutex> lock(direct_frames_mutex_);
    for (const auto& [token, frame] : direct_frames_) {
      static_cast<void>(token);
      active_frames.push_back(frame);
    }
    direct_frames_.clear();
  }
  for (const auto& frame : active_frames) {
    release_direct_slot(frame);
  }
  std::lock_guard<std::mutex> lifecycle_lock(lifecycle_mutex_);
  for (std::size_t index = 0; index < runtimes_.size(); ++index) {
    std::lock_guard<std::mutex> worker_lock(runtime_mutexes_[index]);
    rk3576_dmabuf_runtime_destroy(runtimes_[index]);
    runtimes_[index] = nullptr;
  }
  input_width_ = 0;
  input_height_ = 0;
  output_bytes_ = 0;
  slot_count_ = 0;
  active_worker_count_ = 0;
  core_masks_ = {0, 0, 0};
  core_profile_.clear();
  model_path_.clear();
}

// Build a stable failure payload for validation, initialization, or RKNN
// errors; callers never need to catch a native exception.
Dictionary RK3576NativeBridge::error_result(const std::string& message) const {
  Dictionary result;
  result["ok"] = false;
  result["error"] = String(message.c_str());
  return result;
}

}  // namespace godot
