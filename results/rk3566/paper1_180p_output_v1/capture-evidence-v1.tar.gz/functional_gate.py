"""Strict acceptance of raw-bound, locally replayed RK3566 functional evidence."""
import hashlib
import json
from pathlib import PurePosixPath

EXCLUDED = {'numerical-check-v2.json', 'numerical-replay-v1.json', 'source/run_rk3566.py'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_cases(numerical):
    assert numerical['all_pass'] is True and numerical['scientific_samples'] == 0
    cases = numerical['cases']
    assert len(cases) == 9
    assert {(row['width'],row['source']) for row in cases} == {(w,s) for w in (160,) for s in range(9)}
    for row in cases:
        assert row['selected'] is True and row['pass'] is True and row['residual_exact'] is True
        assert 0 <= row['input_max_abs'] <= 1
        for key in ('composition_max_abs','root_max_abs'):
            assert 0 <= row[key] <= 2
        for key in ('composition_mae','root_mae'):
            assert 0 <= row[key] <= .25


def raw_files(directory):
    return {p.relative_to(directory).as_posix():sha(p) for p in sorted(directory.rglob('*'))
            if p.is_file() and p.relative_to(directory).as_posix() not in EXCLUDED}


def verify_functional(directory, expected_commands, checker_sha256):
    terminal = json.loads((directory/'terminal.json').read_text())
    complete = json.loads((directory/'complete.json').read_text())
    assert terminal == complete == {'status':'COMPLETE','scientific_samples':0}
    start = json.loads((directory/'start.json').read_text())
    assert start['scientific_samples'] == 0 and start['commands'] == expected_commands
    for width,cmd in zip((160,),expected_commands):
        cell = directory/f'{width}_native'
        assert json.loads((cell/'command.json').read_text()) == cmd
        text=(cell/'run.log').read_text()
        assert 'ERROR:' not in text
        matched=[json.loads(line.split('=',1)[1])['source'] for line in text.splitlines() if line.startswith('NATIVE_SOURCE_MATCH=')]
        selected=[int(line.split('=',1)[1]) for line in text.splitlines() if line.startswith('NATIVE_ROOT_SAVED=')]
        assert sorted(matched)==sorted(selected)==list(range(9))
        model=next(arg.split('=',1)[1] for arg in cmd if arg.startswith('--native-bridge-model='))
        remote=PurePosixPath(next(arg.split('=',1)[1] for arg in cmd if arg.startswith('--output-dir=')))
        program=str(PurePosixPath(cmd[0]).parent.parent/'reference_quantized_input')
        for source in range(9):
            for suffix in ('input_rgb.bin','input_int8.bin','residual_rgb.bin','reference.nchw','root.png','texture.png'):
                assert (cell/f'source_{source}_{suffix}').is_file()
            expected=[program,model,str(remote/f'source_{source}_input_int8.bin'),str(remote/f'source_{source}_reference.nchw')]
            assert json.loads((cell/f'source_{source}_reference-command.json').read_text())==expected
    synthetic=(directory/'synthetic.log').read_text()
    assert 'PROMPT_SYNTHETIC_PASS' in synthetic and 'ERROR:' not in synthetic
    numerical=json.loads((directory/'numerical-check-v2.json').read_text())
    check_cases(numerical)
    replay=json.loads((directory/'numerical-replay-v1.json').read_text())
    assert replay['schema']==1 and replay['scientific_samples']==0
    assert replay['checker_sha256']==checker_sha256
    assert replay['result_sha256']==sha(directory/'numerical-check-v2.json')
    assert replay['result']==numerical
    assert replay['raw_files']==raw_files(directory), 'raw evidence/replay mismatch'
    return numerical
