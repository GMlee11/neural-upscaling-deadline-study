#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/core/defs.hpp>
#include <godot_cpp/godot.hpp>

#include "rk3576_native_bridge.h"

using namespace godot;

// Register only at scene level because the bridge is a RefCounted object used
// by GDScript workers, not a rendering-server implementation.
void initialize_rk3576_native_bridge(ModuleInitializationLevel level) {
  if (level == MODULE_INITIALIZATION_LEVEL_SCENE) {
    GDREGISTER_CLASS(RK3576NativeBridge);
  }
}

// The bridge owns no process-global state, so normal object destructors perform
// cleanup and the module terminator only preserves Godot's expected hook.
void uninitialize_rk3576_native_bridge(ModuleInitializationLevel level) {
  if (level != MODULE_INITIALIZATION_LEVEL_SCENE) {
    return;
  }
}

extern "C" {

// Install the scene-level initializer through Godot's stable GDExtension ABI.
GDExtensionBool GDE_EXPORT rk3576_native_bridge_init(
    GDExtensionInterfaceGetProcAddress get_proc_address,
    GDExtensionClassLibraryPtr library,
    GDExtensionInitialization* initialization) {
  GDExtensionBinding::InitObject init_object(
      get_proc_address,
      library,
      initialization);
  init_object.register_initializer(initialize_rk3576_native_bridge);
  init_object.register_terminator(uninitialize_rk3576_native_bridge);
  init_object.set_minimum_library_initialization_level(
      MODULE_INITIALIZATION_LEVEL_SCENE);
  return init_object.init();
}

}
