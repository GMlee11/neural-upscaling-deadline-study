extends "res://main.gd"

# Synthetic control-flow test only: no scene replay or NPU inference.
class FailedRelease:
	extends RefCounted
	func consume_direct_frame(_token: int) -> Dictionary:
		return {"ok": false, "error": "injected final-frame release failure"}

func _update_hud() -> void:
	pass

func _process(_delta: float) -> void:
	pass

func _exit_tree() -> void:
	pass

func _ready() -> void:
	call_deferred("check_controls")

func check_controls() -> void:
	native_bridge_core_profile = "rk3566_single_default"
	backend_id = "heterogeneous_progressive"
	benchmark_fps = 30
	native_readback = false
	direct_validation_readback = false
	output_rect = TextureRect.new()
	add_child(output_rect)
	lr_viewport = SubViewport.new()
	lr_viewport.size = Vector2i(16, 16)
	add_child(lr_viewport)
	phase7_fallback_material = ShaderMaterial.new()
	phase7_fallback_material.shader = load("res://bicubic_fallback.gdshader")
	phase7_lanczos_material = ShaderMaterial.new()
	phase7_lanczos_material.shader = load("res://lanczos_fallback.gdshader")
	for method in ["bicubic", "lanczos"]:
		forced_classical_method = method
		_present_gpu_fallback()
		var expected = phase7_lanczos_material if method == "lanczos" else phase7_fallback_material
		if output_rect.material != expected:
			get_tree().quit(9)
			return
		print("CONTROL_SHADER_PASS=" + method + ":" + expected.shader.resource_path)
	forced_classical_method = ""
	native_bridge = FailedRelease.new()
	var image = Image.create(1, 1, false, Image.FORMAT_RGB8)
	var texture = ImageTexture.create_from_image(image)
	var context = {"frame_capture_start_usec": 0, "response_received_usec": 1000000,
		"response": {"valid": true, "texture": texture, "metadata": {
			"neural_payload_kind": "direct_dmabuf_fused_texture", "direct_frame_token": 299}}}
	var path = "/home/paper3/experiments/paper1-rk3566-v1/engineering/control-failure-test-v2.jsonl"
	if FileAccess.file_exists(path):
		get_tree().quit(8)
		return
	var telemetry = FileAccess.open(path, FileAccess.WRITE)
	# Stand-in prefix is explicitly synthetic. The failing final row must not be appended.
	for index in range(299):
		telemetry.store_line(JSON.stringify({"synthetic_test_frame": index}))
	var accepted: bool = await _record_benchmark_frame(telemetry, 299, context, 0)
	telemetry.close()
	if accepted:
		get_tree().quit(9)
		return
	print("FINAL_RELEASE_REJECTED: expected exit 3, retained 299 synthetic prefix rows")
	get_tree().quit(3)
