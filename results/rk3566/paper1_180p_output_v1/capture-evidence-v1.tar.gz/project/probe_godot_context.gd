extends SceneTree

func _initialize() -> void:
	call_deferred("run_probe")

func run_probe() -> void:
	if not ClassDB.class_exists("RK3576NativeBridge"):
		print("PROBE_FAILED: native class unavailable")
		quit(2)
		return
	var bridge = ClassDB.instantiate("RK3576NativeBridge")
	bridge.reset_render_probe()
	RenderingServer.call_on_render_thread(bridge.probe_render_context)
	for index in range(60):
		await process_frame
		if bridge.status().get("render_probe_complete", false):
			break
	var status: Dictionary = bridge.status()
	print("GODOT_CONTEXT_PROBE=" + JSON.stringify(status))
	if not status.get("render_probe_compatible", false) or not "Mali" in str(status.get("gl_renderer", "")):
		quit(3)
		return
	for shape in [[320, 180], [640, 360]]:
		var model = "/home/paper3/experiments/paper1-rk3566-v1/engineering/models/%dx%d/model.rknn" % shape
		var configured: Dictionary = bridge.configure(model, shape[0], shape[1], 3, "rk3566_single_default")
		print("MODEL_CONFIGURATION=" + JSON.stringify(configured))
		if not configured.get("ok", false):
			bridge.close()
			quit(4)
			return
		bridge.close()
	quit(0)
